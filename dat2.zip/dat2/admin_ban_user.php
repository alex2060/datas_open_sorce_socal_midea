
<?php 
$uname=$_SESSION['uname'];
if ($uname=="") {
  $uname="nobody";
}
include("config.php");
include("web_name.php");


$Sight_Pass=$_POST["Sight_Pass"];
$baned_user=$_POST["baned_user"];




if ($Sight_Pass==$addminpass) {
  $sql= "DELETE FROM  user_".$sitename." WHERE user = '".$baned_user."'; ";
  $result = $conn->query($sql);
  $output=$sql;
}

?>







<!DOCTYPE html>
<html>
<head>
  <title>first_page</title>

<style>
.boady{

  width: 12vw;
  height: 6vw;
  font-size: 5vw;

}
.parent{
    display: flex;
    flex-direction:column;

}
.child1{

    color: blue;
    text-decoration-color: 
    flex: 1;
    margin: 4vw;
    padding: 5vw;
     border: 5px solid black;

}
.button{
  min-width:12vw;
  height: 5vw;
  font-size: 4vw;
}
.button2{
  min-width:15vw;
  height: 5vw;
  font-size: 3vw;
}


</style>

<body style="background-color: #24222a;">
  <div class="parent" style="background-color: #24222a;">

    <div class="child child1" style="background-color: #000000; color: #ffffffff; font-size:6vw; flex: 1; display: flex;">
    <form action = "" method = "POST" enctype = "multipart/form-data">

            <label for="login">Sight Pass</label><br>
            <input type="boady" id="boady" name="Sight_Pass" class="button" value=""><br>
            
            <label for="login">user to ban</label><br>
            <input type="linked" id="sorce" name="baned_user" class="button" value=<?php echo "\"".$_GET["pageid"]."\""; ?> > <br>
            </br>
            <input type="submit" class="button2" value="Enter">

    </form>
  <?php echo $output;   ?>
  </div>
</div>

    
</body>
</html>
