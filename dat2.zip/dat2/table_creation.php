<?php

include("web_name.php");
include("config.php");
$Sight_Pass=$_POST["Sight_Pass"];

$sql1="CREATE TABLE `post_".$sitename."` (  

`fild_id` VARCHAR(64) NOT NULL 			, 
`user` TEXT NOT NULL 					, 
`views` INT NOT NULL 					, 
`views_this_mouth` INT NOT NULL 		, 
`tital` TEXT NOT NULL 					, 
`type` TEXT NOT NULL  					,
`header` TEXT NOT NULL    				, 
`boady` TEXT NOT NULL     				, 
`linked` TEXT NOT NULL    				, 
`sorce` TEXT NOT NULL     				, 
`upvote` INT NOT NULL     				, 
`downvote` INT NOT NULL   				, 
`buypage` BOOLEAN not Null  			, 
`price` FLOAT not Null 					, 
`git_data` Text not Null 				, 
`eamil_data` Text not NUll 				,
`created` TIMESTAMP NOT NULL 			,  
PRIMARY KEY (fild_id) ) ENGINE = MyISAM ;";

$sql2="CREATE TABLE `user_".$sitename."` (
`user` VARCHAR(100) NOT NULL , 
`payment` TEXT NOT NULL , 
`created` TIMESTAMP NOT NULL , 
`email` TEXT NOT NULL , 
`phone number` TEXT NOT NULL , 
`paymentkey` TEXT NOT NULL , 
`pass` TEXT NOT NULL, 
`views` int NOT NULL,
`view_M` int not NULL,
PRIMARY KEY (user) ) ENGINE = MyISAM";






if ($Sight_Pass==$addminpass) {

$result = $conn->query($sql1);
$result = $conn->query($sql2);
}


$output=$sql1." ";


?>



<!DOCTYPE html>
<html>
<head>
  <title>first_page</title>

<style>
.boady{

  width: 12vw;
  height: 6vw;
  font-size: 5vw;

}
.parent{
    display: flex;
    flex-direction:column;

}
.child1{

    color: blue;
    text-decoration-color: 
    flex: 1;
    margin: 4vw;
    padding: 5vw;
     border: 5px solid black;

}
.button{
  min-width:12vw;
  height: 5vw;
  font-size: 4vw;
}
.button2{
  min-width:15vw;
  height: 5vw;
  font-size: 3vw;
}


</style>

<body style="background-color: #24222a;">
  <div class="parent" style="background-color: #24222a;">

    <div class="child child1" style="background-color: #000000; color: #ffffffff; font-size:6vw; flex: 1; display: flex;">
    <form action = "" method = "POST" enctype = "multipart/form-data">

            <label for="login">Sight Pass to make table</label><br>
            <input type="boady" id="boady" name="Sight_Pass" class="button" value=""><br>
            
            <input type="submit" class="button2" value="Enter">

    </form>
  <?php echo $output;   ?>
  </div>
</div>

    
</body>
</html>

