<?php
$sitename="alex_4";
$addminpass="passaddmin";
$webpath="http://alexhaussmann.com/adhaussmann/alex/dat2/";
?>