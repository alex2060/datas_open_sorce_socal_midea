<?php
$_SESSION['logedin']=""

$_SESSION['uname']=""

?>
loged out