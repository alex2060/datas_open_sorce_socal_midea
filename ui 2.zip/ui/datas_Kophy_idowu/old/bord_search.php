<?php

session_start();
$uname=$_SESSION['uname'];

if ($uname=="") {
  $uname="nobody";
}
include("config.php");
$board_name_S=$_GET["board_name"];
$disc_S=$_GET["disc"];
$flags_S=$_GET["flags"];
$order_type=$_GET["order_type"];
$combo_type=$_GET["combo_type"];

$tops="  ORDER BY `created` DESC ";

$hots="  ";

$sort=$hots;
$sql2="";
/*
	CREATE TABLE `treelose_data`.`bord_data` ( 
	`board` VARCHAR(200) NULL , 
	`owner` TEXT NOT NULL, 
	`disc` TEXT NOT NULL, 
	`rules` TEXT NOT NULL, 
	`photo1` TEXT NOT NULL,
	`photo2` TEXT NOT NULL,
	`flags` TEXT NOT NULL, 
	PRIMARY KEY (board) ) ENGINE = MyISAM
*/
include("seach.php");
$sql2= get_seach_sql_with_3_flags(
		"B_data",

		$board_name_S,
		"",
		$combo_type,
		$disc_S,"disc",
		$flags_S,"flags",
		"","flags",
		$items_return,
		6,
		0,
		""

);


include "style/make_body_post.php";

$result = $conn->query($sql2);
$outputdiv=make_body("board_seach",$result);




?>


<!DOCTYPE html>
<html>
<head>
<style>

	<?php
		include "style/seach_page_style.php";
		echo $post_page_css;
	?>

</style>
</head>
<body>

<div class = "phote">

	<div class = "header">
		<h2>board search</h2>s
		<?php include "style/heading_nav.php"; echo $header_nav_for_sight; ?>

		<div class = "body_top">
					<form>
							  <label for="board">board_name</label></br>
							  <input type="text" id="board_name" name="board_name"></br>
							  <label for="lname">flag1</label></br>
							  <input type="text" id="disc" name="disc"></br>
							  <label for="lname">flags</label></br>
							   <input type="text" id="flags" name="flags"></br></br>
							 </br>




								<select name="combo_type" id="type">

									  <option value="or_e">or exclusive</option>

									  <option value="and_e">and exclusive</option>

									  <option value="or_i">or inclusive</option>

									  <option value="and_i">and inclusive</option>

								</select>


								<select name="order_type" id="type">

								  <option value="time">time</option>

								  <option value="top">top</option>

								  <option value="hot">hot</option>
							  
								</select>
								</br>
								<input type="submit" value="search form">


					</form> 
		
		</div>
			<?php 
				$i = 0;
		        while ($i < count($outputdiv) )
		        {
		            echo $outputdiv[$i] ."<br />";
		            $i++;
		        }

		    ?>

	<?php 

        include "style/log_in_its_done.php";
        echo $output_login;

    ?>  

	</div>



</div>


</body>
</html>















