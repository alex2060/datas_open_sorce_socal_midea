<?php
    session_start();

    if($_SESSION == false){
        header("Location: ./signin.php");
        exit();
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/newpost.css">
    <link rel="stylesheet" href="fonts/style.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https:  //fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />



    <title>Document</title>

</head>
<body>
    <div class="loader">
        <div class="lds-ring">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div> 

    <!-- header file for general navigation -->
    <?php include_once 'header.php';?>

    <section class="create-post">
        <form action="./services/post/create.php" method="POST" enctype="multipart/form-data">
            <div class="post">
                <div class="postpicture">
                    <div class="label">IMAGE</div>
                    <label for="profilepic" class="changeprofilepicture">
                        <img src="./img/placeholder-image.jpg" class="profilepicture">
                    </label>
                    <input type="file" name="postimg" accept="image/*" id="profilepic" hidden>
                </div>
                
                <div class="post-details">
                    <div class="title">
                        <div class="label">TITLE</div>
                        <input name="title" class="title">
                    </div>
                    <div class="info">
                        <div class="label">BODY</div>
                        <textarea class="body" name="body" placeholder="Type your caption here..."></textarea>
                    </div>
                    <div class="starting-price">
                        <div class="label">PRICE</div>
                        <div class="price-input">
                            <span class="hash">$</span> 
                            <input class="price" name="price" type="number" placeholder="Enter Price">
                        </div>
                    </div>

                    <button type="submit" class="create-post" disabled>Create Post</button>
                </div>
            </div>
        </form>
    </section>

    <script src="js/jquery.min.js"></script>
    <script src="js/style.js"></script>
    <script src="js/newpost.js"></script>
</body>
</html>