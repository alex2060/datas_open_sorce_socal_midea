<?php
    session_start();
    if(isset($_SESSION['user'])){
       header('Location: ./index.php');
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/auth.css">
<link rel="stylesheet" href="fonts/style.css">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https:  //fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />



<title>HOME</title>

</head>
<body>
    <div class="loader">
        <div class="lds-ring">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>  
    
    <section class="login-box">
        <div class="logo">Simple.</div>
        <?php
            if(isset($_SESSION['message'])){
               if($_SESSION['message'] != ''){
                    echo "<div class='errormsg'>
                            ".$_SESSION['message']."
                        </div>";
               }
            }
        ?>
        <div class="form">
           <form action="./services/user/signin.php" method="POST">
                <div>
                    <div class="label">Username</div>
                    <input type="text" class="username" name="username">
                </div>
                <div>
                    <div class="label">Password</div>
                    <input type="password" class="password" name="password">
                </div>
            </div>

            <button class="signin">SIGN IN</button>
        </form>

        <div class="newaccount">
            <div>Don't have an account?</div>
            <a href="./signup.php"><div class="signup">Sign Up</div></a>
        </div>
    </section>


<script src="js/jquery.min.js"></script>
<script src="js/style.js"></script>
</body>
</html>