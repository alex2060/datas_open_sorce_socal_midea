<?php
    class Post {
        //DB stuff
        private $conn;
        private $table = 'post';

        //Post Properties
        public $field_id;
        public $username;
        public $views;
        public $views_this_month;
        public $title;
        public $type;
        public $header;
        public $body;
        public $img;
        public $source;
        public $upvote;
        public $downvote;
        public $buypage;
        public $price;
        public $git_data;
        public $email_data;
        public $date_created;

        //Constructor with DB
        public function __construct($db) {
            $this->conn = $db;
        }

        //Get Posts
        public function read() {

            //Create query
            $query = 'SELECT 
                p.field_id,
                p.username,
                p.views,
                p.views_this_month,
                p.title,
                p.type,
                p.header,
                p.body,
                p.img,
                p.source,
                p.upvote,
                p.downvote,
                p.buypage,
                p.price,
                p.git_data,
                p.email_data,
                p.date_created
            FROM
                '.$this->table.' p

            ORDER BY
                p.date_created DESC
            ';

            //prepare statement
            $stmt = $this->conn->prepare($query);

            //Execute query
            $stmt->execute();

            return $stmt;
        }

        //Get Single post
        public function read_single() {
            //Create query

            $query = 'SELECT 
                p.field_id,
                p.username,
                p.views,
                p.views_this_month,
                p.title,
                p.type,
                p.header,
                p.body,
                p.img,
                p.source,
                p.upvote,
                p.downvote,
                p.buypage,
                p.price,
                p.git_data,
                p.email_data,
                p.date_created
            FROM
              '.$this->table.' p 
            WHERE
                p.field_id = ?
            LIMIT 0,1
            ';

            //prepare statement
            $stmt = $this->conn->prepare($query);

            //Bind ID
            $stmt->bindParam(1, $this->field_id);

            //Execute query
            $stmt->execute();

            $row = $stmt->fetch(PDO::FETCH_ASSOC);

            //set properties
            $this->field_id = $row['field_id'];
            $this->username = $row['username'];
            $this->views = $row['views'];
            $this->views_this_month = $row['views_this_month'];
            $this->title = $row['title'];
            $this->type = $row['type'];
            $this->header = $row['header'];
            $this->body = $row['body'];
            $this->img = $row['img'];
            $this->source = $row['source'];
            $this->upvote = $row['upvote'];
            $this->downvote = $row['downvote'];
            $this->buypage = $row['buypage'];
            $this->price = $row['price'];
            $this->git_data = $row['git_data'];
            $this->email_data = $row['email_data'];
            $this->date_created = $row['date_created'];

            return $stmt;
        }

        //create post
        public  function create(){
            //create query
            $query = 'INSERT INTO ' 
                . $this->table . '
            SET 
                title = :title,
                body = :body,
                username = :username,
                views = :views,
                views_this_month = :views_this_month,
                type = :type,
                header = :header,
                img = :img,
                source = :source,
                upvote = :upvote,
                downvote = :downvote,
                buypage = :buypage,
                price = :price,
                git_data = :git_data,
                email_data = :email_data
            ';

            //prepare statement
            $stmt = $this->conn->prepare($query);

            //clean data
            $this->title = htmlspecialchars(strip_tags($this->title));
            $this->body = htmlspecialchars(strip_tags($this->body));
            $this->username = htmlspecialchars(strip_tags($this->username));
            $this->views = htmlspecialchars(strip_tags($this->views));
            $this->views_this_month = htmlspecialchars(strip_tags($this->views_this_month));
            $this->type = htmlspecialchars(strip_tags($this->type));
            $this->header = htmlspecialchars(strip_tags($this->header));
            $this->img = htmlspecialchars(strip_tags($this->img));
            $this->source = htmlspecialchars(strip_tags($this->source));
            $this->upvote = htmlspecialchars(strip_tags($this->upvote));
            $this->downvote = htmlspecialchars(strip_tags($this->downvote));
            $this->buypage = htmlspecialchars(strip_tags($this->buypage));
            $this->price = htmlspecialchars(strip_tags($this->price));
            $this->git_data = htmlspecialchars(strip_tags($this->git_data));
            $this->email_data = htmlspecialchars(strip_tags($this->email_data));


            //bind data
            $stmt->bindParam(':title', $this->title);
            $stmt->bindParam(':body', $this->body);
            $stmt->bindParam(':username', $this->username);
            $stmt->bindParam(':views', $this->views);
            $stmt->bindParam(':views_this_month', $this->views_this_month);
            $stmt->bindParam(':type', $this->type);
            $stmt->bindParam(':header', $this->header);
            $stmt->bindParam(':img', $this->img);
            $stmt->bindParam(':source', $this->source);
            $stmt->bindParam(':upvote', $this->upvote);
            $stmt->bindParam(':downvote', $this->downvote);
            $stmt->bindParam(':buypage', $this->buypage);
            $stmt->bindParam(':price', $this->price);
            $stmt->bindParam(':git_data', $this->git_data);
            $stmt->bindParam(':email_data', $this->email_data);

            //Execute query
            if($stmt->execute()){
                return true;
            }

            //print error if something goes wrong
            printf("Error: %s.\n", $stmt->error);

            return false;
        }

        //update post
        public  function update(){
            //create query
            $query = 'UPDATE ' 
                . $this->table . '
            SET 
                title = :title,
                body = :body,
                author = :author,
                category_id = :category_id
                
            WHERE 
                id = :id';

            //prepare statement
            $stmt = $this->conn->prepare($query);

            //clean data
            $this->title = htmlspecialchars(strip_tags($this->title));
            $this->body = htmlspecialchars(strip_tags($this->body));
            $this->author = htmlspecialchars(strip_tags($this->author));
            $this->category_id = htmlspecialchars(strip_tags($this->category_id));
            $this->id = htmlspecialchars(strip_tags($this->id));

            //bind data
            $stmt->bindParam(':title', $this->title);
            $stmt->bindParam(':body', $this->body);
            $stmt->bindParam(':author', $this->author);
            $stmt->bindParam(':category_id', $this->category_id);
            $stmt->bindParam(':id', $this->id);

            //Execute query
            if($stmt->execute()){
                return true;
            }

            //print error if something goes wrong
            printf("Error: %s.\n", $stmt->error);

            return false;
        }
    }

