<?php

    class User {

        //DB stuff
        private $conn;
        private $table = 'user_';

        //users properties
        public $username;
        public $email;
        public $password;

        //Constructor with DB
        public function __construct($db) {
            $this->conn = $db;
        }

        //Get Posts
        public function read() {
            //Create query

            $query = 'SELECT 
                user_.username,
                user_.email,
                user_.password,

            FROM
                '.$this->table.' user_

            ORDER BY
                user_.created_at DESC
            ';  

            //prepare statement
            $stmt = $this->conn->prepare($query);

            //Execute query
            $stmt->execute();

            return $stmt;
        }

        //Get Single post
        public function read_single() {
            //Create query

            $query = 'SELECT 
                user_.username,
                user_.email,
                user_.password,

            FROM
                '.$this->table.' user_

            WHERE
                user_.id = ?

            LIMIT 0,1
            ';

            //prepare statement
            $stmt = $this->conn->prepare($query);

            //Bind ID
            $stmt->bindParam(1, $this->id);

            //Execute query
            $stmt->execute();

            $row = $stmt->fetch(PDO::FETCH_ASSOC);

            //set properties
            $this->username = $row['username'];
            $this->email = $row['email'];
            $this->password = $row['password'];

            return $stmt;
        }

        //create post
        public  function create(){

            //create query
            $query = 'INSERT INTO ' 
                . $this->table . '
            SET 
                username = :username,
                email = :email,
                password = :password';

            //prepare statement
            $stmt = $this->conn->prepare($query);

            //clean data
            $this->username = htmlspecialchars(strip_tags($this->username));
            $this->email = htmlspecialchars(strip_tags($this->email));
            $this->password = htmlspecialchars(strip_tags($this->password));
    

            //bind data
            $stmt->bindParam(':username', $this->username);
            $stmt->bindParam(':email', $this->email);
            $stmt->bindParam(':password', $this->password);

            //Execute query
            if($stmt->execute()){
                return true;
            }

            //print error if something goes wrong
            printf("Error: %s.\n", $stmt->error);

            return false;
        }


    }

