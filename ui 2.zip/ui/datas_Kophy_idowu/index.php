
<?php

    session_start();
    if(!isset($_SESSION['user'])){
        header('Location: ./signin.php');
    }

    include './services/post/read.php';

    function detDate($date){
        $currentDate = date_timestamp_get(date_create());
        $date = date_timestamp_get(date_create($date));
  
        $timeInSeconds = $currentDate - $date;
        $timeInMinutes = $timeInSeconds / 60;
        $timeInHours = $timeInSeconds / 3600;
        $timeInDays  = $timeInHours / 24;
        $timeInMonths  = $timeInHours / 30;
        $timeInYear  = $timeInMonths / 12;

        if($timeInSeconds < 60){
            return floor($timeInSeconds).'s';
        } else if($timeInMinutes < 60){
             return floor($timeInMinutes).'m';
        } else if($timeInHours < 24){
            return floor($timeInHours).'hr';
        } else if($timeInDays < 30){
        return floor($timeInDays).'days';
        } else if($timeInMonths < 12){
            return floor($imeInMonths).'mon';
        } else {
            return floor(timeInYear).'yr';
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/posts.css">
    <link rel="stylesheet" href="fonts/style.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https:  //fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />



    <title>HOME</title>

</head>
<body>
    <div class="loader">
        <div class="lds-ring">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>  

    <?php include_once 'header.php';?>

    <section class="all_posts">
        <?php
            for($count = 0; $count < count($posts_arr['data']); $count++){
                echo '
                    <div class="a_post">
                        <img src="img/uploads/'.$posts_arr['data'][$count]['img'].'">
                        <div class="content">
                            <a class="a_post" href="./post.php?field_id='.$posts_arr['data'][$count]['field_id'].'">
                                <div class="title">
                                '.$posts_arr['data'][$count]['title'].'
                                </div>
                                <div class="body">
                                '.$posts_arr['data'][$count]['body'].'
                                </div>
                            </a>
                        </div>
                        <div class="meta">
                            <div class="date">'.detDate($posts_arr['data'][$count]['date_created']).'</div>
                        </div>
                    </div>
                ';
            };
        ?>

    </section>

    <script src="js/jquery.min.js"></script>
    <script src="js/style.js"></script>
</body>
</html>