$(document).ready(function(){

    $('textarea.body').keyup(function(){
        enableButton();
    });
  
    $('input#profilepic').change(function(){
        if(this.files && this.files[0]){
            var reader = new FileReader();
            reader.onload = function(e){
                $('img.profilepicture').attr('src', e.target.result);
            }
            reader.readAsDataURL(this.files[0]);
            enableButton();
        }
    });

    $('input.price').keyup(function(){
        enableButton();
    });

    $('input.title').keyup(function(){
        enableButton();
    });
});

function enableButton(){
    if($('textarea.body').val() == '' || $('input.price').val() == '' || $('input.title').val() == ''){
        $('button.create-post').attr('disabled', true)
    } else {
        $('button.create-post').attr('disabled', false)
    }
}
