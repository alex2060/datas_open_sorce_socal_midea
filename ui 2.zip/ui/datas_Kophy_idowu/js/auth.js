$(document).ready(function(){

    $('button.signin').click(function(){ 
        $.ajax({
            type: 'POST',
            url: './services/user/signin.php',
            dataType: 'application/json',
            data: {
                username: $('input.username').val(),
                password: $('input.password').val()
            },
            success: function(data){
                console.log(data);
            },
            error: function(data){
                console.log(data);
            }
        });
    });

    $('button.signup').click(function(){
        $username = $('input.username').val();
        $email = $('input.email').val();
        $password = $('input.password').val();

        $.ajax({
            type: 'POST',
            url: './services/user/register.php',
            data: {'username': $username, 'email': $email, 'password': $password},
            success: function(data){
                console.log(data);
            },
            error: function(data){

            }
        });
    });

});