$(document).ready(function(){

    $('div.loader').fadeOut(2000);

    $('nav div.search').click(function(){
        $('section.search-frame').removeClass('hidden');
        $('section.search-frame').removeClass('animate__fadeOut');
        $('section.search-frame').addClass('animate__fadeIn');
        $('nav div.search').html('');
    });

    $('section.search-frame div.layer').click(function(){
        $('section.search-frame').removeClass('animate__fadeIn');
        $('section.search-frame').addClass('animate__fadeOut');
        $('section.search-frame').addClass('hidden');
        $('nav div.search').html('<i class="icon-search"></i>');
    });
    
});
