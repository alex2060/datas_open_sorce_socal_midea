
<?php
    include './services/post/readsingle.php';

    function detDate($date){
        $currentDate = date_timestamp_get(date_create());
        $date = date_timestamp_get(date_create($date));
  
        $timeInSeconds = $currentDate - $date;
        $timeInMinutes = $timeInSeconds / 60;
        $timeInHours = $timeInSeconds / 3600;
        $timeInDays  = $timeInHours / 24;
        $timeInMonths  = $timeInHours / 30;
        $timeInYear  = $timeInMonths / 12;

        if($timeInSeconds < 60){
            return floor($timeInSeconds).'s';
        } else if($timeInMinutes < 60){
             return floor($timeInMinutes).'m';
        } else if($timeInHours < 24){
            return floor($timeInHours).'hr';
        } else if($timeInDays < 30){
        return floor($timeInDays).'days';
        } else if($timeInMonths < 12){
            return floor($imeInMonths).'mon';
        } else {
            return floor(timeInYear).'yr';
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/post.css">
    <link rel="stylesheet" href="fonts/style.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />



    <title>POST</title>

</head>
<body>
    <div class="loader">
        <div class="lds-ring">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>  

    <?php include_once 'header.php';?>

    <section class="post">
        <?php 
            echo '
                <div class="meta">
                    <div>
                        <div class="vote">
                            <div class="upvote">
                                <div class="digit">'.$post_item['upvote'].'</div>
                                <div class="icon"><i class="icon-arrow-with-circle-up"></i></div>
                            </div>
                            <div class="downvote">
                                <div class="icon"><i class="icon-arrow-with-circle-down"></i></div>
                                <div class="digit">'.$post_item['upvote'].'</div>
                            </div>
                        </div>
                        <div class="buy">
                            <div class="price">$'.$post_item['price'].'</div>
                            <button class="buy">BUY</button>
                        </div>
                    </div>
                </div>
                <div class="main">
                    <div class="title">'.$post_item['title'].'</div>
                    <div class="user">
                        <div class="user-icon">
                            <div class="icon-user1"></div>
                        </div>
                        <div class="username">
                            '.$post_item['username'].'
                        </div>
                        <div class="date-created">

                        </div>
                    </div>
                    <img class="post_img" src="img/uploads/'.$post_item['img'].'">
                    <div class="body">
                        '.$post_item['body'].'
                    </div>
                </div>
            ';
        ?>
    </section>

    <script src="js/jquery.min.js"></script>
    <script src="js/style.js"></script>
</body>
</html>