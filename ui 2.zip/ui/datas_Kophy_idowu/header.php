
<header>
    <div class="logo">Simple.</div>
    <nav>
        <div class="links">
            <div><a href="./index.php">HOME</a></div>
            <div><a href="./newpost.php">NEW POST</a></div>
        </div>
        <div class="search"><i class="icon-search"></i></div>
    </nav>
    <div class="user">
        <div class="user-icon">
            <div class="icon-user1"></div>
        </div>
        <?php
            echo '<div class="username">
                    '.$_SESSION['user']['username'].'
                </div>';
        ?>
        <a href="./signout.php"><div class="icon-power1"></div></a>
    </div>
</header>

<section class="search-frame animate__animated hidden">
    <div class="layer"></div>
    <div class="search-box">
        <form>
            <div>
                <label for="fname">User Search</label><br>
                <input type="text" id="user_seach" name="user_seach">
            </div>
            <div>
                <label for="lname">Header</label><br>
                <input type="text" id="header" name="header">
            </div>
            <div>
                <label for="lname">Board Seach</label><br>
                <input type="text" id="boady_seach" name="boady_seach">
            </div>
            <div>
                <label for="lname">Search Item</label><br>
                <input type="text" id="seach_item" name="seach_item">
            </div>

            <select name="combo_type" id="type">
                <option value="or_e">or exclusive</option>
                <option value="and_e">and exclusive</option>
                <option value="or_i">or inclusive</option>
                <option value="and_i">and inclusive</option>
            </select>

            <select name="order_type" id="type">
                <option value="time">time</option>
                <option value="top">top</option>
                <option value="hot">hot</option>
            </select>

            <button type="submit">SEARCH</button>
        </form> 
    </div>
</section>