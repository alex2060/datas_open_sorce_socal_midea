<?

session_start();


include("config.php");
include("web_name.php");

$uname=$_POST["uname"];
$password=$_POST["password"];

$sql = "SELECT * FROM user".$sitename." WHERE user LIKE '".$uname."' ;";

$result = $conn->query($sql1);
if($uname!=""){

  $result = $conn->query($sql1);


  if($result->num_rows==0){


      $go="true";

      $_SESSION['uname']=$uname;

      $sql="INSERT INTO `users_".$sitename."` (`user`, `payment`, `created`, `email`, `phone number`, `paymentkey`, `pass`, `views`, `view_M`) VALUES 
      ('".$uname."', '".$payment."', CURRENT_TIMESTAMP, '".$email."', '".$phone."', '".$paymentkey."', '".$password."', '0', '0');";
      $result = $conn->query($sql);

      $_SESSION['uname']=$uname;
      $_SESSION['logedin']="True";

      header("Location: V3.php");



  }
  else{
      $output="uname in use";
  }

}


$uname=$_SESSION['uname'];
if ($uname=="") {
  $uname="nobody";
}


/*
CREATE TABLE `treelose_data`.`user_T` (
 `user` VARCHAR(100) NOT NULL , 
 `payment` TEXT NOT NULL , 
 `created` TIMESTAMP NOT NULL , 
 `email` TEXT NOT NULL , 
 `phone number` TEXT NOT NULL , 
 `paymentkey` TEXT NOT NULL , 
 `pass` TEXT NOT NULL, 
 `views` int NOT NULL,
 `view_M` int not NULL,
 PRIMARY KEY (user) ) ENGINE = MyISAM
*/



?>






<!DOCTYPE html>
<html>
    <head>
        
        <link rel="stylesheet" href="auth.css" />
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link href="https:  //fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
        
        <title>SIGN UP</title>
    
    </head>

    <body class="body">
        
        <section class="login-box">
            <div class="logo">Simple.</div>
            
            <div class="form">
                <form action="" method="POST" enctype="multipart/form-data">
                    <div>
                        <div class="label">Username</div>
                        <input type="tital" id="uname" name="uname" class="button" value="">
                    </div>
                    <div>
                        <div class="label">Password</div>
                        <input type="header" id="password" name="password" class="button" value="">
                    </div>
                    <div>
                        <div class="label">Website Password</div>
                        <input type="header" id="password" name="sight" class="button" value="">
                    </div>
                    
                    <button class="signin">SIGN IN</button>
                </form>
          
            </div>
        </section>
    
    </body>
</html>








