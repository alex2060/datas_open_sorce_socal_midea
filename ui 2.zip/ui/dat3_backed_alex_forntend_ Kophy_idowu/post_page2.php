<?php


session_start();
include("web_name.php");
if( $_SESSION["logedin".$sitename]==""){
    header("Location: log_in.php?");
}


$uname=$_SESSION["uname".$sitename];
if ($uname=="") {
  $uname="nobody";
}
include("config.php");



$tital=$_POST["tital"];

$header=$_POST["header"];
$boady=$_POST["boady"];
$link=$_POST["link"];

$comtype=$_POST["dropdown"];
$linkdisc=$_POST["linkdisc"];


$sorce=$_POST["sorce"];


$buy=$_POST["buy"];
$price=$_POST["price"];
$git_data=$_POST["git_data"];
$eamil_data=$_POST["eamil_data"];
$type=$_POST["type"];
$bord_I=$_POST["bord"];

$herewego="nothing";

$random_id=$uname1.time();

$buysend="0";
$price_send="5.00";

$output=$tital." heres ".$comtype;



//fild_id
  //user
  //views views_this_mouth
  //tital
  //type
  //header
  //boady
  //linked
  //sorce
//upvote downvote buypage price git_data eamil_data



$sql="";

$herewego="notgood";


$herewego="inlink";
if(isset($_FILES['image'])){
    $herewego="infile";
    $errors= array();
    $file_name = $_FILES['image']['name'];
    $file_size = $_FILES['image']['size'];
    $file_tmp = $_FILES['image']['tmp_name'];
    $file_type = $_FILES['image']['type'];
    $file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));

    $extensions= array("jpeg","jpg","png","gif","mp4");    
    if(in_array($file_ext,$extensions)=== false){
       $errors[]="extension not allowed, please choose a JPEG or PNG file.";
    }
    if($file_size > 2097152) {
       $errors[]='File size must be excately 2 MB';
    }

    if(empty($errors)==true) {
     $output="".$uname.time()."_2";
     move_uploaded_file($file_tmp,"".$random_id);
     $fileMoved = rename($random_id, "imgs/".$random_id ) ;
     $link="imgs/".$random_id;
     $herewego="ture";
    }else{
     print_r($errors);
    }
}





if ($comtype=="Yes") {

  $output="ture";
  $seachid=$boady;
  $websight= $header;


  $ch1 = curl_init();
  curl_setopt($ch1, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch1, CURLOPT_URL,    str_replace(' ', '', $websight."?type=post_B&postID=".$seachid)   );
  $boady       =  curl_exec($ch1);
  curl_close($ch1);



  $ch2 = curl_init();
  curl_setopt($ch2, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch2, CURLOPT_URL,    str_replace(' ', '', $websight."?type=post_2&postID=".$seachid)   );
  $git_data    =  curl_exec($c2);
  curl_close($ch2);



  $ch3 = curl_init();
  curl_setopt($ch3, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch3, CURLOPT_URL,    str_replace(' ', '', $websight."?type=post_H&postID=".$seachid)   );
  $header    =  curl_exec($ch3);
  curl_close($ch3);






  $ch5 = curl_init();
  curl_setopt($ch5, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch5, CURLOPT_URL,  str_replace(' ', '', $websight."?type=post_L&postID=".$seachid)   );
  $link    =  curl_exec($ch5);
  curl_close($ch5);



  $output=$output."?".$boady."?".$git_data."?".$header."?".$tital."      ".$websight."?type=post_T&postID=.  ".$seachid.$link ;


}





$here="1";
if ($tital!=""){


  $here="done";
  $sql="INSERT INTO `post_".$sitename."` (`fild_id`, `user`, `views`, `views_this_mouth`, `tital`, `type`, `header`, `boady`, `linked`, `sorce`, `upvote`, `downvote`, `buypage`, `price`, `git_data`, `eamil_data`,`created`) VALUES 


   ('".$random_id."', 
   '".$uname."',
   '0', '0', 
   '".$tital."', 
   '".$type."', 
   '".$header."', 
   '".$boady."', 
   '".$link."', 
   '".$sorce."', 
   '0', '0', ' ".$buy."', 
   '".$price."', 
   '".$git_data."', 
   '".$eamil_data."'
   ,CURRENT_TIMESTAMP); ";
  
  $result = $conn->query($sql);

  header("Location: V5.php?pageid=".$random_id."");
}


/*
  CREATE TABLE `treelose_data`.post` (
  `fild_id` VARCHAR(64) NOT NULL , 
  `user` TEXT NOT NULL , 
  `views` INT NOT NULL , 
  `views_this_mouth` INT NOT NULL , 
  `tital` TEXT NOT NULL , 
  'type' TEXT NOT NULL,
  `header` TEXT NOT NULL , 
  `boady` TEXT NOT NULL , 
  `linked` TEXT NOT NULL , 
  `sorce` TEXT NOT NULL , 
  `upvote` INT NOT NULL , 
  `downvote` INT NOT NULL, 
  `buypage` BOOLEAN not Null, 
  `price` FLOAT not Null, 
  `git_data` Text not Null, 
  `eamil_data` Text not NUll,
  PRIMARY KEY (fild_id) ) ENGINE = MyISAM
*/
//$result = $conn->query($sql);





//INSERT INTO `treelose_data` (`user`, `postid`, `board`, `ban_type`) VALUES ('thiz_user', '12911', 'bord1', 'type1');






?>




<!DOCTYPE html>
<html>
<head>
    
    <link rel="stylesheet" href="auth.css" />
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https:  //fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    
    <title>POST PAGE</title>
</head>

<body class="body">
    
    <section class="login-box">
        <?php
            echo "<div class='errormsg'>
                    ".$output."
                </div>";
        ?>
        <div class="form">
            <form action = "" method = "POST" enctype = "multipart/form-data">
                <div>
                    <div class="label">Title</div>
                    <input type="tital" id="tital" name="tital" class="button" value="">
                </div>
                
                <div>
                    <div class="label">Header or Webpage</div>
                    <input type="header" id="header" name="header" class="button" value="">
                </div>
                <div>
                    <div class="label">Body or ID</div>
                    <input type="tital" id="tital" name="tital" class="button" value="">
                </div>
                <div>
                    <div class="label">Source</div>
                    <input type="linked" id="sorce" name="sorce" class="button" value=<?php echo "\"".$_GET["pageid"]."\""; ?> >
                </div>
                <div>
                    <div class="label">Link</div>
                    <input type = "file" name = "image" class="button" />
                </div>
                
                <button type="submit" class="signin">SIGN IN</button>
            </form>
         </div>
    </section>
    
</body>
</html>

