<?php

session_start();
include("web_name.php");
$uname=$_SESSION["uname".$sitename];


if( $_SESSION["logedin".$sitename]==""){
    header("Location: log_in.php?");
}
if ($uname=="") {
  $uname="nobody";
}
include("config.php");
$pageid=$_GET["pageid"];
$seach_item=$_GET["user_seach"];
$type=$_GET["type"];
$combo_type="or_i";
$page_number=$_GET["page_number"] ;
if ($page_number<0) {
    $page_number=0;
}
if ($page_number=="") {
    $page_number=0;
}

$prev_page=$page_number-1;
if ($page_number<0) {
    $page_number=0;

}
$next_page=$next_number+1;
if($pageid==""){
$pageid="%%";
}
if($pageid=="all"){
$pageid="%%";
}
if ($seach_item!="%%") {
    $seach_item="%".$seach_item."%";
}

$page_numberbot=6*$page_number;
$page_numbertop=6*$page_number+6;

if ("%%"==$seach_item) {
    $sql ="SELECT * FROM `post_".$sitename."` WHERE `fild_id` LIKE '".$pageid."' ORDER BY `created`  DESC LIMIT 1;";
}
else{
    $sql="
    SELECT * FROM `post_".$sitename."` WHERE `sorce` 
    LIKE '".$pageid."' 
    AND ( 
    `user` LIKE '".$seach_item."' or 
    `boady` LIKE '".$seach_item."' or 
    `header` LIKE '".$seach_item."' ) ORDER BY `created`  DESC  
     LIMIT 1;";
}

$page_numberbot=$page_numberbot+1;
$page_numbertop=$page_numbertop+1;

$result = $conn->query($sql);
$heading_div="nodiv";
$input_type="Vpage";

if ($result->num_rows>0) {
    $count=0;
    while($row = $result->fetch_assoc() and $count==0) {
            $header=$row["header"];
            $boady=$row["boady"];
            $type=$row["type"];
            $linked=$row["linked"];
            $downvote=$row["downvote"];
            $tital=$row["tital"];
            $views=$row["views"];
            $views_this_mouth=$row["views_this_mouth"];
            $buypage=$row["buypage"];
            $poster=$row["user"];
            $sorce_H=$row["sorce"];
            $diplayed_page=$row["fild_id"];
            $count+=1;           
        }
        $sorce_HH=$sorce_H;
        if ($sorce_H=="%%") {
            $sorce_H="the main page";
        }
        $pageidH=$pageid;
        if ($pageid=="%%") {
            $pageidH="the main page";
        }
        
        $side_div = "
            <div><div class=\"label\">Page sorce</div> <div>".$sorce_H."</div>
            </div>
            <div><div class=\"label\">Page ID</div> <div>".$pageidH."</div> </div>
            <div><div class=\"label\">Poster</div> <div>".$poster."</div> </div>
            <div><div class=\"label\">Title</div> <div>".$tital."</div> </div>
            <div><div class=\"label\">Header</div> <div>".$header."</div> </div>
            <div><div class=\"label\">Body</div> <div>".$boady."</div> </div>
        ";
        
        $heading_div="
            <div class=\"post\">
                <div class=\"post-image\"><img src=\"".$linked."\"></div>
                <div class=\"post-info\">
                    <div class=\"displayed\">".$diplayed_page."</div>
                    <div class=\"action\">
                        <div onclick=\"window.location.href='V5.php?pageid=".$diplayed_page." ';\"><i class=\"icon-external-link\"></i><div class=\"label\">Go To Page</div></div>
                        <div onclick=\"window.location.href='V5.php?pageid=".$sorce_HH." ';\"><i class=\"icon-link\"></i><div class=\"label\">Source</div></div>
                        <div onclick=\"window.location.href='post_page2.php?pageid=".$diplayed_page." ';\"><i class=\"icon-reply\"></i><div class=\"label\">Reply</div></div>
                    </div>
                </div>
            </div>
        ";
}
$result = $conn->query($sql_view);
$result = $conn->query($sql_view_M);

$page_numberbot=6*$page_number;
$page_numbertop=6*$page_number+6;


$sql2="
    SELECT * FROM `post_".$sitename."` WHERE `sorce` 
    LIKE '".$pageid."' 
    AND ( 
    `user` LIKE '".$seach_item."' or 
    `boady` LIKE '".$seach_item."' or 
    `header` LIKE '".$seach_item."' ) ORDER BY `created`  DESC  
    LIMIT ".$page_numberbot." ,".$page_numbertop.";";
$array = array();
$result = $conn->query($sql2);

if ($result->num_rows>0) {
    while($row = $result->fetch_assoc()) {
    $C_user =$row["user"];
    $C_tital=$row["tital"];
    $content="<img class=\"img-fluid\" src=\"imgs/".$row["fild_id"]."\">";
    $C_header=$row["header"];
    $button="<button style=\"float: right;\" onclick=
    \"window.location.href= 'V3.php?page    id=".$row["fild_id"]." ' ;\"  >go to page</button>";
    $content="<img src=\"".$row["linked"]."\" style=\"width: 180px; height:110px; \">";

    $outputdivs=
        "
            <div class=\"post\">
                <div class=\"user-info\"><div class=\"user-image\"><i class=\"icon-user1\"></i></div><div class=\"username\">".$row["user"]."</div></div>
                <div class=\"post-image\"><img src=\"".$row["linked"]."\"></div>
                <div class=\"info2\">
                    <div class=\"title\">".$row["tital"]."</div>
                    <div class=\"header\">".$row["header"]."</div>
                    <div class=\"action\">
                        <div onclick=\"window.location.href='V5.php?pageid=".$row["fild_id"]." ';\"><i class=\"icon-external-link\"></i><div class=\"label\">Go To Page</div></div>
                        <div onclick=\"window.location.href='V5.php?pageid=".$row["sorce"]." ';\"><i class=\"icon-link\"></i><div class=\"label\">Source</div></div>
                        <div onclick=\"window.location.href='post_page2.php?pageid=".$row["fild_id"]." ';\"><i class=\"icon-reply\"></i><div class=\"label\">Reply</div></div>
                    </div>
                </div>
            </div>
        ";
        if ($diplayed_page==$row["fild_id"]){

            $outputdivs="";
        }



    


    array_push($array, $outputdivs);
    }
    

}
$outputdiv=$array;
?>

<html>
    <head>
        <link rel="stylesheet" href="fonts/style.css">
        <link href="https:  //fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
        
        <style type="text/css">
            *{
                font-family: 'montserrat';
                margin: 0px;
            }
            img{
                width: 100%;
            }
            body{
                background: rgba(0, 0, 0, 0.987);
            }
            header{
                position: fixed;
                top: 0%;
                width: 90%;
                padding: 0% 5%;
                height: 70px;
                display: flex;
                align-items: center;
                background: rgb(0, 194, 194);
            }
            div.logo{
                color: black;
                font-size: 200%;
                font-weight: 900;
            }
            form.search{
                margin-left: auto;
                display: flex;
                width: 20%;
                height: 60%;
                border-radius: 5px;
                overflow: hidden;
                border: 2px solid black;
            }
            form.search input{
                width: 80%;
                border: none;
                background: none;
                padding: 0% 5%;
                outline: none;
                color: white;
            }
            form.search input::placeholder{
                color: white;
            }
            form.search button{
                width: 20%;
                background: none;
                color: white;
                border: none;
            }
            section{
                margin-top: 70px;
                color: white;
                display: flex;
                padding: 4% 5% 5% 3%;
            }
            div.parent{
                width: 65%;
                overflow: hidden;
                padding: 0% 2%;
            }
            div.parent > div.post{
                border: 1px solid white;
                background: white;
                margin-bottom: 5%;
                width: 80%;
                border-radius: 10px;
                overflow: hidden;
            }
            div.parent > div.post > div.post-info{
                border-top: 1px solid lightgrey;
                display: flex;
                justify-content: space-between;
                padding: 1% 2%;
            }
            div.post-info div.displayed{
                background: lightgrey;
                color: black;
                display: flex;
                align-items: center;
                height: 40px;
                padding: 0% 5%;
                border-radius: 5px;
                font-weight: 700;
                font-size: 90%;
            }
            div.action{
                margin: auto 0%;
                color: black;
                width: 30%;
                display: flex;
                justify-content: space-between;
                padding: 5px 0%;
            }
            div.action > div{
                padding: 0% 5px;
                cursor: pointer;
            }
            div.action > div:last-child{
                border-right: none;
            }
            div.action div.label{
                font-size: 80%;
                font-weight: 600;
            }
            div.post>div.user-info{
                border-bottom: 1px solid lightgrey;
                color: black;
                height: 55px;
                display: flex;
                align-items: center;
                padding: 0% 1%;
                font-size: 110%;
                font-weight: 700;
            }
            div.post div.user-image{
                border: 1px solid black;
                display: flex;
                align-items: center;
                justify-content: center;
                border-radius: 50%;
                width: 40px;
                height: 40px;
                font-size: 150%;
                font-weight: 700;
            }
            div.post div.username{
                margin-left: 1%;
            }
            div.info2{
                width: 100%;
                color: black;
                padding: 0% 1%;
            }
            div.info2 > div.title{
                font-size: 180%;
                text-transform: capitalize;
                padding: 1% 0%;
            }
            div.info2 > div.action{
                width: 98% !important;
                margin: 2% 0% 0%;
                border-top: 1px solid lightgrey;
            }
            
            div.sidebar{
                width: 20%;
                padding: 0% 2%;
                margin-left: 5%;
            }
            div.sidebar div.content{
                border-radius: 15px;
                padding: 0px 5px;
                border: 1px solid white;
                background: white;
                color: black;
            }
            div.sidebar div.content > div{
                border-top: 1px solid lightgrey;
                padding: 5px;
            }
             div.sidebar div.content > div:nth-child(1){
                border-top: none;
            }
            div.sidebar div.content div.label{
                font-weight: 700;
                font-size: 90%;
                padding: 0%;
            }
            div.sidebar div.content div{
                font-weight: 500;
                font-size: 100%;
                padding: 4%;
            }
            div.search-box{
                border: 1px solid white;
                margin-top: 10%;
                padding: 4%;
                border-radius: 20px;
                background: white;
            }
            div.box-title{
                font-weight: 700;
                margin: 5% 0%;
                color: rgb(0, 194, 194);
            }
            div.search-box form {
                padding: 0% 5%;
            }
            div.search-box form div.label{
                font-size: 80%;
                font-weight: 600;
                padding: 2%;
                color: black;
            }
            div.search-box form div input{
                border: 1px solid lightgrey;
                padding: 4%;
                width: 100%;
                border-radius: 5px;
            }
            div.search-box form button{
                width: 100%;
                margin-top: 5%;
                padding: 5% 0%;
                font-weight: 700;
                background: rgb(42, 100, 100);
                border: none;
                color: white;
                border-radius: 5px;
            }
            
            div.bottom-nav{
                width: 76%;
                border: 1px solid white;
                background: white;
                color: black;
                border-radius: 30px;
                height: 70px;
                display: flex;
                align-items: center;
                padding: 0% 2%;
            }
            div.bottom-nav div.nav{
                display: flex;
                height: 60%;
                width: 15%;
                border-radius: 30px;
                box-shadow: 0px 0px 3px 3px lightgrey;
                overflow: hidden;
                justify-content: space-between;
                align-items: center;
                padding: 5px;
                margin: 0% 5% 0% 0%;
            }
            div.bottom-nav div.nav > div{
                width: 50%;
                height: 100%;
                display: flex;
                justify-content: center;
                align-items: center;
                font-size: 200%;
                font-weight: 800;
                color: rgb(0, 194, 194);
                cursor: pointer;
            }
            
            div.bottom-nav div.reply{
                margin: 0% 0% 0% 5%;
                height: 60%;
                cursor: pointer;
            }
            div.bottom-nav div.reply div.icon{
                font-size: 180%;
                font-weight: 900;
                display: flex;
                justify-content: center;
                align-items: center;
                color: rgb(0, 194, 194);
                
            }
            div.bottom-nav div.reply div.button{
                font-size: 80%;
                font-weight: 700;
                color: grey;
            }
            
            div.bottom-nav div.user{
                margin-left: auto;
                display: flex;
                justify-content: center;
                align-items: center;
            }
            div.bottom-nav div.user div.icon{
                width: 35px;
                height: 35px;
                border: 1px solid black;
                font-size: 130%;
                font-weight: 700;
                border-radius: 50%;
                display: flex;
                justify-content: center;
                align-items: center;
            }
            div.bottom-nav div.user div.username{
                font-weight: 700;
                font-size: 80%;
            }
            div.link{
                width: fit-content;
                margin-top: 2%;
                border-radius: 30px;
                padding: 2%;
                background: rgb(16, 16, 16);
                color: white;
                font-weight: 800;
                font-size: 80%;
            }
        </style>
        
    </head>
    
    <body>

        <header>
            <div class="logo">Simple.</div>
             <form action="" class="search">
                <input class= "serachbox" type="text" id="fname" name="user_seach" id="user_seach" placeholder="Search">    
                <button><i class="icon-search1"></i></button>
            </form>
        </header>
        
        <section>
            <div class="parent">
                <?php echo $heading_div;?>

                <?php 
                    $i = 0;
                    while ($i < count($outputdiv) )
                    {
                        echo $outputdiv[$i];
                        $i++;
                    }
                ?>

                <div class="bottom-nav">
                    
                   <div class="nav">
                        <div class="icon-keyboard_arrow_left arrow" onclick=<?php echo "\"window.location.href='V5.php?pageid=".$pageid."&user_seach=".$seach_item."&page_number=".($page_number-1)."';\" ";?>></div>
                        <div class="icon-keyboard_arrow_right arrow" onclick=<?php echo "\"window.location.href='V5.php?pageid=".$pageid."&user_seach=".$seach_item."&page_number=".($page_number+1)."';\" ";?>></div>
                   </div>
                   
                    <div class="reply" onclick= <?php echo " \"window.location.href='post_page2.php?pageid=".$pageid."' \""?>>
                        <div class="icon-reply_all icon"></div>
                        <div class ="button">Reply Page </div>
                    </div>
                    
                    <div class="reply" onclick= <?php echo " \"window.location.href='admin_page.html' \" "?>>
                        <div class="icon-user icon"></div>
                        <div class ="button">Admin Page </div>
                    </div>
                    
                    <div class="user">
                        <div class="icon-user1 icon"></div>
                        <div class="username"> <?php echo $uname;?> </div>
                    </div>
                    
                </div>

                <div class=link>
                    <?php echo $webpath."datumes.php"; ?>
                </div>

            </div>
            
            <div class="sidebar">
                <div class="content">
                    <?php echo $side_div;?>
                </div>
                
                <div class="search-box">
                    <div class="box-title">Search</div>
                    <form action="">
                        <div>
                            <div class="label">Page</div>
                            <input class= "serachbox" type="text" id="fname" name="pageid" id="pageid" value=<?php echo "\"".$pageid."\""; ?> > 
                        </div>
                        <div>
                            <div class="label">Term</div>
                            <input class= "serachbox" type="text" id="fname" name="user_seach" id="user_seach">
                        </div>
                        
                        <button>SEARCH PAGE</button>
                    </form>
                </div>
            </div>
        </section>
        
        
    </body>
    
</html>
















