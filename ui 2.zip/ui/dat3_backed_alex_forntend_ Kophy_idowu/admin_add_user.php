<?php


session_start();

include("config.php");
include("web_name.php");



$Sight_Pass=$_POST["Sight_Pass"];
$add_user=$_POST["add_user"];
$pass_user=$_POST["pass_user"];


if ($Sight_Pass==$addminpass) {

    $sql="INSERT INTO `user_".$sitename."` (`user`, `payment`, `created`, `email`, 
       `phone number`, `paymentkey`, `pass`, `views`, `view_M`)  VALUES 
       ('".$add_user."', '1', CURRENT_TIMESTAMP, '1', '1', '1', '".$pass_user."', '1', '1')";

$output="true";
    $result = $conn->query($sql);
}
//"DELETE FROM table_name WHERE user like ;"

?>




<!DOCTYPE html>
<html>
<head>
    
    <link rel="stylesheet" href="auth.css" />
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https:  //fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    
    
    <title>ADD USER</title>

<body class="body">
    
   <section class="login-box">
        <?php 
            echo "<div class='errormsg'>
                    ".$output."
                </div>";
        ?>
      
        <div class="form">
           <form action = "" method = "POST" enctype = "multipart/form-data">
                <div>
                    <div class="label">Sight Pass</div>
                    <input type="boady" id="boady" name="Sight_Pass" class="button" value="">
                </div>
                
                <div>
                    <div class="label">User To Add</div>
                    <input type="linked" id="sorce" name="add_user" class="button">
                </div>
                
                <div>
                    <div class="label">User To Pass</div>
                    <input type="linked" id="sorce" name="pass_user" class="button">
                </div>
                
                <button class="signin">SIGN IN</button>
            </form>
        </div>
    </section>


    </form>
    

  </div>
</div>

    
</body>
</html>
