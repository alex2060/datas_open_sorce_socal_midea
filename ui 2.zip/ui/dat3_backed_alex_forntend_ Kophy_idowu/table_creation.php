<?php

include("web_name.php");
include("config.php");
$Sight_Pass=$_POST["Sight_Pass"];

$sql1="CREATE TABLE `post_".$sitename."` (  

`fild_id` VARCHAR(64) NOT NULL 			, 
`user` TEXT NOT NULL 					, 
`views` INT NOT NULL 					, 
`views_this_mouth` INT NOT NULL 		, 
`tital` TEXT NOT NULL 					, 
`type` TEXT NOT NULL  					,
`header` TEXT NOT NULL    				, 
`boady` TEXT NOT NULL     				, 
`linked` TEXT NOT NULL    				, 
`sorce` TEXT NOT NULL     				, 
`upvote` INT NOT NULL     				, 
`downvote` INT NOT NULL   				, 
`buypage` BOOLEAN not Null  			, 
`price` FLOAT not Null 					, 
`git_data` Text not Null 				, 
`eamil_data` Text not NUll 				,
`created` TIMESTAMP NOT NULL 			,  
PRIMARY KEY (fild_id) ) ENGINE = MyISAM ;";

$sql2="CREATE TABLE `user_".$sitename."` (
`user` VARCHAR(100) NOT NULL , 
`payment` TEXT NOT NULL , 
`created` TIMESTAMP NOT NULL , 
`email` TEXT NOT NULL , 
`phone number` TEXT NOT NULL , 
`paymentkey` TEXT NOT NULL , 
`pass` TEXT NOT NULL, 
`views` int NOT NULL,
`view_M` int not NULL,
PRIMARY KEY (user) ) ENGINE = MyISAM";






if ($Sight_Pass==$addminpass) {

$result = $conn->query($sql1);
$result = $conn->query($sql2);
}


$output=$sql1." ";


?>



<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="auth.css" />
        <link rel="preconnect" href="https://fonts.gstatic.com" >
        <link href="https:  //fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    
        <title>TABLE CREATION</title>
    </head>
    <body class="body">
        
        <section class="login-box">
            <div class="form">
                <form action="" method="POST" enctype="multipart/form-data">
                    <div>
                        <div class="label">Sight Pass to make table</div>
                        <input type="boady" id="boady" name="Sight_Pass" class="button" value="">
                    </div>
                    
                    <button class="signin">SIGN IN</button>
                </form>
            </div>
        </section>
    
    </body>
</html>











