<?php
$sitename="alex_5";
$addminpass="passaddmin";
$webpath="http://alexhaussmann.com/adhaussmann/alex/dat3/";
?>