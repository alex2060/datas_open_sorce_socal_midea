

<?php

	$sorce="";
	include("config.php");
	include("web_name.php");
	$type=$_GET['type'];
	$output="none".$type;

	if($type=="login_check"){
		$heashword=$_GET['hashword'];
		$webname=$_GET['webname'];
		$user=$_GET['user'];
		$hash_type=$_GET['hash_type'];
		$sql1 = "SELECT * FROM user_".$sitename." WHERE user LIKE '".$user."';";
		$result = $conn->query($sql1);
		if($result->num_rows==1){
			$val=hash('sha256', $pass.$webname);

			while($row = $result->fetch_assoc() and $count==0) {

				$pass=$row["pass"];

				$val=hash('sha256', $pass.$webname);

			}
			if ($val==$heashword) {

					$output="True";


			}
			else{

					$output="False";

			}
		
		}
		else{

			$output="False".$sql1;

		}
	}
	if($type=="post_B"){

		$postid=$_GET['postID'];
		$output="intypeB".$postid;
		$sql ="SELECT * FROM `post_".$sitename."` WHERE `fild_id` LIKE '".$postid."' LIMIT 1;";
		$count=0;
		$result = $conn->query($sql);
		$output=$output." ".$sql;
		while($row = $result->fetch_assoc() and $count==0) {

			$output=$row["boady"];
			$count+=1;  

		}
	}

	if($type=="post_L"){
		$postid=$_GET['postID'];
		$sql ="SELECT * FROM `post_".$sitename."` WHERE `fild_id` LIKE '".$postid."' LIMIT 1;";
		$count=0;
		$result = $conn->query($sql);
		while($row = $result->fetch_assoc() and $count==0) {

			$output=$webpath.$row["linked"];
			$count+=1;

		}
	}

	if($type=="post_R"){
		$postid=$_GET['postID'];
		$sql ="SELECT * FROM `post_".$sitename."` WHERE `fild_id` LIKE '".$postid."' LIMIT 1;";
		$count=0;
		$result = $conn->query($sql);
		while($row = $result->fetch_assoc() and $count==0) {

			$output=$webpath."V5.php?pageid=".$postid;
			$count+=1;

		}
	}

	if($type=="post_H"){
		$postid=$_GET['postID'];
		$sql ="SELECT * FROM `post_".$sitename."` WHERE `fild_id` LIKE '".$postid."' LIMIT 1;";
		$count=0;
		$result = $conn->query($sql);
		while($row = $result->fetch_assoc() and $count==0) {

			$output=$row["header"];
			$count+=1;
			
		}
	}

	if($type=="post_T"){
		$postid=$_GET['postID'];
		$sql ="SELECT * FROM `post_".$sitename."` WHERE `fild_id` LIKE '".$postid."' LIMIT 1;";
		$count=0;
		$result = $conn->query($sql);
		while($row = $result->fetch_assoc() and $count==0) {

			$output=$row["tital"];
			$count+=1;

		}
	}

	if($type=="post_A"){
		$postid=$_GET['postID'];
		$sql ="SELECT * FROM `post_".$sitename."` WHERE `fild_id` LIKE '".$postid."' LIMIT 1;";
		$count=0;
		$result = $conn->query($sql);
		while($row = $result->fetch_assoc() and $count==0) {

			$output="(??) ".$row["tital"]."(??)".$row["header"]."(??)".$row["boady"]."(??)".$row["linked"];
			$count+=1;

		}
	}


	if($type=="post_2"){
		$postid=$_GET['postID'];
		$sql ="SELECT * FROM `post_".$sitename."` WHERE `fild_id` LIKE '".$postid."' LIMIT 1;";
		$count=0;
		$result = $conn->query($sql);
		while($row = $result->fetch_assoc() and $count==0) {

			$output=$webpath."V5.php?pageid=".$postid;
			$count+=1;
		}
	}

	echo $output;
?>




















