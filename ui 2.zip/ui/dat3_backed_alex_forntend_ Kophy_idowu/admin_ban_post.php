<?php
session_start();

include("config.php");
include("web_name.php");
$Sight_Pass=$_POST["Sight_Pass"];
$baned_post=$_POST["baned_post"];

if ($Sight_Pass==$addminpass) {
  $sql= "DELETE FROM  post_".$sitename." WHERE fild_id = '".$baned_post."'; ";
    $output="true";
    $result = $conn->query($sql);
}
?>



<!DOCTYPE html>
<html>
<head>
    
    <link rel="stylesheet" href="auth.css" />
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https:  //fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    
    
    <title>BAN POST</title>


<body class="body">
    
   <section class="login-box">
        <?php 
            echo "<div class='errormsg'>
                    ".$output."
                </div>";
        ?>
      
        <div class="form">
            <form action = "" method = "POST" enctype = "multipart/form-data">
                <div>
                    <div class="label">User To Pass</div>
                    <input type="boady" id="boady" name="Sight_Pass" class="button" value="">
                </div>
                <div>
                    <div class="label">Post To Ban</div>
                    <input type="linked" id="sorce" name="baned_post" class="button"  >
                </div>
                
                <button class="signin">SIGN IN</button>
            </form>
        </div>
    </section>
</div>

    
</body>
</html>




