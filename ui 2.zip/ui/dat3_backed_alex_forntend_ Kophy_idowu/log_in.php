<?php 
session_start();
include("config.php");
include("web_name.php");


$output="";
$uname=$_GET["uname"];
$password2=$_GET["password"];


$hash=$_GET["hash"];
$web=$_GET["web"];



$webid="alex_websight";


if ($web!="") {


$Websights = array(
  "http://alexhaussmann.com/adhaussmann/alex/dat2/datumes.php",
  "http://alexhaussmann.com/adhaussmann/alex/dat3/datumes.php",
  "this");

$names = [
    'http://alexhaussmann.com/adhaussmann/alex/dat2/datumes.php' => "-1",
    'http://alexhaussmann.com/adhaussmann/alex/dat3/datumes.php' => "-2"
];



if(in_array($web, $Websights)){
  #$output="good";
  $val=hash('sha256', $password2.$webid);
  $make=$web."?webname=".$webid."&type=login_check&user=".$uname."&hashword=".$val;
  $ch1 = curl_init();
  curl_setopt($ch1, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt ($ch1, CURLOPT_VERBOSE,TRUE);
  curl_setopt($ch1, CURLOPT_URL,    str_replace(' ', '', $make)   );
  $test1 =  curl_exec($ch1);
  curl_close($ch1);


  $make=$web."?webname=".$webid."&type=login_check&user=".$uname."&hashword=".$val;
  $ch1 = curl_init();
  curl_setopt($ch1, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt ($ch1, CURLOPT_VERBOSE,TRUE);
  curl_setopt($ch1, CURLOPT_URL,  str_replace(' ', '', $make)   );
  $test2 =  curl_exec($ch1);
  curl_close($ch1);
  $output=$test1.$test2;

  if (strpos($output, 'T') !== false) {


      $_SESSION["uname".$sitename  ]=$uname.$names[$web];
      $_SESSION["logedin".$sitename]="True";
      header("Location: V5.php");
      $output="loged in as11 ".$uname." ".$make." ".$test2." ".$test1." in ture";
  }
  else{

      $_SESSION["uname".$sitename  ]=$uname.$names[$web];
      $_SESSION["logedin".$sitename]="True";
      #header("Location: V5.php");
      $output="loged in as ".$uname." ".$make." ".$test2." ".$test1;

  }


}
else{
  $output="websight not suported";
}



}
else{

  $sql1 = "SELECT * FROM user_".$sitename." WHERE user LIKE '".$uname."' and pass LIKE '".$password2."';";

  $result = $conn->query($sql1);

  if ($uname!="") {


  	if($result->num_rows==1){
  		$_SESSION["uname".$sitename]=$uname;
      $_SESSION["logedin".$sitename]="True";
  		header("Location: V5.php");
  		$output="loged in as ".$uname." ";
  	}



  	else{
  		$output="not loged in";
  	}



  }

  $uname=$_SESSION['uname'];
  if ($uname=="") {
    $uname="nobody";
    echo $row["boady"];

    
  }

}




/*
if ($result->num_rows!=0){
  	$_SESSION['uname']
  	$output="loged in as".$uname."here";
}
$output="wrong user name of password ";
/*
CREATE TABLE `treelose_data`.`__users` (
 `user` VARCHAR(100) NOT NULL , 
 `payment` TEXT NOT NULL , 
 `created` TIMESTAMP NOT NULL , 
 `email` TEXT NOT NULL , 
 `phone number` INT NOT NULL , 
 `paymentkey` TEXT NOT NULL , 
 `pass` TEXT NOT NULL, 
 PRIMARY KEY (user) ) ENGINE = MyISAM
*/

?>



<!DOCTYPE html>
<html>
<head>
    
    <link rel="stylesheet" href="auth.css" />
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https:  //fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    
    <title>LOGIN</title>

</head>

<body class="body">
    
    <section class="login-box">
        <div class="logo">Simple.</div>
        <?php
            echo "<div class='errormsg'>
                    ".$output."
                </div>";
        ?>
        <div class="form">
           <form action="log_in.php">
                <div>
                    <div class="label">Username</div>
                    <input type="uname" id="uname" name="uname" class="username" value="">
                </div>
                <div>
                    <div class="label">Password</div>
                    <input type="password" class="password" name="password" value="">
                </div>
                <div>
                    <div class="label">Login Hash</div>
                    <input type="text" id="hash" class="hash" name="hash"  value="">
                </div>
                <div>
                    <div class="label">Login Website</div>
                    <input type="text" id="hash" class="web" name="web" value="">
                </div>
                
                <button class="signin">SIGN IN</button>
            </form>
        </div>
    </section>

</body>
</html>









