<?php

session_start();
$uname=$_SESSION['uname'];

if ($uname=="") {
  $uname="nobody";
}


$servername = "localhost";
$username = "alex_hausssmann";
$password = "treelos_password";
$dbName = "treelose_data";
$conn = new mysqli($servername, $username, $password,$dbName );



//UPDATE video_table SET viewed_count=viewed_count+1 WHERE SELECT * FROM video_table WHERE DATE='today' 
/*
	CREATE TABLE `treelose_data`.`post` (
	`fild_id` VARCHAR(64) NOT NULL , 
	`user` TEXT NOT NULL , 
	`views` INT NOT NULL , 
	`views_this_mouth` INT NOT NULL , 
	`tital` TEXT NOT NULL , 
	`type` TEXT NOT NULL,
	`header` TEXT NOT NULL , 
	`boady` TEXT NOT NULL , 
	`linked` TEXT NOT NULL , 
	`sorce` TEXT NOT NULL , 
	`upvote` INT NOT NULL , 
	`downvote` INT NOT NULL, 
	`buypage` BOOLEAN not Null, 
	`price` FLOAT not Null, 
	`git_data` Text not Null, 
	`eamil_data` Text not NUll,
	`created` TIMESTAMP NOT NULL ,  
	PRIMARY KEY (fild_id) ) ENGINE = MyISAM;
*/





$pageid=$_GET["pageid"];
$uname_S=$_GET["uname"];
$header_S=$_GET["header"];
$seach_item=$_GET["seach_item"];
$type=$_GET["type"];

if ($type=="") {
	$type="or_i";
}

$order_type=$_GET["order_type"];

if ($type=="") {
	$type="order_type";
}
$combo_type=$_GET["combo_type"];

if ($type=="") {
	$type="or_i";
}

if($pageid==""){
$pageid="";

}


if($pageid=="all"){
$pageid="";

}




$sql_view="UPDATE video_table SET views=views+10 WHERE `fild_id` Like ".$pageid."' ;";

$result = $conn->query($sql_view);

$sql_view_M="UPDATE video_table SET views_this_mouth=views_this_mouth+10 WHERE `fild_id` Like ".$pageid."' ;";

$result = $conn->query($sql_view_M);



//outputdiv

$sql ="SELECT * FROM `post` WHERE `fild_id` LIKE '".$pageid."' ;";
$result = $conn->query($sql);



$heading_div="nodiv";

if ($result->num_rows>0) {

while($row = $result->fetch_assoc()) {
    $header=$row["header"];
    $boady=$row["boady"];
    $type=$row["type"];
    $linked=$row["linked"];
    $upvote=$row["upvote"];
    $downvote=$row["downvote"];
    $tital=$row["tital"];
    $views=$row["views"];
    $views_this_mouth=$row["views_this_mouth"];
    $buypage=$row["buypage"];
    $poster=$row["user"];
    $sorce_H=["sorce"];
    
  }


$heading_div="

  tital

  <div class=\"pic\"> </br>


	   </div> <div class=\"users\"> nobody</div>   <div class=\"tital\">header 

		</div>
		</br>
		<img style=\"float: right; padding: 0px 3px 0px 0px;\"

		src=\"".$linked."\" 
		alt=\"Girl in a jackets
		\" width=\"400\" height=\"200\"> 

		boady
		</br> 
		</br> 
		</br>
		</br>
		</br>
		</br>
		</br>
		</br>
		</br>
		</br>
		</br>  ".



   
   "<button type=\"button\"  
  onclick=\"window.location.href='http://alexhaussmann.com/adhaussmann/dataums/upload/upload_file.php';\"
   >upload</button> 
   <button type=\"button\"  
  onclick=\"window.location.href='http://alexhaussmann.com/adhaussmann/dataums/post_page/post_page.php';\"
   >make post</button> 
   <button type=\"button\"  
  onclick=\"window.location.href='http://alexhaussmann.com/adhaussmann/dataums/board_folader/bord_search.php';\"
   >seach board</button> 
   <button type=\"button\"  
  onclick=\"window.location.href='http://alexhaussmann.com/adhaussmann/dataums/post_page/post_page.php';\"
   >seach posts</button> 
   <button type=\"button\"  
  onclick=\"window.location.href='http://alexhaussmann.com/adhaussmann/dataums/board_folader/post_bord.php';\"
   >make bord</button> ";


}




$tops="  ORDER BY `created` DESC ";

$hots="  ORDER BY `views` ASC ";

$sort=$hots;
$sql2="";

if ($combo_type=="and_i" or $combo_type=="or_i") {
	$uname_S="%".$uname_S."%";
	$header_S="%".$header_S."%";
	$seach_item="%".$seach_item."%";
}
if ($combo_type=="and_e" or $combo_type=="or_e") {
	if ($uname_S="") {
		$uname_S="%%";
	}
	if ($header_S="") {
		$header_S="%%";
	}
	if ($seach_item="") {
		$seach_item="%%";
	}
}

if ($pageid=="all") {
	$pageid="%%";
}

$sql2="SELECT * FROM `post` WHERE `sorce` LIKE '".$pageid."' " ;

if ($combo_type=="and_e" or $combo_type=="and_i") {	
	$useach=" AND `user` LIKE '".$uname_S."' ";
	$item_seach=" AND `boady` LIKE '".$seach_item."' ";
	$header_seach=" AND `header` LIKE '".$header_S."' ";
	$sql2=$sql2.$useach.$item_seach.$header_seach;
	$sql2=$sql2;
}
if ($combo_type=="or_e" or $combo_type=="or_i") {
	$useach=" AND ( `user` LIKE '".$uname_S."' ";
	$item_seach=" or `boady` LIKE '".$seach_item."' ";
	$header_seach=" or `header` LIKE '".$header_S."' ) ";
	$sql2=$sql2.$useach.$item_seach.$header_seach;
	$sql2=$sql2;
}
$page_numberbot=0;
$page_numbertop=6;
$end="LIMIT ".$page_numberbot." ,".$page_numbertop.";";
$sql2=$sql2.$hots.$end;
$outputdiv   =array("0","1","2","3","4","5","6");
$result = $conn->query($sql2);
$count=0;
$good="";
if ($result->num_rows>0) {
	$good="we good";
   while($row = $result->fetch_assoc()) {
		
		$outputdiv[$count]="
		<img class=\"viewimg\" src=\"".$row["linked"]."\" alt=\"Girl in a jacket\" width=\"200\" height=\"200\"> 
		".$row["header"]."    ".$row["user"]." </br> ".$row["tital"]." _ ";

		$outputdiv[$count]=$outputdiv[$count]." _ "." _ ".$row["user"];
		$outputdiv[$count]=$outputdiv[$count]." _ <button class= \"buttonkk\" onclick=\"window.location.href= 
		'http://alexhaussmann.com/adhaussmann/dataums/post_page/viewpage.php?pageid=".$row["fild_id"]." '; \"> </button>";
		

		$outputdiv[$count]=$outputdiv[$count]."
		";


		$C_tital=$row["tital"];		


		$C_user=$row["user"];

		$C_header=$row["header"];





		$outputdiv[$count]= "
		<div class = \"textbody\">
			<div class =\"comnet_header\">
			".$C_tital."
			</br>
				<div class =\"user_header\">
					".$C_user."
				</div>
			</div>
			<div class =\"body_header\">
			  ".$C_header."
			  </br>
			</br>
		</br>
		</br>
		</br>
		<button class= \"buttonkk\" onclick=\"window.location.href= 
		'http://alexhaussmann.com/adhaussmann/dataums/post_page/viewpage.php?pageid=".$row["fild_id"]." '; \"> </button>
			</div>


		</div>
		
		<div class=\"viewimg\" >
	





		<img   src=\"http://alexhaussmann.com/adhaussmann/dataums/post_page/im/".$row["fild_id"]."\" alt=\"Girl in a jacket\" width=\"205\" height=\"205\"> 





		</div>";

	$count=$count+1;

	}


}

?>




<!DOCTYPE html>
<html>
<head>
<style>
body {
  background-image: url('https://wallpapercave.com/wp/8Ktr9Qn.jpg');
}

.phote{
width: 800px;
border: 5px solid gray;
background-image: url('https://metal.graphics/files/matte/matte-black-background.jpg');
color: rgb(255,255,255);


}

.header{
	width: 790px;

	font-size: 20px;
	color: rgb(255,255,255);
	border: 5px solid gray;
}

.header__1{	
	width: 790px;
	font-size: 30px;
	color: rgb(255,255,255);
	border: 5px solid gray;
}


.textbox{
	width: 790px;
	font-size: 20px;
	color: rgb(255,255,255);
	border: 5px solid gray;
	padding: 10px;
}

.nextthing{
	width: 790px;

	font-size: 20px;
	color: rgb(255,255,255);
	border: 5px solid gray;
}

.body_top{
	width: 790px;
font-size: 30px;
	font-size: 10px;
	color: rgb(255,255,255);
	border: 5px solid gray;
}


.viewimg{
	text-align:right;


}


.tital{
font-size: 30px;
}


.users{
font-size: 15px;
}


.upvote{

	font-size: 15px
}
.pic{
	float: right;

}

.postHead{

	font-size: 25px;
}


.buttonkk { 
height: 20px; 
width: 20px; 



} 

.comnet_header{
	font-size: 35px;
	border: 5px solid gray;
	width: 571px;

	text-overflow: ellipsis;
}

.body_header{
	font-size: 20px;
	border: 5px solid gray;
	width: 571px;

}

.textbody{
	float: left;
	width: auto;

}


.user_header{
	font-size: 15px;

}


</style>
</head>
<body>

<div class = "phote">
viewpage
  <div class = "header">
  <?php echo $heading_div;?>




</div>


</div>

<div class = "body_top">


<form>
	<label for="fname">user_seach</label>
	<input type="text" id="user_seach" name="user_seach">
	<label for="lname">header</label>
	<input type="text" id="header" name="header">
	<label for="lname">boady_seach</label>
	<input type="text" id="boady_seach" name="boady_seach">
	<label for="lname">seach_item</label>
	<input type="text" id="seach_item" name="seach_item">

	<label for="lname">seach_page</label>
	<input type="text" id="pageid" name="pageid" value=<?php echo "\"".$pageid."\""?>>
   

	<select name="combo_type" id="type">

		  <option value="or_e">or exclusive</option>

		  <option value="and_e">and exclusive</option>

		  <option value="or_i">or inclusive</option>

		  <option value="and_i">and inclusive</option>

	</select>


	<select name="order_type" id="type">

	  <option value="time">time</option>

	  <option value="top">top</option>

	  <option value="hot">hot</option>
  
	</select>


	<input type="submit" value="search form">
</form> 



	</div>




<div class="textbox">
	

	<?php echo $outputdiv[0] ?>


</div>


<div class="textbox">
	<?php echo $outputdiv[1] ?>
</div>


<div class="textbox">
	<?php echo $outputdiv[2] ?>
</div>



<div class="textbox">
	<?php echo $outputdiv[3] ?>
</div>



<div class="textbox">
	<?php echo $outputdiv[4] ?>
</div>


<div class="textbox">
	<?php echo $outputdiv[5] ?>
</div>




<div class="nextthing">

   <button type="button"  
  onclick="window.location.href='http://alexhaussmann.com/adhaussmann/dataums/upload/upload_file.php';"
   >next</button> 


 <button type="button"  
  onclick="window.location.href='http://alexhaussmann.com/adhaussmann/dataums/upload/upload_file.php';"
   >previose</button> 

  


	upvote downvote


	 <button type="button"  
  onclick=<?php echo "\"window.location.href='http://alexhaussmann.com/adhaussmann/dataums/post_page/post_page_F.php?sorce=".$pageid."';\"";?>
   
   >post reply</button> 
   
	


	 <button type="button"  
  onclick= <?php echo "\"window.location.href='http://alexhaussmann.com/adhaussmann/dataums/board_folader/post_to_bord.php?post_id=".$pageid."';\"";?>
   >post to bord</button> 




	post to bord



    
    </br>
</div>

<div class="textbox">
   

user : <? echo $uname; ?>


</div>

</div>





<?php echo $sql.$uname; ?>


</br>
<?php echo $sql2;?>

</body>
</html>



















