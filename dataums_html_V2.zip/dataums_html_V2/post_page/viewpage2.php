<?php

session_start();
$servername = "localhost";
$username = "alex_hausssmann";
$password = "treelos_password";
$dbName = "treelose_data";
$conn = new mysqli($servername, $username, $password,$dbName );


//UPDATE video_table SET viewed_count=viewed_count+1 WHERE SELECT * FROM video_table WHERE DATE='today' 

/*


	CREATE TABLE `treelose_data`.`post` (
	`fild_id` VARCHAR(64) NOT NULL , 
	`user` TEXT NOT NULL , 
	`views` INT NOT NULL , 
	`views_this_mouth` INT NOT NULL , 
	`tital` TEXT NOT NULL , 
	`type` TEXT NOT NULL,
	`header` TEXT NOT NULL , 
	`boady` TEXT NOT NULL , 
	`linked` TEXT NOT NULL , 
	`sorce` TEXT NOT NULL , 
	`upvote` INT NOT NULL , 
	`downvote` INT NOT NULL, 
	`buypage` BOOLEAN not Null, 
	`price` FLOAT not Null, 
	`git_data` Text not Null, 
	`eamil_data` Text not NUll,
	`created` TIMESTAMP NOT NULL ,  
	PRIMARY KEY (fild_id) ) ENGINE = MyISAM;


*/
$pageid=$GET["pageid"];
$uname=$GET["uname"];
$header=$GET["header"];
$seach_item=$GET["seach_item"];
$type=$GET["type"];

//$sql1 ="SELECT * FROM `post` WHERE `fild_id` LIKE '".pageid."' ";
//$result = $conn->query($sql);


//outputdiv


$heading_div="";


if ($result->num_rows>0) {

while($row = $result->fetch_assoc()) {
    $header=$row["header"];
    $boady=$row["boady"];
    $type=$row["type"];
    $linked=$row["linked"];
    $upvote=$row["upvote"];
    $downvote=$row["downvote"];
    $tital=$row["tital"];
    $views=$row["views"];
    $views_this_mouth=$row["views_this_mouth"];
    $buypage=$row["buypage"];

  }
}

$heading_div="header ".$header." boady".$boady." type".$type." linked".$linked." upvote".$upvote;

$heading_div=$_ing_div." downvote".$downvote." tital".$tital." views".$views." views_this_mouth".$views_this_mouth." buypage".$buypage;



/*

if ($board_name=="") {
	if ($flag1==""){
		if ($flag2==""){
			//all null
			$sql1 = "SELECT * FROM products WHERE product_name LIKE '%".$search."%' and this LIKE "that" ";
		}
		//null but flag2
		$sql1 = "SELECT * FROM products WHERE product_name LIKE '%".$search."%' and this LIKE "that" ";
	}
	else{
		if ($flag2==""){
			//all null but flag1
			$sql1 = "SELECT * FROM products WHERE product_name LIKE '%".$search."%' and this LIKE "that" ";
		}			
		//all null but flag1 and 2
		$sql1 = "SELECT * FROM products WHERE product_name LIKE '%".$search."%' and this LIKE "that" ";
		}
	}
}

else{
	
	if ($flag1==""){
		if ($flag2==""){
			//all null
			$sql1 = "SELECT * FROM products WHERE product_name LIKE '%".$search."%' and this LIKE "that" ";
		}
		//null but flag2
		$sql1 = "SELECT * FROM products WHERE product_name LIKE '%".$search."%' and this LIKE "that" ";
	}
	else{
		if ($flag2==""){
		//all null but flag1
		$sql1 = "SELECT * FROM products WHERE product_name LIKE '%".$search."%' and this LIKE "that" ";
		}			
		//all null but flag1 and 2
		$sql1 = "SELECT * FROM products WHERE product_name LIKE '%".$search."%' and this LIKE "that" ";
		}
	}
}



$outputdiv   =array("0","1","2","3","4","5","6");
$count=0;
if ($result->num_rows>0) {
   while($row = $result->fetch_assoc()) {

    $outputdiv="".$row["user"]." ".$row["owner"]." ".$row["header"]." ".$row["type"]." "."linked";

    count=count+1;

}










*/







?>




<!DOCTYPE html>
<html>
<head>
<style>
body {
  background-image: url('https://wallpapercave.com/wp/8Ktr9Qn.jpg');
}
.phote{
width: 800px;
border: 5px solid gray;
background-image: url('https://metal.graphics/files/matte/matte-black-background.jpg');
color: rgb(255,255,255);


}

.header{
	width: 790px;

	font-size: 20px;
	color: rgb(255,255,255);
	border: 5px solid gray;
}


.textbox{
	width: 790px;

	font-size: 20px;
	color: rgb(255,255,255);
	border: 5px solid gray;
}

.nextthing{
	width: 790px;

	font-size: 20px;
	color: rgb(255,255,255);
	border: 5px solid gray;
}

.body_top{
	width: 790px;
font-size: 30px;
	font-size: 10px;
	color: rgb(255,255,255);
	border: 5px solid gray;
}

</style>
</head>
<body>

<div class = "phote">

<div class = "header">
<h2>datums home page</h2>

 <button type="button"	
onclick="window.location.href='https://www.w3docs.com';"

 >upload</button> 

 <button type="button"	
onclick="window.location.href='https://www.w3docs.com';"

 >make post</button> 



 <button type="button"	
onclick="window.location.href='https://www.w3docs.com';"

 >seach board</button> 


 <button type="button"	
onclick="window.location.href='https://www.w3docs.com';"

 >seach posts</button> 



 <button type="button"	
onclick="window.location.href='https://www.w3docs.com';"

 >make bord</button> 
</div>

<div class = "body_top">


 <form>
  <label for="fname">user_seach</label>
  <input type="text" id="fname" name="fname">
  <label for="lname">header</label>
  <input type="text" id="header" name="lname">
  <label for="lname">boady_seach</label>
   <input type="text" id="boady_seach" name="lname">
   <label for="lname">seach_item</label>
   <input type="text" id="seach_item" name="lname">
   

<select name="cars" id="type">
  <option value="volvo">recent</option>
  <option value="saab">votes</option>
  <input type="submit" value="search form">
</select>

</form> 



	</div>

<div class="textbox">
	<?php echo $heading_div;?>
</div>



<div class="textbox">
	post1
</div>


<div class="textbox">
	post2
</div>


<div class="textbox">
	post3
</div>



<div class="textbox">
	post4
</div>



<div class="textbox">
	post5
</div>


<div class="textbox">
	post6
</div>




<div class="nextthing">

	next.   
	previose.   
	submit upvote downvote</br>
</div>

</div>

<?php echo $_SESSION["uname"]; ?>;

its
</body>
</html>



















