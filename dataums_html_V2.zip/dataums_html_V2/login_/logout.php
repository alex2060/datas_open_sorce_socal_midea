<?
session_start();
$_SESSION['uname'] = "";




?>

your loged out