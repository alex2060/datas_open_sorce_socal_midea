<?php 
session_start();


$servername = "localhost";
$username = "alex_hausssmann";
$password = "treelos_password";
$dbName = "treelose_data";
$conn = new mysqli($servername, $username, $password,$dbName );



$output="";
$uname=$_GET["uname"];
$password2=$_GET["password"];

$sql1 = "SELECT * FROM user_T WHERE user LIKE '".$uname."' and pass LIKE '".$password2."';";

$result = $conn->query($sql1);
if ($uname!="") {

if($result->num_rows==1){
	$_SESSION['uname']=$uname;
	header("Location: http://alexhaussmann.com/adhaussmann/dataums/post_page/viewpage.php");
	$output="loged in as ".$uname." " ;
}
else{
	$output="not loged in";
}
	# code...
}




/*
if ($result->num_rows!=0){
	$_SESSION['uname']
	$output="loged in as".$uname."here";
}

$output="wrong user name of password ";



/*
CREATE TABLE `treelose_data`.`__users` (
 `user` VARCHAR(100) NOT NULL , 
 `payment` TEXT NOT NULL , 
 `created` TIMESTAMP NOT NULL , 
 `email` TEXT NOT NULL , 
 `phone number` INT NOT NULL , 
 `paymentkey` TEXT NOT NULL , 
 `pass` TEXT NOT NULL, 
 PRIMARY KEY (user) ) ENGINE = MyISAM
*/



?>
<html>
<head>
<style>
body {
  background-image: url('https://wallpapercave.com/wp/8Ktr9Qn.jpg');
}
.phote{
width: 800px;
border: 5px solid gray;
background-image: url('https://metal.graphics/files/matte/matte-black-background.jpg');
color: rgb(255,255,255);


}

.header{
	width: 790px;

	font-size: 20px;
	color: rgb(255,255,255);
	border: 5px solid gray;
}


.textbox{
	width: 790px;

	font-size: 20px;
	color: rgb(255,255,255);
	border: 5px solid gray;
}

.nextthing{
	width: 790px;

	font-size: 20px;
	color: rgb(255,255,255);
	border: 5px solid gray;
}

.body_top{
	width: 790px;
font-size: 30px;
	font-size: 10px;
	color: rgb(255,255,255);
	border: 5px solid gray;
}

</style>
</head>
<body>

<div class = "phote">

<div class = "header">
<h2>login</h2>

 <button type="button"	
onclick="window.location.href='https://www.w3docs.com';"

 >upload</button> 

 <button type="button"	
onclick="window.location.href='https://www.w3docs.com';"

 >make post</button> 



 <button type="button"	
onclick="window.location.href='https://www.w3docs.com';"

 >seach board</button> 


 <button type="button"	
onclick="window.location.href='https://www.w3docs.com';"

 >seach posts</button> 



 <button type="button"	
onclick="window.location.href='https://www.w3docs.com';"

 >make bord</button> 
</div>

<div class = "body_top">


expalination



	</div>


<form action="log_in2.php">
  <label for="login">uname</label><br>
  <input type="uname" id="uname" name="uname" value=""><br>
  <label for="login">password</label><br>
  <input type="password" id="password" name="password" value=""><br>
  <input type="submit" value="Submit">
</form> 



</div>
<?php echo $output;?>
<br>

<?php echo $sql1;?>
next
<?php 

while($row = mysql_fetch_array($result)) {
    print_r($row); 
}

?>

</body>
</html>




