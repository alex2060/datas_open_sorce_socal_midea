<?

session_start();

$servername = "localhost";
$username = "alex_hausssmann";
$password = "treelos_password";
$dbName = "treelose_data";
$conn = new mysqli($servername, $username, $password,$dbName );



$uname=$_GET["uname"];
$password=$_GET["password"];
$payment=$_GET["payment"];
$paymentkey=$_GET["paymentkey"];
$email=$_GET["email"];
$phone=$_GET["phone"];


/*
if no uname
$_SESSION['uname']=$uname;

*/


$sql1 = "SELECT * FROM user_T WHERE user LIKE '.".$uname."' and password LIKE '".$password."';";

$result = $conn->query($sql);
if($result->num_rows==1){
  $_SESSION['uname']=$uname;
  
  $sql="INSERT INTO `user_T` (`user`, `payment`, `created`, `email`, `phone number`, `paymentkey`, `pass`, `views`, `view_M`) VALUES 
  ('".$uname."', '".$payment."', CURRENT_TIMESTAMP, '".$email."', '".$phone."', '".$paymentkey."', '".$password."', '0', '0');";

  $result = $conn->query($sql);

}
else{
  $output="uname in use";
}




/*
CREATE TABLE `treelose_data`.`user_T` (
 `user` VARCHAR(100) NOT NULL , 
 `payment` TEXT NOT NULL , 
 `created` TIMESTAMP NOT NULL , 
 `email` TEXT NOT NULL , 
 `phone number` TEXT NOT NULL , 
 `paymentkey` TEXT NOT NULL , 
 `pass` TEXT NOT NULL, 
 `views` int NOT NULL,
 `view_M` int not NULL,
 PRIMARY KEY (user) ) ENGINE = MyISAM
*/

/*
check if unname not in there


if not there add it with password and info into __users

*/



$password=$_GET["password"];





?>



<html>
<head>
<style>
body {
  background-image: url('https://wallpapercave.com/wp/8Ktr9Qn.jpg');
}
.phote{
width: 800px;
border: 5px solid gray;
background-image: url('https://metal.graphics/files/matte/matte-black-background.jpg');
color: rgb(255,255,255);


}

.header{
  width: 790px;

  font-size: 20px;
  color: rgb(255,255,255);
  border: 5px solid gray;
}


.textbox{
  width: 790px;

  font-size: 20px;
  color: rgb(255,255,255);
  border: 5px solid gray;
}

.nextthing{
  width: 790px;

  font-size: 20px;
  color: rgb(255,255,255);
  border: 5px solid gray;
}

.body_top{
  width: 790px;
font-size: 30px;
  font-size: 10px;
  color: rgb(255,255,255);
  border: 5px solid gray;
}

</style>
</head>
<body>

<div class = "phote">

<div class = "header">
<h2>sighn up</h2>

 <button type="button"  
onclick="window.location.href='https://www.w3docs.com';"

 >upload</button> 

 <button type="button"  
onclick="window.location.href='https://www.w3docs.com';"

 >make post</button> 



 <button type="button"  
onclick="window.location.href='https://www.w3docs.com';"

 >seach board</button> 


 <button type="button"  
onclick="window.location.href='https://www.w3docs.com';"

 >seach posts</button> 



 <button type="button"  
onclick="window.location.href='https://www.w3docs.com';"

 >make bord</button> 
</div>

<div class = "body_top">


expalination



  </div>







 <form action="sighnup.php">
  <label for="login">user name</label><br>
  <input type="user name" id="uname" value=""><br>
  <label for="login">password</label><br>
  <input type="password" id="password" value=""><br>

   <label for="login">payment paypal for now</label><br>
  <input type="payment" id="payment" value="paypal"><br>


  <label for="login">paymentkey paypal for public key the way i pay you</label><br>
  <input type="paymentkey" id="paymentkey" value="none"><br>


  <label for="login">e mail if you think you will lose password for now</label><br>
  <input type="e mail" id="email" value="none of your buissness"><br>


  <label for="login">phone if you think you will lose password</label><br>
  <input type="phone" id="phone" value="none of your buissness"><br>
  

  <input type="submit" value="Submit">
</form> 


</div>



</body>
</html>



