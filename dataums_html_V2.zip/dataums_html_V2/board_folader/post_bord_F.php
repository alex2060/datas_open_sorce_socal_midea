<?php 

session_start();
$uname=$_SESSION['uname'];
if ($uname=="") {
  $uname="nobody";
}


$servername = "localhost";
$username = "alex_hausssmann";
$password = "treelos_password";
$dbName = "treelose_data";
$conn = new mysqli($servername, $username, $password,$dbName );



$rules=$_GET["rules"];
$photo_1=$_GET["photo_1"];
$photo_2=$_GET["photo_2"];
$board=$_GET["board"];
$disc=$_GET["disc"];
$flags=$_GET["flags"];




$sql1 ="";

$sql2="121".$board;

if ($photo_1=="") {
	if(isset($_FILES['image'])){
	  $errors= array();
	  $file_name = $_FILES['image']['name'];
	  $file_size = $_FILES['image']['size'];
	  $file_tmp = $_FILES['image']['tmp_name'];
	  $file_type = $_FILES['image']['type'];
	  $file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
	  
	  $extensions= array("jpeg","jpg","png");
	  
	  if(in_array($file_ext,$extensions)=== false){
	     $errors[]="extension not allowed, please choose a JPEG or PNG file.";
	  }
	  if($file_size > 2097152) {
	     $errors[]='File size must be excately 2 MB';
	  }

	  if(empty($errors)==true) {
	     move_uploaded_file($file_tmp,"/imgs/".$uname.time());
	     $output="/imgs/".$uname.time()
	  
	  }else{
	     print_r($errors);
	  }
	}
	# code...
}


if ($photo_2=="") {

	if(isset($_FILES['image2'])){
	  $errors= array();
	  $file_name = $_FILES['image2']['name'];
	  $file_size = $_FILES['image2']['size'];
	  $file_tmp  = $_FILES['image2']['tmp_name'];
	  $file_type = $_FILES['image2']['type'];
	  $file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
	  
	  $extensions= array("jpeg","jpg","png");
	  
	  if(in_array($file_ext,$extensions)=== false){
	     $errors[]="extension not allowed, please choose a JPEG or PNG file.";
	  }
	  if($file_size > 2097152) {
	     $errors[]='File size must be excately 2 MB';
	  }

	  if(empty($errors)==true) {
	     move_uploaded_file($file_tmp,"".$uname.time()."_2");
	     $output="/imgs/".$uname.time()
	  
	  }else{
	     print_r($errors);
	  }
	}

}




if ($board!="") {
	$sql1 = "INSERT INTO `bord_data` (`board`, `owner`, `disc`, `rules`, `photo1`, `photo2`, `flags`) 
	VALUES (
		'".$board."', 
		'".$uname."', 
		'".$disc."', 
		'".$rules."', 
		'".$photo_1."', 
		'".$photo_2."', 
		'".$flags."');";

	$result = $conn->query($sql1);

	 $sql2 ="INSERT INTO `bord_data_vews` (`board`, `owner`, `views_M`, `views`) VALUES 
	 ('".$board."', '".$uname."', '0', '0');";

	 $result = $conn->query($sql2);

}


/*
	CREATE TABLE `treelose_data`.`bord_data` ( 
	`board` VARCHAR(200) NULL , 
	`owner` TEXT NOT NULL, 
	`disc` TEXT NOT NULL, 
	`rules` TEXT NOT NULL, 
	`photo1` TEXT NOT NULL,
	`photo2` TEXT NOT NULL,
	`flags` TEXT NOT NULL, 
	PRIMARY KEY (board) ) ENGINE = MyISAM;

	CREATE TABLE `treelose_data`.`bord_data_vews` ( 
	`board` VARCHAR(200) NULL , 
	`owner` TEXT NOT NULL,
	`views_M` INT NOT NULL,
	`views` INT NOT NULL,
	PRIMARY KEY (board) ) ENGINE = MyISAM;
*/



?>


<html>
<head>
<style>
body {
  background-image: url('https://wallpapercave.com/wp/8Ktr9Qn.jpg');
}
.phote{
width: 800px;
border: 5px solid gray;
background-image: url('https://metal.graphics/files/matte/matte-black-background.jpg');
color: rgb(255,255,255);


}

.header{
	width: 790px;

	font-size: 20px;
	color: rgb(255,255,255);
	border: 5px solid gray;
}


.textbox{
	width: 790px;

	font-size: 20px;
	color: rgb(255,255,255);
	border: 5px solid gray;
}

.nextthing{
	width: 790px;

	font-size: 20px;
	color: rgb(255,255,255);
	border: 5px solid gray;
}

.body_top{
	width: 790px;
font-size: 30px;
	font-size: 10px;
	color: rgb(255,255,255);
	border: 5px solid gray;
}

</style>
</head>
<body>

<div class = "phote">

<div class = "header">
<h2>board admin page</h2>

 <button type="button"	
onclick="window.location.href='https://www.w3docs.com';"

 >upload</button> 

 <button type="button"	
onclick="window.location.href='https://www.w3docs.com';"

 >make post</button> 



 <button type="button"	
onclick="window.location.href='https://www.w3docs.com';"

 >seach board</button> 


 <button type="button"	
onclick="window.location.href='https://www.w3docs.com';"

 >seach posts</button> 



 <button type="button"	
onclick="window.location.href='https://www.w3docs.com';"

 >make bord</button> 
</div>

<div class = "body_top">


expalination




</div>


<div class="header">
<form action="post_bord-F.php">
  <label for="login">board name 200char </label><br>
  <input type="text" id="board" name="board" value=""><br>

    <label for="login">board discription </label><br>
  <input type="text" id="disc" name="disc" value=""><br>

      <label for="login">board rules </label><br>
  <input type="text" id="rules" name="rules" value=""><br>

      <label for="login">photo 1 </label><br>
  <input type="text" id="photo_1" name="photo_1" value=""><br>

  <form action = "" method = "POST" enctype = "multipart/form-data">
  <input type = "file" name = "image" />



        <label for="login">photo 2 </label><br>
 <input type="text" id="photo_2" name="photo_2" value=""><br>

  <form action = "" method = "POST" enctype = "multipart/form-data">
  <input type = "file" name = "image2" />



 <label for="login">flags </label><br>
 <input type="text" id="flags" name="flags" value=""><br>




<select name="cars" id="cars">
  <option value="volvo">everyone</option>
  <option value="saab">onlybanned</option>
  <input type="submit" value="search form">
</select>
<br>

  <input type="submit" value="Submit">





</form> 
</div>




</div>
</br>
<?php echo  $sql2; 
?>


</body>
</html>






