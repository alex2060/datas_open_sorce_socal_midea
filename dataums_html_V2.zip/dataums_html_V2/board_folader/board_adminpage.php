
<?php

session_start();
$uname=$_SESSION['uname'];

if ($uname=="") {
  $uname="nobody";
}


$servername = "localhost";
$username = "alex_hausssmann";
$password = "treelos_password";
$dbName = "treelose_data";
$conn = new mysqli($servername, $username, $password,$dbName );

//$board=$_GET["board"]
//$postid=$_GET["postid"]
//$user=$_GET["user"]
//$type=$_GET["type"]
//check if board addmin is user
//bord_data_2



$sql1 ="SELECT * FROM `bord_data` WHERE `board` LIKE '".$_GET["board"]."' ";
$output="";
$result = $conn->query($sql);
$owner=0;

if($result->num_rows==0){


  if ($result->num_rows>0) {

     while($row = $result->fetch_assoc()) {
      
        $owner=$row["owner"];

      }

      if($owner==$uname){
              
          if($type=="ban_user"){
              $sql="INSERT INTO `ban_list` (`user`, `postid`, `board`, `ban_type`) VALUES ('".$user."', '".$postid."', '".$board."', 'ban_user')";
          
              $output="banned ".$user;
          }

          if($type=="ban_post"){
      
              $sql="INSERT INTO `ban_list` (`user`, `postid`, `board`, `ban_type`) VALUES ('".$user."', '".$postid."', '".$board."', 'ban_post')";
              $output="banned ".$postid;

          }



          if($type=="unban_user"){
            $sql="DELETE FROM ban_list WHERE board='".$board."' and user='".$user."' and ban_type='ban_user' ";
            $output="unbanned ".$postid;
          }

          if($type=="unban_post"){
      
            $sql="DELETE FROM ban_list WHERE postid='".$postid."' and board='".$board."' and ban_type='unban_post'" ;
            $output="unbanned ".$postid;
          }


      }
      else{
    
        $output = "you are not the owener";
      }
  }
  else{
    $output="something went wrong";
  }
}
else{
  $output="no board found";

}





// if not return your not the board owner

// if so 
//INSERT INTO `ban_list` (`user`, `postid`, `board`, `ban_type`) VALUES ('thiz_user', '12911', 'bord1', 'type1');
// return insert message post to log



/*

CREATE TABLE `treelose_data`.`bord_data_2` ( 
`board` VARCHAR(200) NULL , 
`owner` TEXT NOT NULL, 
`disc` TEXT NOT NULL, 
`rules` TEXT NOT NULL, 
`flags` TEXT NOT NULL, 
PRIMARY KEY (board) ) ENGINE = MyISAM


*/


/*
CREATE TABLE `treelose_data`.`ban_list` ( 
    `user` VARCHAR(100) NOT NULL , 
    `postid` VARCHAR(64) NOT NULL , 
    `board` VARCHAR(200) NOT NULL , 
    `ban_type` TEXT NOT NULL,
PRIMARY KEY (user,postid,board) ) ENGINE = MyISAM; 


*/




?>

<html>
<head>
<style>
body {
  background-image: url('https://wallpapercave.com/wp/8Ktr9Qn.jpg');
}
.phote{
width: 800px;
border: 5px solid gray;
background-image: url('https://metal.graphics/files/matte/matte-black-background.jpg');
color: rgb(255,255,255);


}

.header{
	width: 790px;

	font-size: 20px;
	color: rgb(255,255,255);
	border: 5px solid gray;
}


.textbox{
	width: 790px;

	font-size: 20px;
	color: rgb(255,255,255);
	border: 5px solid gray;
}

.nextthing{
	width: 790px;

	font-size: 20px;
	color: rgb(255,255,255);
	border: 5px solid gray;
}

.body_top{
	width: 790px;
font-size: 30px;
	font-size: 10px;
	color: rgb(255,255,255);
	border: 5px solid gray;
}

</style>
</head>
<body>

<div class = "phote">

<div class = "header">
<h2>board admin page</h2>

 <button type="button"	
onclick="window.location.href='https://www.w3docs.com';"

 >upload</button> 

 <button type="button"	
onclick="window.location.href='https://www.w3docs.com';"

 >make post</button> 



 <button type="button"	
onclick="window.location.href='https://www.w3docs.com';"

 >seach board</button> 


 <button type="button"	
onclick="window.location.href='https://www.w3docs.com';"

 >seach posts</button> 



 <button type="button"	
onclick="window.location.href='https://www.w3docs.com';"

 >make bord</button> 
</div>

<div class = "body_top">


expalination



</div>


<form action="board_adminpage.php">
  <label for="board">board</label>
  <input type="text" id="board" name="board"><br>
  <label for="lname">postid</label>
  <input type="text" id="postid" name="postid"></br>
  <label for="user">user  </label>
   <input type="text" id="user" name="user"></br>
   </br>

<select name="type" id="type">
  <option value="ban_user">ban user</option>
  <option value="ban_post">ban post</option>
  <option value="unban_user">unbanuser</option>
  <option value="unban_post">unnban postr</option>
  
</select>

<input type="submit" value="search form">
</form> 

<?php echo $output ?>




</div>



</body>
</html>










