
<?
session_start();
$uname=$_SESSION['uname'];

if ($uname=="") {
  $uname="nobody";
}

$servername = "localhost";
$username = "alex_hausssmann";
$password = "treelos_password";
$dbName = "treelose_data";
$conn = new mysqli($servername, $username, $password,$dbName );




$user_S=$_GET["user"];
$seach=$_GET["seach"];





$order_type=$_GET["order_type"];
$combo_type=$_GET["combo_type"];




$tops="  ORDER BY `time` DESC ";

$hots=" ";

$sort=$hots;
$sql2="";




/*
	CREATE TABLE `treelose_data`.`bord_data` ( 
	`board` VARCHAR(200) NULL , 
	`owner` TEXT NOT NULL, 
	`disc` TEXT NOT NULL, 
	`rules` TEXT NOT NULL, 
	`photo1` TEXT NOT NULL,
	`photo2` TEXT NOT NULL,
	`flags` TEXT NOT NULL, 
	PRIMARY KEY (board) ) ENGINE = MyISAM
*/


$board_S=$_GET["board"];

$sql1 = "SELECT * FROM bord_data WHERE `board` LIKE '".$board_S."';";



$result = $conn->query($sql1);

$header="";

if ($result->num_rows>0) {
	while($row = $result->fetch_assoc()) {


		$board=$row["board"];
		$photo1=$row["photo1"];
		$disc=$row["disc"];
		$rules=$row["rules"];

		$header="<div class = \"header__1\">
		  <div class=\"pic\"> </br>


			   </div> <div class=\"users\">".$board."</div>   <div class=\"tital\">owners 

				</div>
	<button onclick=\"myFunction()\">rules</button>
	<p id=\"b_rules\"></p>
	<script>
	function myFunction() {
	  document.getElementById(\"b_rules\").innerHTML = \"".$rules."\";
	}
	</script>
</div>
			</br>
			<img style=\"float: right; padding: 0px 3px 0px 0px;\"
			src=\"".$photo1."\" 

			alt=\"Girl in a jacket
			\" width=\"400\" height=\"200\">".$disc."
			 </br> </br> </br>
			 </br>
			 </br>
		 	 </br>
			 </br>  
			 </br>
			 </br>
			 </br> 
			 </br>  
			 </br>
			 </br>
			 </br> 
	<button type=\"button\"  
  onclick=\"window.location.href='http://alexhaussmann.com/adhaussmann/dataums/upload/upload_file.php';\"
   >upload</button> 
   <button type=\"button\"  
  onclick=\"window.location.href='http://alexhaussmann.com/adhaussmann/dataums/post_page/post_page.php';\"
   >make post</button> 
   <button type=\"button\"  
  onclick=\"window.location.href='http://alexhaussmann.com/adhaussmann/dataums/board_folader/bord_search.php';\"
   >seach board</button> 
   <button type=\"button\"  
  onclick=\"window.location.href='http://alexhaussmann.com/adhaussmann/dataums/post_page/post_page.php';\"
   >seach posts</button> 
   <button type=\"button\"  
  onclick=\"window.location.href='http://alexhaussmann.com/adhaussmann/dataums/board_folader/post_bord.php';\"
   >make bord</button> ";

	}

}



/*
	CREATE TABLE `treelose_data`.`board_post_table_holder_3` ( 
	`board` VARCHAR(200) NOT NULL , 
	`postid` VARCHAR(64) NOT NULL ,
	`dic` Text Not Null, 
	`user` VARCHAR(100) NOT NULL , 
	`upvotes` INT NOT NULL , 
	`downvotes` INT NOT NULL,
	`time` TIMESTAMP NOT NULL ,
	PRIMARY KEY (board,user,postid)
	 ) ENGINE = MyISAM; 
*/


if ($combo_type=="") {
	$combo_type="and_i";
}

if ($combo_type=="and_i" or $combo_type=="or_i") {
	$uname_S="%".$uname_S."%";
	$seach="%".$seach."%";
}




if ($combo_type=="and_e" or $combo_type=="or_e") {
	if ($seach="") {
		$seach="%%";
	}

	if ($uname_S="") {
		$uname_S="%%";
	}

}



if($board_S==""){
	$board_S="%%";

}

if($board_S=="all"){
	$board_S="%%";

}

if ($user_S="") {
	$user_S="%%";
}



$sql2="SELECT * FROM `post` JOIN board_post_table_holder_3 on fild_id=postid  WHERE `board` LIKE '".$board_S."' " ;

if ($combo_type=="and_e" or $combo_type=="and_i") {
	$useach=" AND board_post_table_holder_3.user LIKE '".$uname_S."' ";
	$item_seach=" AND `dic` LIKE '".$seach."' ";
	$sql2=$sql2.$useach.$item_seach.$header_seach;
}

if ($combo_type=="or_e" or $combo_type=="or_i") {
	$useach=" or board_post_table_holder_3.user LIKE '".$uname_S."' ";
	$item_seach=" or `dic` LIKE '".$seach."' ";
	$sql2=$sql2.$useach.$item_seach.$header_seach;
}


$page_numberbot=$_GET["pageNumber"];
if ($page_numberbot=="") {
	$page_numberbot=0;
}

if ($page_numberbot==0) {
	$page_numberbot=0;
}


$page_numberbot=$page_numberbot*6;

$page_numbertop=$page_numberbot+6;



$end="LIMIT ".$page_numberbot." , ".$page_numbertop."; ";
$sql2=$sql2.$hots.$end;




/*

	CREATE TABLE `treelose_data`.`board_post_table_holder_3` ( 
	`board` VARCHAR(200) NOT NULL , 
	`postid` VARCHAR(64) NOT NULL ,
	`dic` Text Not Null, 
	`user` VARCHAR(100) NOT NULL , 
	`upvotes` INT NOT NULL , 
	`downvotes` INT NOT NULL,
	`time` TIMESTAMP NOT NULL ,
	PRIMARY KEY (board,user,postid)
	 ) ENGINE = MyISAM;

	 
*/




$outputdiv   = array("0","1","2","3","4","5","6");



$result = $conn->query($sql2);

$count=0;

$good="";
if ($result->num_rows>0) {
	$good="we good";
   while($row = $result->fetch_assoc()) {



		$C_tital=$row["tital"];		


		$C_user=$row["user"];

		$C_header=$row["header"];



		$outputdiv[$count]= "
			<div class = \"textbody\">
				<div class =\"comnet_header\">
				".$C_tital."
				</br>
					<div class =\"user_header\">
						".$C_user."
					</div>
				</div>
				<div class =\"body_header\">
				  ".$C_header."
				  </br>
				</br>
			</br>
			</br>
			</br>
			<button class= \"buttonkk\" onclick=\"window.location.href= 
			'http://alexhaussmann.com/adhaussmann/dataums/post_page/viewpage.php?pageid=".$row["fild_id"]." '; \"> </button>
				</div>


			</div>
			
			<div class=\"viewimg\" >
		





			<img   src=\"http://alexhaussmann.com/adhaussmann/dataums/post_page/im/".$row["fild_id"]."\" alt=\"Girl in a jacket\" width=\"205\" height=\"205\"> 

		</div>";






	    $count=$count+1;

	}

}



/*

CREATE TABLE `treelose_data`.`board_post_table_holder_3` ( 
`board` VARCHAR(200) NOT NULL , 
`postid` VARCHAR(64) NOT NULL ,
`dic` Text Not Null, 
`user` VARCHAR(100) NOT NULL , 
`upvotes` INT NOT NULL , 
`downvotes` INT NOT NULL,
`time` TIMESTAMP NOT NULL ,
PRIMARY KEY (board,user,postid)
 ) ENGINE = MyISAM; 
 
*/










/*
CREATE TABLE `treelose_data`.`upvote_table`  ( 
`user` VARCHAR(100) NOT NULL , 
`board` VARCHAR(200) NOT NULL , 
`upvote` BOOLEAN NOT NULL , 
`downvote` BOOLEAN NOT NULL , 
`time` TIMESTAMP NOT NULL , 
`postid` VARCHAR(64) NOT NULL,

PRIMARY KEY (board,user,postid)
 ) ENGINE = MyISAM; 
*/

/*
CREATE TABLE `treelose_data`.`board_post_table_holder` ( 
`board` VARCHAR(200) NOT NULL , 
`postid` VARCHAR(64) NOT NULL , 
`user` VARCHAR(100) NOT NULL , 
`upvotes` INT NOT NULL , 
`downvotes` INT NOT NULL,
PRIMARY KEY (board,user,postid)
 ) ENGINE = MyISAM; 
*/



/*
CREATE TABLE `treelose_data`.`ban_list` ( 
    `user` VARCHAR(100) NOT NULL , 
    `postid` VARCHAR(64) NOT NULL , 
    `board` VARCHAR(200) NOT NULL , 
    `ban_type` TEXT NOT NULL,
PRIMARY KEY (user,postid,board) ) ENGINE = MyISAM; 


*/

?>



<!DOCTYPE html>
<html>
<head>
<style>
body {
  background-image: url('https://wallpapercave.com/wp/8Ktr9Qn.jpg');
}

.phote{
width: 800px;
border: 5px solid gray;
background-image: url('https://metal.graphics/files/matte/matte-black-background.jpg');
color: rgb(255,255,255);


}

.header{
	width: 790px;

	font-size: 20px;
	color: rgb(255,255,255);
	border: 5px solid gray;
}

.header__1{	
	width: 790px;
	font-size: 30px;
	color: rgb(255,255,255);
	border: 5px solid gray;
}


.textbox{
	width: 790px;
	font-size: 20px;
	color: rgb(255,255,255);
	border: 5px solid gray;
	padding: 10px;
}

.nextthing{
	width: 790px;

	font-size: 20px;
	color: rgb(255,255,255);
	border: 5px solid gray;
}

.body_top{
	width: 790px;
font-size: 30px;
	font-size: 10px;
	color: rgb(255,255,255);
	border: 5px solid gray;
}


.viewimg{
	text-align:right;


}


.tital{
font-size: 30px;
}


.users{
font-size: 15px;
}


.upvote{

	font-size: 15px
}
.pic{
	float: right;

}

.postHead{

	font-size: 25px;
}


.buttonkk { 
height: 20px; 
width: 20px; 



} 

.comnet_header{
	font-size: 35px;
	border: 5px solid gray;
	width: 571px;

	text-overflow: ellipsis;
}

.body_header{
	font-size: 20px;
	border: 5px solid gray;
	width: 571px;

}

.textbody{
	float: left;
	width: auto;

}


.user_header{
	font-size: 15px;

}




</style>
</head>
<body>

<div class = "phote">

	  <div class = "header">
	  <?php echo $header; ?>
	</div>



<div class = "body_top">


 <form>
  <label for="fname">board</label>
  <input type="text" id="board" name="board" value=<?php echo "\"".$board_S."\""; ?>>
  <label for="lname">user</label>
  <input type="text" id="user" name="">
  <label for="lname">seach</label>
   <input type="text" id="seach" name="">
   

	<select name="combo_type" id="type">

		  <option value="or_e">or exclusive</option>

		  <option value="and_e">and exclusive</option>

		  <option value="or_i">or inclusive</option>

		  <option value="and_i">and inclusive</option>

	</select>


	<select name="order_type" id="type">

	  <option value="time">time</option>

	  <option value="top">top</option>

	  <option value="hot">hot</option>
  
	</select>

	<input type="submit" value="search form">

</form> 



	</div>


<div class="textbox">
	<div class="name_of_seach">


	
</div>



	<? echo $outputdiv[0] ?>




	<? echo $outputdiv[1] ?>




	<? echo $outputdiv[2] ?>



	<? echo $outputdiv[3] ?>



	<? echo $outputdiv[4] ?>






<div class="nextthing">

	next.   
	previose.   
	


	</br>

	   <button type="button"  
	  onclick=<?php
	  echo "\"window.location.href='http://alexhaussmann.com/adhaussmann/dataums/post_page/post_page_F.php?board=".$board_S."';\"";

	  ?>
	   >make_post</button> 


</div>

</div>

</br>

</br>
<?php echo $sql2;?>

</br>

<?php echo $sql1;?>
</br>
1
<?php echo $board_S;?>
</br>
1s


</body>
</html>




