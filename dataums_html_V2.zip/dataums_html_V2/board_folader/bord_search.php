<?php

session_start();
$uname=$_SESSION['uname'];

if ($uname=="") {
  $uname="nobody";
}

include("config.php");








$board_name_S=$_GET["board_name"];
$disc_S=$_GET["disc"];
$flags_S=$_GET["flags"];

$order_type=$_GET["order_type"];
$combo_type=$_GET["combo_type"];



$tops="  ORDER BY `created` DESC ";

$hots="  ";



$sort=$hots;
$sql2="";



/*
	CREATE TABLE `treelose_data`.`bord_data` ( 
	`board` VARCHAR(200) NULL , 
	`owner` TEXT NOT NULL, 
	`disc` TEXT NOT NULL, 
	`rules` TEXT NOT NULL, 
	`photo1` TEXT NOT NULL,
	`photo2` TEXT NOT NULL,
	`flags` TEXT NOT NULL, 
	PRIMARY KEY (board) ) ENGINE = MyISAM




*/


$b1=$board_name_S;

if ($board_name_S=="") {
	$board_name_S="%%";
}

if ($board_name_S=="all") {
	$board_name_S="%%";
}



$lets="";
if ($combo_type=="and_e" or $combo_type=="or_e") {

	if ($board_name_S=="") {
		$board_name_S="%%";
	}



	if ($disc_S=="") {
		$disc_S="%%";
	}
	if ($flags_S=="") {
		$flags_S="%%";
	}
	$lets="go".$flags_S."=".$disc_S."=";
}


$b2=$board_name_S;


if ($combo_type=="and_i" or $combo_type=="or_i") {

	$board_name_S="%".$board_name_S."%";
	$disc_S="%".$disc_S."%";
	$flags_S="%".$flags_S."%";
}

$b3=$board_name_S;

$sql2="SELECT * FROM `bord_data` WHERE `board` LIKE '".$board_name_S."' " ;



if ($combo_type=="and_e" or $combo_type=="and_i") {
	
	//$useach=" AND `board` LIKE '".$board_name_S."' ";
	$item_seach=" AND `disc` LIKE '".$disc_S."' ";
	$header_seach=" AND `flags` LIKE '".$flags_S."' ";
	$sql2=$sql2.$item_seach.$header_seach;

}

if ($combo_type=="or_e" or $combo_type=="or_i") {

	//$useach=" or `board` LIKE '".$board_name_S."' ";
	$item_seach=" or `disc` LIKE ' ".$disc_S." ' ";
	$header_seach=" or `flags` LIKE ' ".$flags_S." ' ";
	$sql2=$sql2.$item_seach.$header_seach;

}



$page_numberbot=$_GET["pageNumber"];
if ($page_numberbot=="") {
	$page_numberbot=0;
}

if ($page_numberbot==0) {
	$page_numberbot=0;
}


$page_numberbot=$page_numberbot*6;

$page_numbertop=$page_numberbot+6;


$end="LIMIT ".$page_numberbot." ,".$page_numbertop.";";
$sql2=$sql2.$hots.$end;







$outputdiv   =array("0","1","2","3","4","5","6");


$result = $conn->query($sql2);

$count=0;



$good="";
if ($result->num_rows>0) {
	$good="we good";
   while($row = $result->fetch_assoc()) {


    $outputdiv[$count] =" _ <button onclick=\"window.location.href= 'http://alexhaussmann.com/adhaussmann/dataums/board_folader/bord.php?board=".$row["board"]." '; \"> ".$row["board"]."</button>".
    $row["disc"]." _ ".$row["flags"]."<img src=\""
    .$row["photo1"]."\" alt=\"Girl in a jacket\" width=\"200\" height=\"200\">";
//my&combo_type=or_e&order_type=time

    $count=$count+1;
	}

}

?>





<!DOCTYPE html>
<html>
<head>
<style>
body {
  background-image: url('https://wallpapercave.com/wp/8Ktr9Qn.jpg');
}
.phote{
width: 800px;
border: 5px solid gray;
background-image: url('https://metal.graphics/files/matte/matte-black-background.jpg');
color: rgb(255,255,255);


}

.header{
	width: 790px;

	font-size: 20px;
	color: rgb(255,255,255);
	border: 5px solid gray;
}


.textbox{
	width: 790px;

	font-size: 20px;
	color: rgb(255,255,255);
	border: 5px solid gray;
}

.nextthing{
	width: 790px;

	font-size: 20px;
	color: rgb(255,255,255);
	border: 5px solid gray;
}

.body_top{
	width: 790px;
font-size: 30px;
	font-size: 10px;
	color: rgb(255,255,255);
	border: 5px solid gray;
}

.name_of_seach{
font-size: 40px;

}

.img{
float: right;
}


</style>
</head>
<body>

<div class = "phote">


<div class = "header">
	  <h2>board search</h2>
	   <button type="button"  
	  onclick="window.location.href='http://alexhaussmann.com/adhaussmann/dataums/upload/upload_file.php';"
	   >upload</button> 
	   <button type="button"  
	  onclick="window.location.href='http://alexhaussmann.com/adhaussmann/dataums/post_page/post_page.php';"
	   >make post</button> 
	   <button type="button"  
	  onclick="window.location.href='http://alexhaussmann.com/adhaussmann/dataums/board_folader/bord_search.php';"
	   >seach board</button> 
	   <button type="button"  
	  onclick="window.location.href='http://alexhaussmann.com/adhaussmann/dataums/post_page/viewpage.php?pageid=all';"
	   >seach posts</button> 
	   <button type="button"  
	  onclick="window.location.href='http://alexhaussmann.com/adhaussmann/dataums/board_folader/post_bord.php';"
	   >make bord</button> 
	</div>


<div class = "body_top">


 <form>
  <label for="board">board_name</label></br>
  <input type="text" id="board_name" name="board_name"></br>
  <label for="lname">flag1</label></br>
  <input type="text" id="disc" name="disc"></br>
  <label for="lname">flags</label></br>
   <input type="text" id="flags" name="flags"></br></br>
 </br>




	<select name="combo_type" id="type">

		  <option value="or_e">or exclusive</option>

		  <option value="and_e">and exclusive</option>

		  <option value="or_i">or inclusive</option>

		  <option value="and_i">and inclusive</option>

	</select>


	<select name="order_type" id="type">

	  <option value="time">time</option>

	  <option value="top">top</option>

	  <option value="hot">hot</option>
  
	</select>
	</br>
	<input type="submit" value="search form">


</form> 

</div>


<div class="textbox">


<?php echo $outputdiv[0]; ?>

</div>


<div class="textbox">

<?php echo $outputdiv[1]; ?>

</div>


<div class="textbox">

<?php echo $outputdiv[2]; ?>

</div>



<div class="textbox">

<?php echo $outputdiv[3]; ?>

</div>


<div class="textbox">

<?php echo $outputdiv[4]; ?>

</div>

<div class="textbox">

<?php echo $outputdiv[5]; ?>

</div>


<div class="textbox">

<?php echo $outputdiv[6]; ?>


</div>


</div>

</br>
<?php echo $sql2;?>

</br>
<?php echo $type;?>
</br>
<?php echo $good;?>
</br>
<?php echo $lets;?>
</br> b1
<?php echo $b1;?>
</br> b2
<?php echo $b2;?>
</br> b3
<?php echo $b3;?>

</body>
</html>















