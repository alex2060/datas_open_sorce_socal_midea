<?php 
session_start();


"
CREATE TABLE `treelose_data`.`__users` (
 `user` VARCHAR(100) NOT NULL , 
 `payment` TEXT NOT NULL , 
 `created` TIMESTAMP NOT NULL , 
 `email` TEXT NOT NULL , 
 `phone number` INT NOT NULL , 
 `paymentkey` TEXT NOT NULL , 
 `pass` TEXT NOT NULL, 
 PRIMARY KEY (user) ) ENGINE = MyISAM

"



?>