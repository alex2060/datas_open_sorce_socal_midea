<?php 
session_start();

include("config.php");

$output="";
$uname=$_GET["uname"];
$password2=$_GET["password"];
$sql1 = "SELECT * FROM user_T WHERE user LIKE '".$uname."' and pass LIKE '".$password2."';";

$result = $conn->query($sql1);

if ($uname!="") {

	if($result->num_rows==1){
		$_SESSION['uname']=$uname;
		header("Location: http://alexhaussmann.com/adhaussmann/datas/viewpage.php");
		$output="loged in as ".$uname." " ;
	}

	else{
		$output="not loged in";
	}
	# code...
}

$uname=$_SESSION['uname'];
if ($uname=="") {
  $uname="nobody";
}


/*
if ($result->num_rows!=0){
	$_SESSION['uname']
	$output="loged in as".$uname."here";
}

$output="wrong user name of password ";



/*
CREATE TABLE `treelose_data`.`__users` (
 `user` VARCHAR(100) NOT NULL , 
 `payment` TEXT NOT NULL , 
 `created` TIMESTAMP NOT NULL , 
 `email` TEXT NOT NULL , 
 `phone number` INT NOT NULL , 
 `paymentkey` TEXT NOT NULL , 
 `pass` TEXT NOT NULL, 
 PRIMARY KEY (user) ) ENGINE = MyISAM
*/





?>

<html>
  <head>
    <style>
      <?php
        include "style/seach_page_style.php";
        echo $post_page_css;
      ?>
    </style>
  </head>
  
  <body>

  <div class = "phote">

    <div class = "header">
      <h2>sighn up</h2>
              <?php 
                    include "style/heading_nav.php";
                    echo $header_nav_for_sight;
              ?>
      <div class = "body_top">
      expalination
      </div>

  		<form action="log_in.php">
  		  <label for="login">uname</label><br>
  		  <input type="uname" id="uname" name="uname" value=""><br>
  		  <label for="login">password</label><br>
  		  <input type="password" id="password" name="password" value=""><br>
  		  <input type="submit" value="Submit">
  		</form> 
		 <button type="button"  
		 onclick="window.location.href='http://alexhaussmann.com/adhaussmann/datas/sighnup.php';">sighnup</button> 
      <?php 
        include "log_in_its_done.php";
        echo $output_login;
      ?>  
    </div>
  </div>


  </body>
</html>














<!DOCTYPE html>
<html>
<head>
  <title>first_page</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</head>
<style>
  body
  {
    background: url('background_image.jpg');
  }
  .container-fluid {
    width: 100%;
      margin: 0;
    padding: 0;
}
   }
  .container {
    max-width: auto;

    margin: 0;
    padding: 0;
}
  .main_area
  {
        width: auto;
    border: 5px solid gray;
       background-color: #0e0e10;
  }
  .header {
    padding-left: 5px;
    padding-right: 5px;
}
.tital {
    font-size: 15px;
}
h2 {
    color: #ffff;
    font-size: 25px;
}
.data {
  font-size: 18px;
    color: #fff;
    margin-bottom: 35px;
}
label {
  font-size: 22px;
    color: #fff;
    display: inline-block;
    margin-bottom: .5rem;
}
p {
    color: #fff;
    font-size: 18px;
    margin-top: 0;
    margin-bottom: 1rem;
}
.first_image
{
  float: right; padding: 0px 3px 0px 0px;
}
.data {
    margin-bottom: 35px;
}
.button {
  background-color: #4CAF50;
  border: 1px solid green;
  color: white;
  padding: 8px 22px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
.buttons
{
   margin: auto;
  width: 65%;
  padding: 10px;
}
/*Form*/
input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

div {
      margin: auto;
    width: 50%;
    /* border: 3px solid green; */
    padding: 10px;
    /* display: block; */
    /* margin: 0; */
    width: 50%;
    border-radius: 5px;
    padding: 20px;
}
/*Form*/


.pagination a:hover:not(.active) {background-color: #ddd;}
</style>

<body>
<div class="container-fluid">
  <div class="container">
    <div class="main_area">
      <h1 class="heading_top text-white text-center">Post Page</h1>

      <div>

      <form action="log_in.php">
        <label for="login">uname</label><br>
        <input type="uname" id="uname" name="uname" value=""><br>
        <label for="login">password</label><br>
        <input type="password" id="password" name="password" value=""><br>

        <label for="login">login hash</label><br>
        <input type="password" id="hash" name="hash" value=""><br>


        <label for="login">login websight</label><br>
        <input type="password" id="hash" name="hash" value=""><br>


        <input type="submit" value="Submit">
      </form> 

</div>

    </div>
    </div>
    
  </div>
  <?php echo $herewego; ?>
</div>
</body>
</html>









