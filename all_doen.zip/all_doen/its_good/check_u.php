

<?php
$websight=$_GET["websight"];
$hash_passwrod=$_GET["hash"];
$user=$_GET["user"];

//echo hash('sha256', $_POST['ppasscode']);

$sql ="SELECT * FROM `post_2` WHERE `user` LIKE '".$user."' LIMIT 1;";
$result = $conn->query($sql);
if ($result_of_sql_qurry->num_rows>0) {


}




header("Location: V3.php?pageid=".$random_id."");







?>











