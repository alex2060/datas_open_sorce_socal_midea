<?php

session_start();
$uname=$_SESSION['uname'];

if ($uname=="") {
  $uname="nobody";
}
include("config.php");


//UPDATE video_table SET viewed_count=viewed_count+1 WHERE SELECT * FROM video_table WHERE DATE='today'

/*	
	CREATE TABLE `treelose_data`.`post` (   ,
	`fild_id` VARCHAR(64) NOT NULL 			, 
	`user` TEXT NOT NULL 					, 
	`views` INT NOT NULL 					, 
	`views_this_mouth` INT NOT NULL 		, 
	`tital` TEXT NOT NULL 					, 
	`type` TEXT NOT NULL  					,
	`header` TEXT NOT NULL    				, 
	`boady` TEXT NOT NULL     				, 
	`linked` TEXT NOT NULL    				, 
	`sorce` TEXT NOT NULL     				, 
	`upvote` INT NOT NULL     				, 
	`downvote` INT NOT NULL   				, 
	`buypage` BOOLEAN not Null  			, 
	`price` FLOAT not Null 					, 
	`git_data` Text not Null 				, 
	`eamil_data` Text not NUll 				,
	`created` TIMESTAMP NOT NULL 			,  
	PRIMARY KEY (fild_id) ) ENGINE = MyISAM ;
*/


$pageid=$_GET["pageid"];
$uname_S=$_GET["user_seach"];
$header_S=$_GET["user_seach"];
$seach_item=$_GET["user_seach"];
$type=$_GET["type"];
$combo_type="or_i";

$page_number=$_GET["page_number"] ;
if ($page_number<0) {
	$page_number=0;
}
if ($page_number=="") {
	$page_number=0;
}

$prev_page=$page_number-1;
if ($page_number<0) {
	$page_number=0;
}

$next_page=$next_number+1;


if($pageid==""){
$pageid="%%";
}


if($pageid=="all"){
$pageid="%%";
}


//output as $content for heaing of webpage  -- 


$sql ="SELECT * FROM `post_2` WHERE `fild_id` LIKE '".$pageid."' LIMIT 1;";
$result = $conn->query($sql);
$heading_div="nodiv";
$input_type="Vpage";
include "style_2/heading_div_ab.php";
//heading div output div
$heading_obj=make_headingdiv("Vpage",$result);
$heading_div=$heading_obj[0];

	$sql_view="UPDATE video_table SET views=views+10 WHERE `fild_id` Like ".$heading_obj[1]."' ;";
	$result = $conn->query($sql_view);
	$sql_view_M="UPDATE video_table SET views_this_mouth=views_this_mouth+10 WHERE `fild_id` Like ".$heading_obj[1]."' ;";
	$result = $conn->query($sql_view_M);



include("seach.php");

$sql2= get_seach_sql_with_3_flags(
		"",
		$pageid,
		"",
		$combo_type,
		$uname_S,"user",
		$seach_item,"boady",
		$header_S,"header",
		$items_return,
		6,
		$page_number,
		""
);

function get_seach_sql_with_3_flags(
		$type_of_seach,
		$sorce_1,
		$sorce_2,
		$combo_type,
		$flag_1,$flag_target_1,
		$flag_2,$flag_target_2,
		$flag_3,$flag_target_3,
		$item_number,
		$page_number,
		$order_type
){


		$sql="SELECT * FROM `post_2` WHERE `sorce` LIKE '".$sorce_1."' " ;

		if ($combo_type=="and_i" or $combo_type=="or_i") {
				$flag_1="%".$flag_1."%";
				$flag_2="%".$flag_2."%";
				$flag_3="%".$flag_3."%";	
		}
		if ($combo_type=="and_e" or $combo_type=="or_e") {
			//$sql="inhere ".$flag_1."next ";
				if ($flag_1=="") {
					$flag_1="%%";
				}
				if ($flag_2=="") {
					$flag_2="%%";
				}
				if ($flag_3=="") {
					$flag_3="%%";
				}
		}
		if ($combo_type=="and_e" or $combo_type=="and_i") {	
			$useach=" AND `".$flag_target_1."` LIKE '".$flag_1."' ";
			$item_seach=" AND `".$flag_target_2."` LIKE '".$flag_2."' ";
			$header_seach=" AND `".$flag_target_3."` LIKE '".$flag_3."' ";
			$sql=$sql.$useach.$item_seach.$header_seach;
		}
		if ($combo_type=="or_e" or $combo_type=="or_i") {
			$useach=" AND ( `".$flag_target_1."` LIKE '".$flag_1."' ";
			$item_seach=" or `".$flag_target_2."` LIKE '".$flag_2."' ";
			$header_seach=" or `".$flag_target_3."` LIKE '".$flag_3."' ) ";

			$sql=$sql.$useach.$item_seach.$header_seach;
		}



		if ($type_of_seach=="B_data"){

			$sql="SELECT * FROM `bord_data` WHERE `board` LIKE '".$sorce_1."' " ;


				if ($combo_type=="and_e" or $combo_type=="and_i") {	
					$useach=" AND `".$flag_target_1."` LIKE '".$flag_1."' ";
					$item_seach=" AND `".$flag_target_2."` LIKE '".$flag_2."' ";
					$header_seach=" AND `".$flag_target_3."` LIKE '".$flag_3."' ";
					$sql=$sql.$useach.$item_seach.$header_seach;
				}

				if ($combo_type=="or_e" or $combo_type=="or_i") {
					$useach=" or ( `".$flag_target_1."` LIKE '".$flag_1."' ";
					$item_seach=" or `".$flag_target_2."` LIKE '".$flag_2."' ";
					$header_seach=" or `".$flag_target_3."` LIKE '".$flag_3."' ) ";

					$sql=$sql.$useach.$item_seach.$header_seach;
				}


		}


		$page_numberbot=$item_number*$page_number;
		$page_numbertop=$item_number*$page_number+$page_number;
		$end="LIMIT ".$page_numberbot." ,".$page_numbertop.";";


		$sql=$sql.$hots.$end;

		return $sql;

}





include "style_2/make_body_post.php";
$result = $conn->query($sql2);
$outputdiv=make_body("post_id",$result);


/*
*/

?>










<!DOCTYPE html>
<html>
<head>
	<title>first_page</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</head>
<style>
		body
		{
			background: url('background_image.jpg');
		}
		.container-fluid {
	    width: 100%;
	      margin: 0;
	    padding: 0;
		}
	   
	   	}
		.container {
	    max-width: auto;

	    margin: 0;
	    padding: 0;
		}
		
		.main_area
		{
			    width: auto;
	    border: 5px solid gray;
	       background-color: #0e0e10;
		}
		.header {
	    padding-left: 5px;
	    padding-right: 5px;
		}
		.tital {
		    font-size: 15px;
		}
		h2 {
		    color: #ffff;
		    font-size: 25px;
		}
		
		.data {
			font-size: 18px;
		    color: #fff;
		    margin-bottom: 35px;
		}
		label {
			font-size: 22px;
		    color: #fff;
		    display: inline-block;
		    margin-bottom: .5rem;
		}
		p {
		    color: #fff;
		    font-size: 18px;
		    margin-top: 0;
		    margin-bottom: 1rem;
		}
		.first_image
		{
			float: right; padding: 0px 3px 0px 0px;
		}
		.data {
		    margin-bottom: 35px;
		}
		.button {
		  background-color: #4CAF50;
		  border: 1px solid green;
		  color: white;
		  padding: 8px 22px;
		  text-align: center;
		  text-decoration: none;
		  display: inline-block;
		  font-size: 16px;
		  margin: 4px 2px;
		  cursor: pointer;
		}
		.buttons
		{
			 margin: auto;
		  width: 65%;
		  padding: 10px;
		}
		/*Form*/
		input[type=text], select {
		  width: 100%;
		  padding: 12px 20px;
		  margin: 8px 0;
		  display: inline-block;
		  border: 1px solid #ccc;
		  border-radius: 4px;
		  box-sizing: border-box;
		}

		input[type=submit] {
		  width: 100%;
		  background-color: #4CAF50;
		  color: white;
		  padding: 14px 20px;
		  margin: 8px 0;
		  border: none;
		  border-radius: 4px;
		  cursor: pointer;
		}

		input[type=submit]:hover {
		  background-color: #45a049;
		}

		div {
		  border-radius: 5px;
		  padding: 20px;
		}
		/*Form*/
		.textbody {
		    float: left;
		    width: 100%;
		}
		.comnet_header {
		    font-size: 35px;
		   /* border: 5px solid gray;*/
		    width: auto;
		    text-overflow: ellipsis;
		}
		.body_header {
		    font-size: 20px;
		    border: 5px solid gray;
		    width: 571px;
		}
		.viewimg {
		    text-align: right;
		}
		hr {
		    margin-top: 45px;
		    margin-bottom: 1rem;
		    border: 0;
		    border-top: 1px solid rgb(255 255 255);
		}
		.pagination {
		  display: inline-block;
		}
		.textdown{
			word-wrap: normal;

		}

		.pagination a {
		  color: #ffff;
		  float: left;
		  padding: 8px 16px;
		  text-decoration: none;
		  transition: background-color .3s;
		}

		.pagination a.active {
		  background-color: #4CAF50;
		  color: white;
		}

	.pagination a:hover:not(.active) {background-color: #ddd;}



</style>

<body>
<div class="container-fluid">
	<div class="container">
		<div class="main_area">
			<div class="header">
		<!-- fild_id -->

		  		<!-- <div class="pic"> <br>


			   </div>  -->
			   <!-- <div class="users"> alex2060</div>  -->			  
			   <?echo $heading_div;?>



	 <div class="buttons">
	<button class="button" onclick=
	<?php echo "\"window.location.href='post_page2.php?sorce=".$pageid."' ; \""; ?>

	>Make Post</button>
 </div>



</div>
<div class="body_top">


	<div>
  <form action="">
    <label for="fname">Search</label>
    <input type="text" id="fname" name="user_seach" id="user_seach"  placeholder="....">

    <label for="lname">Search Page</label>
    <input type="text" id="lname" name="pageid"  id="pageid"   value=<?php echo "\"".$_GET["pageid"]."\""; ?>   placeholder="">

  
    <input type="submit" value="Submit">
  </form>
</div>
<div class="textbox">
	<div style="border: 1px solid gray;">
					


			<?php 
				$i = 0;
		        while ($i < count($outputdiv) )
		        {
		            echo $outputdiv[$i] ."<br />";
		            $i++;
		        }
		    ?>







	</div>
</div>
<div class="pagination">


  <a <?php echo "href=\"V3.php?pageid=".$pageid."&page_number=".($page_number-1)."\" ";?> >PREV</a>
  <a <?php echo "href=\"V3.php?pageid=".$pageid."&page_number=".($page_number+1)."\" ";?> >NEXT</a>



  <a href="#">&raquo;</a>
</div>
			<!-- <form>
				<label for="fname">user_seach</label>
				<input type="text" id="user_seach" name="user_seach">
				<label for="lname">header</label>
				<input type="text" id="header" name="header">
				<label for="lname">boady_seach</label>
				<input type="text" id="boady_seach" name="boady_seach">
				<label for="lname">seach_item</label>
				<input type="text" id="seach_item" name="seach_item">

				<label for="lname">seach_page</label>
				<input type="text" id="pageid" name="pageid" value="%%">
			   

				<select name="combo_type" id="type">

					  <option value="or_e">or exclusive</option>

					  <option value="and_e">and exclusive</option>

					  <option value="or_i">or inclusive</option>

					  <option value="and_i">and inclusive</option>

				</select>


				<select name="order_type" id="type">

				  <option value="time">time</option>

				  <option value="top">top</option>

				  <option value="hot">hot</option>
			  
				</select>


				<input type="submit" value="search form">
			</form> 
 -->


		</div>
		</div>
		logged in as alex
	</br>
	<?php echo $sql2;?>
	</div>
</div>
</body>
</html>