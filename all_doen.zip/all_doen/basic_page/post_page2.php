
<?php
session_start();
$uname=$_SESSION['uname'];
if ($uname=="") {
  $uname="nobody";
}
include("config.php");

$tital=$_GET["tital"];
$board=$_GET["board"];


$tital=$_POST["tital"];

$header=$_POST["header"];
$boady=$_POST["boady"];
$link=$_POST["link"];
$linkdisc=$_POST["linkdisc"];
$sorce=$_POST["sorce"];
$buy=$_POST["buy"];
$price=$_POST["price"];
$git_data=$_POST["git_data"];
$eamil_data=$_POST["eamil_data"];
$type=$_POST["type"];
$bord_I=$_POST["bord"];

$herewego="nothing";

$random_id=$uname1.time();

$buysend="0";
$price_send="5.00";



//fild_id
  //user
  //views views_this_mouth
  //tital
  //type
  //header
  //boady
  //linked
  //sorce
//upvote downvote buypage price git_data eamil_data



$sql="";

$herewego="notgood";


$herewego="inlink";
if(isset($_FILES['image'])){
    $herewego="infile";
    $errors= array();
    $file_name = $_FILES['image']['name'];
    $file_size = $_FILES['image']['size'];
    $file_tmp = $_FILES['image']['tmp_name'];
    $file_type = $_FILES['image']['type'];
    $file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
    
    $extensions= array("jpeg","jpg","png");
    
    if(in_array($file_ext,$extensions)=== false){
       $errors[]="extension not allowed, please choose a JPEG or PNG file.";
    }
    if($file_size > 2097152) {
       $errors[]='File size must be excately 2 MB';
    }

    if(empty($errors)==true) {
     $output="".$uname.time()."_2";
     move_uploaded_file($file_tmp,"".$random_id);
     $fileMoved = rename($random_id, "imgs/".$random_id ) ;
     $link="imgs/".$random_id;
     $herewego="ture";
    }else{
     print_r($errors);
    }
}






$here="1";
if ($tital!=""){
  $here="done";
$sql="INSERT INTO `post_2` (`fild_id`, `user`, `views`, `views_this_mouth`, `tital`, `type`, `header`, `boady`, `linked`, `sorce`, `upvote`, `downvote`, `buypage`, `price`, `git_data`, `eamil_data`,`created`) VALUES 
   ('".$random_id."', 
   '".$uname."',
   '0', '0', 
   '".$tital."', 
   '".$type."', 
   '".$header."', 
   '".$boady."', 
   '".$link."', 
   '".$sorce."', 
   '0', '0', '".$buy."', 
   '".$price."', 
   '".$git_data."', 
   '".$eamil_data."'
   ,CURRENT_TIMESTAMP); ";
  
  $result = $conn->query($sql);
  header("Location: V3.php?pageid=".$random_id."");
}
/*
  CREATE TABLE `treelose_data`.post` (
  `fild_id` VARCHAR(64) NOT NULL , 
  `user` TEXT NOT NULL , 
  `views` INT NOT NULL , 
  `views_this_mouth` INT NOT NULL , 
  `tital` TEXT NOT NULL , 
  'type' TEXT NOT NULL,
  `header` TEXT NOT NULL , 
  `boady` TEXT NOT NULL , 
  `linked` TEXT NOT NULL , 
  `sorce` TEXT NOT NULL , 
  `upvote` INT NOT NULL , 
  `downvote` INT NOT NULL, 
  `buypage` BOOLEAN not Null, 
  `price` FLOAT not Null, 
  `git_data` Text not Null, 
  `eamil_data` Text not NUll,
  PRIMARY KEY (fild_id) ) ENGINE = MyISAM
*/
//$result = $conn->query($sql);





//INSERT INTO `treelose_data` (`user`, `postid`, `board`, `ban_type`) VALUES ('thiz_user', '12911', 'bord1', 'type1');



/* 
   CREATE TABLE `treelose_data`.`upvote_table` 
    ( `user` VARCHAR(100) NOT NULL , 
   `post_id` INT(64) NOT NULL , 
   `bord` VARCHAR(200) NOT NULL , 
   `vote` INT NOT NULL , 
   `downvote` BOOLEAN NOT NULL,
   PRIMARY KEY (user,post_id,bord) ) ENGINE = MyISAM; 
*/

/*
 add to bord form tabel
 
*/



?>











<!DOCTYPE html>
<html>
<head>
	<title>first_page</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</head>
<style>
	body
	{
		background: url('background_image.jpg');
	}
	.container-fluid {
    width: 100%;
      margin: 0;
    padding: 0;
}
   }
	.container {
    max-width: auto;

    margin: 0;
    padding: 0;
}
	.main_area
	{
		    width: auto;
    border: 5px solid gray;
       background-color: #0e0e10;
	}
	.header {
    padding-left: 5px;
    padding-right: 5px;
}
.tital {
    font-size: 15px;
}
h2 {
    color: #ffff;
    font-size: 25px;
}
.data {
	font-size: 18px;
    color: #fff;
    margin-bottom: 35px;
}
label {
	font-size: 22px;
    color: #fff;
    display: inline-block;
    margin-bottom: .5rem;
}
p {
    color: #fff;
    font-size: 18px;
    margin-top: 0;
    margin-bottom: 1rem;
}
.first_image
{
	float: right; padding: 0px 3px 0px 0px;
}
.data {
    margin-bottom: 35px;
}
.button {
  background-color: #4CAF50;
  border: 1px solid green;
  color: white;
  padding: 8px 22px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
.buttons
{
	 margin: auto;
  width: 65%;
  padding: 10px;
}
/*Form*/
input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

div {
      margin: auto;
    width: 50%;
    /* border: 3px solid green; */
    padding: 10px;
    /* display: block; */
    /* margin: 0; */
    width: 50%;
    border-radius: 5px;
    padding: 20px;
}
/*Form*/


.pagination a:hover:not(.active) {background-color: #ddd;}
</style>

<body>
<div class="container-fluid">
	<div class="container">
		<div class="main_area">
			<h1 class="heading_top text-white text-center">Post Page</h1>

			<div>
    <form action = "" method = "POST" enctype = "multipart/form-data">

            <label for="login">tital</label><br>
            <input type="tital" id="tital" name="tital" value=""><br>


            <label for="login">header</label><br>
            <input type="header" id="header" name="header" value=""><br>

            <label for="login">boady</label><br>
            <input type="boady" id="boady" name="boady" value=""><br>

            <input type = "file" name = "image" />

            </br>
            <label for="login">linked file discription</label><br>
            <input type="linked" id="linkdisc" name="linkdisc" value=""><br>
            <label for="sorce">sorce file11</label><br>
            <input type="linked" id="sorce" name="sorce" value=<?php echo "\"".$_GET["sorce"]."\""; ?> > <br>
            <label for="sorce">type</label><br>
            <select name="buy" id="type">
            <option value="img">text</option>
            <option value="video">video</option>
            <option value="video">link</option>
            </select>
            </br>
            <input type="submit">
            </select>
    </form>
</div>

		</div>
		</div>
		
	</div>
  <?php echo $herewego; ?>
</div>
</body>
</html>