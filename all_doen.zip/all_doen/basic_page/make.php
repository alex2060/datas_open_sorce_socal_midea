<?php

session_start();
$uname=$_SESSION['uname'];


$name=2;
if ($uname=="") {
  $uname="nobody";
}
include("config.php");

$sql =
	"
	CREATE TABLE `treelose_data`.`post_".$name."` (   ,
	`fild_id` VARCHAR(64) NOT NULL 			, 
	`user` TEXT NOT NULL 					, 
	`views` INT NOT NULL 					, 
	`views_this_mouth` INT NOT NULL 		, 
	`tital` TEXT NOT NULL 					, 
	`type` TEXT NOT NULL  					,
	`header` TEXT NOT NULL    				, 
	`boady` TEXT NOT NULL     				, 
	`linked` TEXT NOT NULL    				, 
	`sorce` TEXT NOT NULL     				, 
	`upvote` INT NOT NULL     				, 
	`downvote` INT NOT NULL   				, 
	`buypage` BOOLEAN not Null  			, 
	`price` FLOAT not Null 					, 
	`git_data` Text not Null 				, 
	`eamil_data` Text not NUll 				,
	`created` TIMESTAMP NOT NULL 			,  
	PRIMARY KEY (fild_id) ) ENGINE = MyISAM ;
	";
	
$result = $conn->query($sql);

?>






