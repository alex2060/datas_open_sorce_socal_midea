<?php 


function make_headingdiv($type_of_header,$result_of_sql_qurry) {

 		


 		
	if ($result_of_sql_qurry->num_rows>0) {
				$count=0;
				$count2=0;
			//effects viww page

				while($row = $result_of_sql_qurry->fetch_assoc() and $count==0) {
				    $header=$row["header"];
				    $boady=$row["boady"];
				    $type=$row["type"];
				    $linked=$row["linked"];
				    $upvote=$row["upvote"];
				    $downvote=$row["downvote"];
				    $tital=$row["tital"];
				    $views=$row["views"];
				    $views_this_mouth=$row["views_this_mouth"];
				    $buypage=$row["buypage"];
				    $poster=$row["user"];
				    $sorce_H=["sorce"];
				    $diplayed_page="fild_id";
				    $count+=1;			    
				}


				$page_viewed=$diplayed_page;
				$tital=$poster;
				//body handing to be immented
				$header=$header;
				$boady=$boady;

				// content handing to be implemented
				$content="<img class=\"first_image\" src=\"".$linked."\" alt=\"Girl in a jackets \" width=\"400\" height=\"200\">";
				//$content="<img src=\"".$linked."\" class=\"img-fluid \">";
				


			


				$heading_div="
				 <div class=\"tital\">
 					<p>".$tital."</p> 

				</div>
				<br>
				<div class=\"data\">

".$content."
					".$header."</br>".$boady."
				</div>
				 ";






	}


return array($heading_div,$page_viewed);


}






?>