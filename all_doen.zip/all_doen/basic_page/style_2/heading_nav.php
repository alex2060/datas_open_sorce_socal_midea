 <?php $header_nav_for_sight=

 "<div class=\"buttons\">
	<button class=\"button\" onclick=\"window.location.href='post_page2.php';\">Make Post</button>

 </div>"


?>