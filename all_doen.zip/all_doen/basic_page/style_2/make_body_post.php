
<?php



function make_body($type_of_header,$result) {
$array = array();

	if ($result->num_rows>0) {
		while($row = $result->fetch_assoc()) {
				$C_tital=$row["tital"];
				$C_user=$row["flags"];

				$C_header=$row["disc"];

				$button="<button class= \"buttonkk\" onclick=\"window.location.href= 'viewpage.php?pageid=".$row["fild_id"]." '; \"> </button>";

				$content="<img   src=\"imgs/".$row["fild_id"]."\" alt=\"fail\" style=\"width:205px;height:205px;\" width=\"205\" height=\"205\"> ";

				if ($type_of_header=="board_seach") {
						
					$C_user="<button class= \"buttonkk\" onclick=\"window.location.href= 'somewhere.php' \"'> ".$row["owner"]."</button>";
					$C_tital=$row["board"];	
					$C_header=$row["disc"];
					$button="<button class= \"button-primary\" onclick=\"window.location.href= '/bord.php?board=".$row["board"]." '; \"> </button>";
					$content="<img src=\"".$row["photo1"]."\" style=\"width: 50%;\">";
				}


				if ($type_of_header=="post_id") {
						$C_user =$row["user"];
						$C_tital=$row["tital"];
						$content="<img class=\"img-fluid\" src=\"imgs/".$row["fild_id"]."\">";
						$C_header=$row["header"];

						$button="<button style=\"float: right;\" onclick=\"window.location.href= 'V3.php?pageid=".$row["fild_id"]." ' ;\"  >go to page</button>";
						$content="<img src=\"".$row["linked"]."\" style=\"width: 180px; height:110px; \">";

						//"<button style=\"float: right;\" class= \"buttonkk\" onclick=\"window.location.href= 'V3.php?pageid=".$row["fild_id"]." '; \"> </button>";
				}




$outputdiv=
	"
<div class=\"movie_des\" style=\"width: 70%; display: inline-block; border-right: 1px solid gray;\">
<h2 style=\"display: inline-block;\">".$C_tital."</h2>
".$button."
<p style=\"display: inline-block;\">".$C_user."</br>".$C_header."</p>
</div>
<div style=\"float: right;\">
	".$content."
</div>
<hr style=\"color: #ffff;\"> 

	";


/*




*/

			array_push($array, $outputdiv);

		}


	}
$array[0]=$array[0]."";

return $array;




	}













?>
