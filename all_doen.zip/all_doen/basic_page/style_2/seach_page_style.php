
<?php

$post_page_css="


		body
		{
			background: url('background_image.jpg');
		}
		.container-fluid {
	    width: 100%;
	      margin: 0;
	    padding: 0;
		}
	   
	   	}
		.container {
	    max-width: auto;

	    margin: 0;
	    padding: 0;
		}
		
		.main_area
		{
			    width: auto;
	    border: 5px solid gray;
	       background-color: #0e0e10;
		}
		.header {
	    padding-left: 5px;
	    padding-right: 5px;
		}
		.tital {
		    font-size: 15px;
		}
		h2 {
		    color: #ffff;
		    font-size: 25px;
		}
		
		.data {
			font-size: 18px;
		    color: #fff;
		    margin-bottom: 35px;
		}
		label {
			font-size: 22px;
		    color: #fff;
		    display: inline-block;
		    margin-bottom: .5rem;
		}
		p {
		    color: #fff;
		    font-size: 18px;
		    margin-top: 0;
		    margin-bottom: 1rem;
		}
		.first_image
		{
			float: right; padding: 0px 3px 0px 0px;
		}
		.data {
		    margin-bottom: 35px;
		}
		.button {
		  background-color: #4CAF50;
		  border: 1px solid green;
		  color: white;
		  padding: 8px 22px;
		  text-align: center;
		  text-decoration: none;
		  display: inline-block;
		  font-size: 16px;
		  margin: 4px 2px;
		  cursor: pointer;
		}
		.buttons
		{
			 margin: auto;
		  width: 65%;
		  padding: 10px;
		}
		/*Form*/
		input[type=text], select {
		  width: 100%;
		  padding: 12px 20px;
		  margin: 8px 0;
		  display: inline-block;
		  border: 1px solid #ccc;
		  border-radius: 4px;
		  box-sizing: border-box;
		}

		input[type=submit] {
		  width: 100%;
		  background-color: #4CAF50;
		  color: white;
		  padding: 14px 20px;
		  margin: 8px 0;
		  border: none;
		  border-radius: 4px;
		  cursor: pointer;
		}

		input[type=submit]:hover {
		  background-color: #45a049;
		}

		div {
		  border-radius: 5px;
		  padding: 20px;
		}
		/*Form*/
		.textbody {
		    float: left;
		    width: 100%;
		}
		.comnet_header {
		    font-size: 35px;
		   /* border: 5px solid gray;*/
		    width: auto;
		    text-overflow: ellipsis;
		}
		.body_header {
		    font-size: 20px;
		    border: 5px solid gray;
		    width: 571px;
		}
		.viewimg {
		    text-align: right;
		}
		hr {
		    margin-top: 45px;
		    margin-bottom: 1rem;
		    border: 0;
		    border-top: 1px solid rgb(255 255 255);
		}
		.pagination {
		  display: inline-block;
		}

		.pagination a {
		  color: #ffff;
		  float: left;
		  padding: 8px 16px;
		  text-decoration: none;
		  transition: background-color .3s;
		}

		.pagination a.active {
		  background-color: #4CAF50;
		  color: white;
		}

	.pagination a:hover:not(.active) {background-color: #ddd;}




";


?>