<?php 
session_start();

$uname=$_SESSION['uname'];
if ($uname=="") {
  $uname="nobody";
}

$servername = "localhost";
$username = "alex_hausssmann";
$password = "treelos_password";
$dbName = "treelose_data";
$conn = new mysqli($servername, $username, $password,$dbName );




$board=$_GET["board"];
$dic=$_GET["dic"];
$post_id=$_GET["post_id"];



$sql1 =  "INSERT INTO `board_post_table_holder_3` (`board`, `postid`, `dic`, `user`, `upvotes`, `downvotes`,`time`)
	VALUES 
		('".$board."', 
		'".$post_id."', 
		'".$dic."', 
		'".$uname."', 
		'0', 
		'0',
		CURRENT_TIMESTAMP);";
$result = $conn->query($sql1);



/*
CREATE TABLE `treelose_data`.`board_post_table_holder_3` ( 
`board` VARCHAR(200) NOT NULL , 
`postid` VARCHAR(64) NOT NULL ,
`dic` Text Not Null, 
`user` VARCHAR(100) NOT NULL , 
`upvotes` INT NOT NULL , 
`downvotes` INT NOT NULL,
`time` TIMESTAMP NOT NULL ,
PRIMARY KEY (board,user,postid)
 ) ENGINE = MyISAM; 
 
*/



?>


<html>
<head>
<style>
body {
  background-image: url('https://wallpapercave.com/wp/8Ktr9Qn.jpg');
}
.phote{
width: 800px;
border: 5px solid gray;
background-image: url('https://metal.graphics/files/matte/matte-black-background.jpg');
color: rgb(255,255,255);


}

.header{
	width: 790px;

	font-size: 20px;
	color: rgb(255,255,255);
	border: 5px solid gray;
}


.textbox{
	width: 790px;

	font-size: 20px;
	color: rgb(255,255,255);
	border: 5px solid gray;
}

.nextthing{
	width: 790px;

	font-size: 20px;
	color: rgb(255,255,255);
	border: 5px solid gray;
}

.body_top{
	width: 790px;
font-size: 30px;
	font-size: 10px;
	color: rgb(255,255,255);
	border: 5px solid gray;
}

</style>
</head>
<body>

<div class = "phote">

<div class = "header">
<h2>board admin page</h2>

	    <?php include "heading_nav.php";

  		echo $header_nav_for_sight;

  		?>

 
</div>

<div class = "body_top">


expalination




</div>


<div class="header">
<form action="">
  <label for="login">board</label><br>
  <input type="text" id="board" name="board" value=<?php "\"".$board."\"" ?>  > <br>
  <label for="login">dic</label><br>
  <input type="text" id="dic" name="dic" value=""><br>

  <label for="login">post_id1</label><br>
  <input type="text" id="post_id" name="post_id" value=<?php echo "\"".$_GET["post_id"]."\""; ?> ><br>


<br>

  <input type="submit" value="Submit">

</form> 

</div>




</div>

</br>
<?php echo  $sql1; 
?>
</br>


</body>
</html>






