<?php 
$servername = "localhost";
$username = "alex_hausssmann";
$password = "treelos_password";
$dbName = "treelose_data";
$conn = new mysqli($servername, $username, $password,$dbName );


?>






