
<?php 

function get_seach_sql_with_3_flags(
		$type_of_seach,
		$sorce_1,
		$sorce_2,
		$combo_type,
		$flag_1,$flag_target_1,
		$flag_2,$flag_target_2,
		$flag_3,$flag_target_3,
		$item_number,
		$page_number,
		$order_type
){



	$sql="SELECT * FROM `post` WHERE `sorce` LIKE '".$sorce_1."' " ;






	if ($combo_type=="and_i" or $combo_type=="or_i") {
			$flag_1="%".$flag_1."%";
			$flag_2="%".$flag_2."%";
			$flag_3="%".$flag_3."%";	
	}
	if ($combo_type=="and_e" or $combo_type=="or_e") {
		//$sql="inhere ".$flag_1."next ";
			if ($flag_1=="") {
				$flag_1="%%";
			}
			if ($flag_2=="") {
				$flag_2="%%";
			}
			if ($flag_3=="") {
				$flag_3="%%";
			}
	}

	if ($combo_type=="and_e" or $combo_type=="and_i") {	
		$useach=" AND `".$flag_target_1."` LIKE '".$flag_1."' ";
		$item_seach=" AND `".$flag_target_2."` LIKE '".$flag_2."' ";
		$header_seach=" AND `".$flag_target_3."` LIKE '".$flag_3."' ";
		$sql=$sql.$useach.$item_seach.$header_seach;
	}

	if ($combo_type=="or_e" or $combo_type=="or_i") {
		$useach=" AND ( `".$flag_target_1."` LIKE '".$flag_1."' ";
		$item_seach=" or `".$flag_target_2."` LIKE '".$flag_2."' ";
		$header_seach=" or `".$flag_target_3."` LIKE '".$flag_3."' ) ";

		$sql=$sql.$useach.$item_seach.$header_seach;
	}



	if ($type_of_seach=="B_data"){

		$sql="SELECT * FROM `bord_data` WHERE `board` LIKE '".$sorce_1."' " ;


			if ($combo_type=="and_e" or $combo_type=="and_i") {	
				$useach=" AND `".$flag_target_1."` LIKE '".$flag_1."' ";
				$item_seach=" AND `".$flag_target_2."` LIKE '".$flag_2."' ";
				$header_seach=" AND `".$flag_target_3."` LIKE '".$flag_3."' ";
				$sql=$sql.$useach.$item_seach.$header_seach;
			}

			if ($combo_type=="or_e" or $combo_type=="or_i") {
				$useach=" or ( `".$flag_target_1."` LIKE '".$flag_1."' ";
				$item_seach=" or `".$flag_target_2."` LIKE '".$flag_2."' ";
				$header_seach=" or `".$flag_target_3."` LIKE '".$flag_3."' ) ";

				$sql=$sql.$useach.$item_seach.$header_seach;
			}


	}



	if ($type_of_seach=="B_2_data"){

		$sql="SELECT * FROM `post` JOIN board_post_table_holder_3 on fild_id=postid  WHERE `board` LIKE '".$sorce_1."' " ;

			if ($combo_type=="and_e" or $combo_type=="and_i") {	
				$useach=" AND ".$flag_target_1." LIKE '".$flag_1."' ";
				$item_seach=" AND `".$flag_target_2."` LIKE '".$flag_2."' ";
				$sql=$sql.$useach.$item_seach;
			}

			if ($combo_type=="or_e" or $combo_type=="or_i") {
				$useach=" or ( ".$flag_target_1." LIKE '".$flag_1."' ";
				$item_seach=" or `".$flag_target_2."` LIKE '".$flag_2."' ";

				$sql=$sql.$useach.$useach.$item_seach;
			}


	}



	$page_numberbot=$item_number*$page_number;
	$page_numbertop=$item_number*$page_number+$page_number;
	$end="LIMIT ".$page_numberbot." ,".$page_numbertop.";";


	$sql=$sql.$hots.$end;

	return $sql;


}


?>

