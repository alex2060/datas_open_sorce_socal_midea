
<?php

/*
check settion name 
add
*/

session_start();
$uname=$_SESSION['uname'];

if ($uname=="") {
  $uname="nobody";
}



$servername = "localhost";
$username = "alex_hausssmann";
$password = "treelos_password";
$dbName = "treelose_data";
$conn = new mysqli($servername, $username, $password,$dbName );

/*

CREATE TABLE `treelose_data`.`___uploads_stuff` ( 
`file_id` VARCHAR(64) NOT NULL , 
`users` TEXT NOT NULL , 
`views` INT NOT NULL , 
`mouth_views` INT NOT NULL, 
PRIMARY KEY (file_id) ) ENGINE = MyISAM

*/

//$key_size = 512;  //For a 256 bit key, you can use 128 or 512 as well. 
//$key = uuid_gen(($key_size / 8)); //8 bits in a byte

if(isset($_FILES['image'])){
      $errors= array();
      $file_name = $_FILES['image']['name'];
      $file_size = $_FILES['image']['size'];
      $file_tmp = $_FILES['image']['tmp_name'];
      $file_type = $_FILES['image']['type'];
      $file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
      
      $extensions= array("jpeg","jpg","png");
      
      if(in_array($file_ext,$extensions)=== false){
         $errors[]="extension not allowed, please choose a JPEG or PNG file.";
      }
      if($file_size > 2097152) {
         $errors[]='File size must be excately 2 MB';
      }
      if(empty($errors)==true) {
         $id=$uname.time()."_1";
         move_uploaded_file($file_tmp,"".$id);
         $fileMoved = rename($id, "imgs/".$id );
         echo "Success";

         $output="http://alexhaussmann.com/adhaussmann/dataums/upload/imgs/".$id;
      }else{
         print_r($errors);
      }
   }

   /*
	post upload link
   */
?>

<html>

<head>
<style>
body {
  background-image: url('https://wallpapercave.com/wp/8Ktr9Qn.jpg');
}
.phote{
   width: 800px;
   border: 5px solid gray;
   background-image: url('https://metal.graphics/files/matte/matte-black-background.jpg');
   color: rgb(255,255,255);


}

.header{
   width: 790px;
   font-size: 20px;
   color: rgb(255,255,255);
   border: 5px solid gray;
}


.textbox{
   width: 790px;
   font-size: 20px;
   color: rgb(255,255,255);
   border: 5px solid gray;
}

.nextthing{
   width: 790px;

   font-size: 20px;
   color: rgb(255,255,255);
   border: 5px solid gray;
}

.body_top{
   width: 790px;
   font-size: 30px;
   font-size: 10px;
   color: rgb(255,255,255);
   border: 5px solid gray;
}

</style>
</head>
<body>

<div class = "phote">

<div class = "header">
     <h2>post bord</h2>
      <button type="button"  
     onclick="window.location.href='http://alexhaussmann.com/adhaussmann/dataums/upload/upload_file.php';"
      >upload</button> 
      <button type="button"  
     onclick="window.location.href='http://alexhaussmann.com/adhaussmann/dataums/post_page/post_page.php';"
      >make post</button> 
      <button type="button"  
     onclick="window.location.href='http://alexhaussmann.com/adhaussmann/dataums/board_folader/bord_search.php';"
      >seach board</button> 
      <button type="button"  
     onclick="window.location.href='http://alexhaussmann.com/adhaussmann/dataums/post_page/viewpage.php?pageid=all';"
      >seach posts</button> 
      <button type="button"  
     onclick="window.location.href='http://alexhaussmann.com/adhaussmann/dataums/board_folader/post_bord.php';"
      >make bord</button> 
   </div>


<div class = "body_top">


expalination



   </div>



<body>
   
   <form action = "" method = "POST" enctype = "multipart/form-data">
      <input type = "file" name = "image" />
      <input type = "submit"/>
		
      <ul>
         <li>Sent file: <?php echo $_FILES['image']['name'];  ?>
         <li>File size: <?php echo $_FILES['image']['size'];  ?>
         <li>File type: <?php echo $_FILES['image']['type'] ?>
         <li> file log: <?php echo $output                  ?>   
      </ul>
		
   </form>
   

<div class="textbox">
   

user : <? echo $uname; ?>


</div>


</div>




</body>
</html>