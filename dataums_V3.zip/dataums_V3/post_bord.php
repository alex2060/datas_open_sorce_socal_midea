<?php 

session_start();
$uname=$_SESSION['uname'];

if ($uname=="") {
  $uname="nobody";
}


$servername = "localhost";
$username = "alex_hausssmann";
$password = "treelos_password";
$dbName = "treelose_data";
$conn = new mysqli($servername, $username, $password,$dbName );



$rules=$_POST["rules"];
$photo_1=$_POST["photo_1"];
$photo_2=$_POST["photo_2"];



$board=$_POST["board"];
$disc=$_POST["disc"];
$flags=$_POST["flags"];

$sql1 ="";





if ($photo_1=="") {
  $herewego="inlink";
  if(isset($_FILES['image1'])){
    $herewego="infile";
    $errors= array();
    $file_name = $_FILES['image1']['name'];
    $file_size = $_FILES['image1']['size'];
    $file_tmp  = $_FILES['image1']['tmp_name'];
    $file_type = $_FILES['image1']['type'];
    $file_ext=strtolower(end(explode('.',$_FILES['image1']['name'])));
    
    $extensions= array("jpeg","jpg","png");
    
    if(in_array($file_ext,$extensions)=== false){
       $errors[]="extension not allowed, please choose a JPEG or PNG file.";
    }
    if($file_size > 2097152) {
       $errors[]='File size must be excately 2 MB';
    }


    if(empty($errors)==true) {
    	$id=$uname.time()."_1";
       move_uploaded_file($file_tmp,"".$id);
       $fileMoved = rename($id, "imgs/".$id );
       $photo_1="http://alexhaussmann.com/adhaussmann/datas/imgs/".$id;

       $output="".$uname.time()."_2";
       $herewego="ture";
    
    }else{
       print_r($errors);
    }
  }

}





if ($photo_2=="") {
  $herewego="inlink";
  if(isset($_FILES['image2'])){
    $herewego="infile";
    $errors= array();
    $file_name = $_FILES['image2']['name'];
    $file_size = $_FILES['image2']['size'];
    $file_tmp  = $_FILES['image2']['tmp_name'];
    $file_type = $_FILES['image2']['type'];
    $file_ext=strtolower(end(explode('.',$_FILES['image2']['name'])));
    
    $extensions= array("jpeg","jpg","png");
    
    if(in_array($file_ext,$extensions)=== false){
       $errors[]="extension not allowed, please choose a JPEG or PNG file.";
    }
    if($file_size > 2097152) {
       $errors[]='File size must be excately 2 MB';
    }

    if(empty($errors)==true) {
    	$id=$uname.time()."_2";
       move_uploaded_file($file_tmp,"".$id);
       $fileMoved = rename($id, "imgs/".$id ); 
       $photo_2="http://alexhaussmann.com/adhaussmann/datas/imgs/".$id;
       //$output="".$uname.time()."_2";
       $herewego="ture";
    
    }else{
       print_r($errors);
    }
  }

}







if ($board!="") {

  $sql1 = "INSERT INTO `bord_data` (`board`, `owner`, `disc`, `rules`, `photo1`, `photo2`, `flags`) 
  VALUES (
  	'".$board."', 
  	'".$uname."', 
  	'".$disc."', 
  	'".$rules."', 
  	'".$photo_1."', 
  	'".$photo_2."', 
  	'".$flags."');";




  $result = $conn->query($sql1);

   $sql2 ="INSERT INTO `bord_data_vews` (`board`, `owner`, `views_M`, `views`) VALUES  
   ('".$board."', '".$uname."', '0', '0');";

  $result = $conn->query($sql2);

  header("Location:http://alexhaussmann.com/adhaussmann/datas/bord.php?board=".$board."");



}




/*
CREATE TABLE `treelose_data`.`bord_data` ( 
`board` VARCHAR(200) NULL , 
`owner` TEXT NOT NULL, 
`disc` TEXT NOT NULL, 
`rules` TEXT NOT NULL, 
`photo1` TEXT NOT NULL,
`photo2` TEXT NOT NULL,
`flags` TEXT NOT NULL, 
PRIMARY KEY (board) ) ENGINE = MyISAM

CREATE TABLE `treelose_data`.`bord_data_vews` ( 
`board` VARCHAR(200) NULL , 
`owner` TEXT NOT NULL,
`views_M` INT NOT NULL,
`views` INT NOT NULL,
PRIMARY KEY (board) ) ENGINE = MyISAM

*/



?>


<html>
<head>
<style>

<?php
  include "seach_page_style.php";
  echo $post_page_css;
?>



</style>
</head>
<body>

<div class = "phote">


<div class = "header">
    <h2>post board</h2>

        <?php include "heading_nav.php";

        echo $header_nav_for_sight;

        ?>
    <div class = "body_top">
        <div class="header">
        <form action = "" method = "POST" enctype = "multipart/form-data">ss
          <label for="login">board name 200char </label><br>
          <input type="text" id="board" name="board" value=""><br>

            <label for="login">board discription </label><br>
          <input type="text" id="disc" name="disc" value=""><br>

              <label for="login">board rules </label><br>
          <input type="text" id="rules" name="rules" value=""><br>

            <label for="login">photo 1 </label><br>

          <input type = "file" name = "image1" /></br>

                <label for="login">photo 2 </label><br>

         <input type = "file" name = "image2" /></br>

         <label for="login">flags </label><br>
         <input type="text" id="flags" name="flags" value=""><br>
        <select name="cars" id="cars">
          <option value="volvo">everyone</option>
          <option value="saab">onlybanned</option>
          <input type="submit" value="search form">
        </select>
        <br>

          <input type="submit" value="Submit">
      </form> 
    </div>
  </div>



  </div>
  <?php echo  $sql2; 
  ?>

</div>



</body>
</html>






