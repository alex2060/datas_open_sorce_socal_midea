
<?
session_start();
$uname=$_SESSION['uname'];

if ($uname=="") {
  $uname="nobody";
}

$servername = "localhost";
$username = "alex_hausssmann";
$password = "treelos_password";
$dbName = "treelose_data";
$conn = new mysqli($servername, $username, $password,$dbName );

$user_S=$_GET["user"];
$seach=$_GET["seach"];

$order_type=$_GET["order_type"];
$combo_type=$_GET["combo_type"];

$tops="  ORDER BY `time` DESC ";

$hots=" ";

$sort=$hots;
$sql2="";

/*
	CREATE TABLE `treelose_data`.`bord_data` ( 
	`board` VARCHAR(200) NULL , 
	`owner` TEXT NOT NULL, 
	`disc` TEXT NOT NULL, 
	`rules` TEXT NOT NULL, 
	`photo1` TEXT NOT NULL,
	`photo2` TEXT NOT NULL,
	`flags` TEXT NOT NULL, 
	PRIMARY KEY (board) ) ENGINE = MyISAM
*/


$board_S=$_GET["board"];

$sql1 = "SELECT * FROM bord_data WHERE `board` LIKE '".$board_S."';";



$result = $conn->query($sql1);


include "heading_div_ab.php";
//heading div output div
$result = $conn->query($sql1);
$heading_obj=make_headingdiv("Bpage",$result);
$header=$heading_obj[0];
/*
	CREATE TABLE `treelose_data`.`board_post_table_holder_3` ( 
	`board` VARCHAR(200) NOT NULL , 
	`postid` VARCHAR(64) NOT NULL ,
	`dic` Text Not Null, 
	`user` VARCHAR(100) NOT NULL , 
	`upvotes` INT NOT NULL , 
	`downvotes` INT NOT NULL,
	`time` TIMESTAMP NOT NULL ,
	PRIMARY KEY (board,user,postid)
	 ) ENGINE = MyISAM; 
*/
$board_S=$_GET["board"];
include("seach.php");

$sql2= get_seach_sql_with_3_flags(
		"B_2_data",
		$board_S,
		"",
		$combo_type,
		$disc_S,"board_post_table_holder_3.user",
		$flags_S,"dic",
		"","flags",
		$items_return,
		6,
		0,
		""
);


/*
	CREATE TABLE `treelose_data`.`board_post_table_holder_3` ( 
	`board` VARCHAR(200) NOT NULL , 
	`postid` VARCHAR(64) NOT NULL ,
	`dic` Text Not Null, 
	`user` VARCHAR(100) NOT NULL , 
	`upvotes` INT NOT NULL , 
	`downvotes` INT NOT NULL,
	`time` TIMESTAMP NOT NULL ,
	PRIMARY KEY (board,user,postid)
	 ) ENGINE = MyISAM;	 
*/


include "make_body_post.php";
$result = $conn->query($sql2);
$outputdiv=make_body("post_id",$result);
/*

CREATE TABLE `treelose_data`.`board_post_table_holder_3` ( 
`board` VARCHAR(200) NOT NULL , 
`postid` VARCHAR(64) NOT NULL ,
`dic` Text Not Null, 
`user` VARCHAR(100) NOT NULL , 
`upvotes` INT NOT NULL , 
`downvotes` INT NOT NULL,
`time` TIMESTAMP NOT NULL ,
PRIMARY KEY (board,user,postid)
 ) ENGINE = MyISAM; 
*/
/*
CREATE TABLE `treelose_data`.`upvote_table`  ( 
`user` VARCHAR(100) NOT NULL , 
`board` VARCHAR(200) NOT NULL , 
`upvote` BOOLEAN NOT NULL , 
`downvote` BOOLEAN NOT NULL , 
`time` TIMESTAMP NOT NULL , 
`postid` VARCHAR(64) NOT NULL,

PRIMARY KEY (board,user,postid)
 ) ENGINE = MyISAM; 
*/
/*
CREATE TABLE `treelose_data`.`board_post_table_holder` ( 
`board` VARCHAR(200) NOT NULL , 
`postid` VARCHAR(64) NOT NULL , 
`user` VARCHAR(100) NOT NULL , 
`upvotes` INT NOT NULL , 
`downvotes` INT NOT NULL,
PRIMARY KEY (board,user,postid)
 ) ENGINE = MyISAM; 
*/
/*
CREATE TABLE `treelose_data`.`ban_list` ( 
    `user` VARCHAR(100) NOT NULL , 
    `postid` VARCHAR(64) NOT NULL , 
    `board` VARCHAR(200) NOT NULL , 
    `ban_type` TEXT NOT NULL,
PRIMARY KEY (user,postid,board) ) ENGINE = MyISAM; 
*/
?>










<!DOCTYPE html>
<html>
<head>
<style>

	<?php
		include "seach_page_style.php";
		echo $post_page_css;
	?>

</style>
</head>
<body>

<div class = "phote">

	<div class = "header">
		<h2>board search</h2>
		<?php include "heading_nav.php"; echo $header_nav_for_sight; ?>
		<div class = "body_top">
					<form>
							<label for="fname">board</label>
							<input type="text" id="board" name="board" value=<?php echo "\"".$board_S."\""; ?>>
							<label for="lname">user</label>
							<input type="text" id="user" name="">
							<label for="lname">seach</label>
							<input type="text" id="seach" name="">
						  
							<select name="combo_type" id="type">

								  <option value="or_e">or exclusive</option>

								  <option value="and_e">and exclusive</option>

								  <option value="or_i">or inclusive</option>

								  <option value="and_i">and inclusive</option>

							</select>


							<select name="order_type" id="type">

							  <option value="time">time</option>

							  <option value="top">top</option>

							  <option value="hot">hot</option>
						  
							</select>

							<input type="submit" value="search form">

					</form> 
		</div>
			<?php 
				$i = 0;
		        while ($i < count($outputdiv) )
		        {
		            echo $outputdiv[$i] ."<br />";
		            $i++;
		        }
		    ?>
		<div class="nextthing">

			next.   
			previose.  
			</br>

		   <button type="button"  
		  onclick=<?php
		  echo "\"window.location.href='http://alexhaussmann.com/adhaussmann/datas/post_page_F.php?board=".$board_S."';\"";

		  ?>
		  >
		  make_post</button> 

		</div>

	<?php 

        include "log_in_its_done.php";
        echo $output_login;

    ?>  

	</div>



</div>


</body>
</html>
































