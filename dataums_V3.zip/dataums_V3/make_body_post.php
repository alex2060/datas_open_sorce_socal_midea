
<?php



function make_body($type_of_header,$result) {
$outputdivk   =array("0","10","2","3","4","5","6");

$array = array();

	if ($result->num_rows>0) {
//$count=0;
$outputdivk[0]="7";

   while($row = $result->fetch_assoc()) {
		
$outputdivk[3]="7";

					

			$C_tital=$row["tital"];
			$C_user=$row["flags"];

			$C_header=$row["disc"];

			$button="<button class= \"buttonkk\" onclick=\"window.location.href= 
				'http://alexhaussmann.com/adhaussmann/datas/viewpage.php?pageid=".$row["fild_id"]." '; \"> </button>";

			$content="<img   src=\"http://alexhaussmann.com/adhaussmann/datas/imgs/".$row["fild_id"]."\" alt=\"Girl in a jacket\" width=\"205\" height=\"205\"> ";

			if ($type_of_header=="board_seach") {
				$C_tital=$row["board"];		
				$C_user=$row["owner"];
				$C_header=$row["disc"];
				$button="<button class= \"buttonkk\" onclick=\"window.location.href= 
					'http://alexhaussmann.com/adhaussmann/datas/bord.php?board=".$row["board"]." '; \"> </button>";

				$content="<img   src=\"".$row["photo1"]."\" alt=\"Girl in a jacket\" width=\"205\" height=\"205\"> ";

			}


			if ($type_of_header=="post_id") {
				

				$C_user ="<button class= \"buttonkk\" onclick=\"window.location.href= 'somewhere.php' \"'> ".$row["user"]."</button>";
				$C_tital=$row["tital"];
				$content="<img   src=\"http://alexhaussmann.com/adhaussmann/datas/imgs/".$row["fild_id"]."\" alt=\"Girl in a jacket\" width=\"205\" height=\"205\"> ";
				$C_header=$row["header"];
				$button="<button class= \"buttonkk\" onclick=\"window.location.href= 
				'viewpage.php?pageid=".$row["fild_id"]." '; \"> </button>";

			}




			




			$outputdiv= "

			<div class=\"textbox\">
				<div class = \"textbody\">
					<div class =\"comnet_header\">
					".$C_tital."
					</br>
						<div class =\"user_header\">
							".$C_user."
						</div>
					</div>
					<div class =\"body_header\">
					  ".$C_header."
					  </br>
					</br>
				</br>
				</br>
				</br>
				".$button."
					</div>


				</div>
				
				<div class=\"viewimg\" >
			





				".$content."
			</div>

			</div>";


		array_push($array, $outputdiv);

	}


	}

return $array;




	}













?>
