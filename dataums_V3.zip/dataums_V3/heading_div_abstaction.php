<?php 



function make_headingdiv() {

/*
	if ($result_of_sql_qurry->num_rows>0) {


				$count=0;
				while($row = $result->fetch_assoc() and $count==0) {


				    $header=$row["header"];
				    $boady=$row["boady"];
				    $type=$row["type"];
				    $linked=$row["linked"];
				    $upvote=$row["upvote"];
				    $downvote=$row["downvote"];
				    $tital=$row["tital"];
				    $views=$row["views"];
				    $views_this_mouth=$row["views_this_mouth"];
				    $buypage=$row["buypage"];
				    $poster=$row["user"];
				    $sorce_H=["sorce"];
				    $diplayed_page="fild_id";

				    $count+=1;




			    
			  }

			//body handing to be immented
			$boady=$boady."</br> </br> </br> </br> </br> </br> </br> </br> </br> </br> </br>";

			// content handing to be implemented
			$content="
			<img style=\"float: right; padding: 0px 3px 0px 0px;\"src=\"".$linked."\"  
			alt=\"Girl in a jackets \" width=\"400\" height=\"200\">
			\ ";
					


				$heading_div="

			  		tital

			  		<div class=\"pic\"> </br>


				   </div> <div class=\"users\"> nobody</div>   <div class=\"tital\">header 

					</div>
					</br>
					".$content.$boady;


	}
*/
return "";
}






?>