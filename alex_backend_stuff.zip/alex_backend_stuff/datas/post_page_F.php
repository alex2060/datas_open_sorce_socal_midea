
<?php

session_start();
$uname=$_SESSION['uname'];


if ($uname=="") {
  $uname="nobody";
}



include("config.php");




$tital=$_GET["tital"];
$board=$_GET["board"];


$tital=$_POST["tital"];

$header=$_POST["header"];
$boady=$_POST["boady"];
$link=$_POST["link"];
$linkdisc=$_POST["linkdisc"];
$sorce=$_POST["sorce"];
$buy=$_POST["buy"];
$price=$_POST["price"];
$git_data=$_POST["git_data"];
$eamil_data=$_POST["eamil_data"];
$type=$_POST["type"];
$bord_I=$_POST["bord"];



$random_id=$uname1.time();

$buysend="0";
$price_send="5.00";



//fild_id
//user
//views views_this_mouth
//tital
//type
//header
//boady
//linked
//sorce
//upvote downvote buypage price git_data eamil_data

$sql="";

$herewego="notgood";



if ($link=="") {
  $herewego="inlink";
  if(isset($_FILES['image'])){
    $herewego="infile";
    $errors= array();
    $file_name = $_FILES['image']['name'];
    $file_size = $_FILES['image']['size'];
    $file_tmp = $_FILES['image']['tmp_name'];
    $file_type = $_FILES['image']['type'];
    $file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
    
    $extensions= array("jpeg","jpg","png");
    
    if(in_array($file_ext,$extensions)=== false){
       $errors[]="extension not allowed, please choose a JPEG or PNG file.";
    }
    if($file_size > 2097152) {
       $errors[]='File size must be excately 2 MB';
    }

    if(empty($errors)==true) {
       $output="".$uname.time()."_2";
       move_uploaded_file($file_tmp,"".$random_id);
       $fileMoved = rename($random_id, "imgs/".$random_id ) ;
       $link="http://alexhaussmann.com/adhaussmann/alex_backend_stuff/datas/imgs/".$random_id;
       $herewego="ture";
    }else{
       print_r($errors);
    }
  }

}


$here="1";
if ($tital!=""){
  $here="done";
$sql="INSERT INTO `post_2` (`fild_id`, `user`, `views`, `views_this_mouth`, `tital`, `type`, `header`, `boady`, `linked`, `sorce`, `upvote`, `downvote`, `buypage`, `price`, `git_data`, `eamil_data`,`created`) VALUES 
   ('".$random_id."', 
   '".$uname."',
   '0', '0', 
   '".$tital."', 
   '".$type."', 
   '".$header."', 
   '".$boady."', 
   '".$link."', 
   '".$sorce."', 
   '0', '0', '".$buy."', 
   '".$price."', 
   '".$git_data."', 
   '".$eamil_data."'
   ,CURRENT_TIMESTAMP); ";
  
  $result = $conn->query($sql);
  


if( $bord_I=="")
{
$bord_I="all";

}
$sql1 =  "INSERT INTO `board_post_table_holder_3_2` (`board`, `postid`, `dic`, `user`, `upvotes`, `downvotes`,`time`)
  VALUES 
    ('".$bord_I."', 
    '".$random_id."', 
    '".$header."', 
    '".$uname."', 
    '0', 
    '0',
    CURRENT_TIMESTAMP);";


  $result = $conn->query($sql1);
  header("Location:http://alexhaussmann.com/adhaussmann/datas/viewpage.php?pageid=".$random_id."");

}


//$result = $conn->query($sql);





//INSERT INTO `treelose_data` (`user`, `postid`, `board`, `ban_type`) VALUES ('thiz_user', '12911', 'bord1', 'type1');


/*
  CREATE TABLE `treelose_data`.post` (
  `fild_id` VARCHAR(64) NOT NULL , 
  `user` TEXT NOT NULL , 
  `views` INT NOT NULL , 
  `views_this_mouth` INT NOT NULL , 
  `tital` TEXT NOT NULL , 
  'type' TEXT NOT NULL,
  `header` TEXT NOT NULL , 
  `boady` TEXT NOT NULL , 
  `linked` TEXT NOT NULL , 
  `sorce` TEXT NOT NULL , 
  `upvote` INT NOT NULL , 
  `downvote` INT NOT NULL, 
  `buypage` BOOLEAN not Null, 
  `price` FLOAT not Null, 
  `git_data` Text not Null, 
  `eamil_data` Text not NUll,
  PRIMARY KEY (fild_id) ) ENGINE = MyISAM

*/


/* 

CREATE TABLE `treelose_data`.`upvote_table` 
( `user` VARCHAR(100) NOT NULL , 
 `post_id` INT(64) NOT NULL , 
 `bord` VARCHAR(200) NOT NULL , 
 `vote` INT NOT NULL , 
 `downvote` BOOLEAN NOT NULL,
PRIMARY KEY (user,post_id,bord) ) ENGINE = MyISAM; 


*/

/*
 add to bord form tabel
 
*/



?>





<html>
  <head>
    <style>
      <?php
        include "style/seach_page_style.php";
        echo $post_page_css;
      ?>
    </style>
  </head>
  
  <body>

  <div class = "phote">

    <div class = "header">
      <h2>post page</h2>


              <?php include "style/heading_nav.php";

              echo $header_nav_for_sight;

              ?>

      <div class = "body_top">
        expalination
      </div>
      <form action = "" method = "POST" enctype = "multipart/form-data">

            <label for="login">tital</label><br>
            <input type="tital" id="tital" name="tital" value=""><br>


            <label for="login">header</label><br>
            <input type="header" id="header" name="header" value=""><br>

            <label for="login">boady</label><br>
            <input type="boady" id="boady" name="boady" value=""><br>



            <input type = "file" name = "image" />



            </br>
            <label for="login">linked file discription</label><br>
            <input type="linked" id="linkdisc" name="linkdisc" value=""><br>


            <label for="login">bord</label><br>
            <input type="linked" id="bord" name="bord" value=<?php echo "\"".$_GET["board"]."\"";?> ><br>


            <label for="sorce">sorce file11</label><br>
            <input type="linked" id="sorce" name="sorce" value=<?php echo "\"".$_GET["sorce"]."\""; ?> > <br>
            type<br>
            <select name="buy" id="type">
            <option value="text">text</option>
            <option value="video">video</option>
            <option value="img">img</option>
            </select>
            </br>


            buyable<br>
            <select name="buy" id="buy">
            <option value="True">true</option>
            <option value="False">Saab</option>
            </select>

            <br>
            price<br>
            <select name="buy" id="price">
            <option value="5.00">5.00</option>
            <option value="10.00">10.00</option>
            <option value="20.00">20.00</option>
            </select>
            </br>


            <br>
            <label for="sorce">eamil_data</label><br>
            <input type="linked" id="eamil_data" name="eamil_data" value=""><br>

            <label for="sorce">git_data</label><br>
            <input type="linked" id="git_data" name="git_data" value=""><br>

            <input type="submit">
      </form> 


      <?php 

        include "style/log_in_its_done.php";
        echo $output_login;

      ?>  

    </div>

  </div>


  </body>
</html>














