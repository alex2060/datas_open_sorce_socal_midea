<!DOCTYPE html>
<html lang="">
<head>
	<meta charset="utf-8">
	<title>Example Title</title>
	<meta name="author" content="Your Name">
	<meta name="description" content="Example description">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--Links-->
    <link rel="stylesheet" href="Assets/Style/bootstrap.min.css"/>
    <link rel="stylesheet" href="Assets/Style/index.css"/>
    <link rel="stylesheet" href="Assets/Style/all.min.css"/>
	<link rel="icon" type="image/x-icon" href="Assets/Image/"/>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="Assets/Style/animate.css">






</head>

<body>  
<!--header-->
    <header>
       




        <div class="container">
            <div class="row">
                <div class="col-md-6 order-2">
                    <div class="hero__text">
                        <!--text header-->
                        <h1 class="wow bounce" data-wow-duration='2s'>In it except to so temper mutual tastes mother. Interested cultivated its continuing now yet are. Out interested accep</h1>
                        <p class=" wow bounce" data-wow-duration='3s'>Had denoting properly jointure you occasion directly raillery. In said to of poor full be post face snug. Introduced imprudence see say unpleasing devonshire acceptance son. Exeter longer wisdom gay nor design age. Am weather to entered norland no in showing service. Nor repeated speaking shy appetite. Excited it hastily an pasture it observe. Snug hand how dare here too. Improve ashamed married expense bed her comfort pursuit mrs. Four time took ye your as fail lady. Up greatest am exertion or marianne. Shy occasional terminated insensible and inhabiting gay. So know do fond to half on. Now who promise was justice new winding. In finished on he speaking suitable advanced if. Boy happiness sportsmen say prevailed offending concealed nor was provision. Provided so as doubtful on striking required. Waiting we to compass assured.</p>
                    </div>
                </div> 
                <div class="col-md-6 order-1">
                    <!--img-header-->
                    <img src="Assets/Image/headerImg.jpg" class="img-fluid ">
                </div>
            </div> 
        </div>




    </header>  



   <!--form -->
    <section class="form__section">
        



        <div class="container">
            <form class="d-flex justify-content-between flex-column  flex-wrap align-item-center form__enquery">
                <!--title --> 
                <h2 class="name">make post </h2>
                <!--input container --> 
                <div class="d-flex justify-content-order align-item-start form__name">
                        <input type="text" class="firstname"  placeholder="user search ">
                        <input class="lastname" type="text" placeholder="header ">
                </div>
                <!--input container -->
                <div class="d-flex justify-content-order align-item-start form__name">
                        <input class="company" type="text"  placeholder="boady_seach">
                        <input class="company" type="text"  placeholder="seach_item">
                </div>
                <!--input email  -->
                <input class="email" type="seach_page"  placeholder="seach_page">
                <!--option -->
                <div class="options mb-4 d-flex align-item-start">
                    <select id="cars " class="mr-3">
                      <option value="volvo">or exclusion</option>
                      <option value="saab">and exclusion</option>
                      <option value="opel">or inclusion </option>
                      <option value="audi">and inclusion</option>
                    </select>
                    <select id="cars">
                      <option value="volvo">time </option>
                      <option value="saab">top</option>
                      <option value="opel">hot</option>
                    </select>
                </div>
                <div class="d-flex justify-content-between flex-wrap" >
                    <!--button  -->
                    <button class="button-primary">search form  </button>
                </div>
            </form>
        </div>





    </section>
<!--section about one -->
    <section>
        <div class="container">
            <div class="row">
                <div class="col-md-6  wow bounceInLeft" data-wow-duration='2s'>
                    <!--img about-->
                    <img class="img-fluid" src="Assets/Image/1609.jpg">
                </div>
                <div class="col-md-6 wow bounceInRight" data-wow-duration='2s'>
                       <!--about info -->
                        <div class="text__about">
                            <h2>Another journey chamber way</h2>
                            <p class="text__down">In it except to so temper mutual tastes mother. Interested cultivated its continuing now yet are. Out interested accep</p>
                            <button class="button-primary"> show it </button>
                        </div>
                </div>
            </div>
        </div>
    </section>
<!--section About two   -->




    <section>
        <div class="container">
            <div class="row">
                <div class="col-md-6 wow bounceInRight text-center" data-wow-duration='2s'>
                    <!--img about-->
                    <img class="img-fluid" src="Assets/Image/1609675783.png">
                </div>
                <div class="col-md-6  wow bounceInLeft" data-wow-duration='2s'>
                       <!--about info -->
                        <div class="text__about">
                            <h2>Effect if in up no depend seemed. Ecs</h2>
                            <p class="text__down">You disposal strongly quitting his endeavor two settling him. Manners ham him hearted hundred expense. Get open game him what hour more part. Adapted as smiling of females oh me journey exposed concern. Met come add cold calm rose mile what. Tiled manor court at built by place fa</p>
                            <button class="button-primary"> show it </button>
                        </div>
                </div>
            </div>
        </div>
    </section>
<!--section About three  -->
    <section>
        <div class="container">
            <div class="row">
                <div class="col-md-6  wow bounceInLeft" data-wow-duration='2s'>
                    <!--img about-->
                    <img class="img-fluid" src="Assets/Image/1609675783.png">
                </div>
                <div class="col-md-6  wow bounceInRight" data-wow-duration='2s'>
                       <!--about info -->
                        <div class="text__about">
                            <h2>hero </h2>
                            <p class="text__down">dsfasdfsafsagfadfdagaesfgas</p>
                            <button class="button-primary"> show it </button>
                        </div>
                </div>
            </div>
        </div>
    </section>
<!--section About four   -->
    <section>
        <div class="container">
            <div class="row">
                <div class="col-md-6 wow bounceInRight" data-wow-duration='2s'>
                    <!--img about-->
                    <img class="img-fluid" src="Assets/Image/headerImg.jpg">
                </div>
                <div class="col-md-6  wow bounceInLeft" data-wow-duration='2s'>
                       <!--about info -->
                        <div class="text__about">
                            <h2>ayyy</h2>
                            <p class="text__down">asdajdalsdaskds</p>
                            <button class="button-primary"> show it </button>
                        </div>
                </div>
            </div>
        </div>
    </section>



<!--section About five -->    
    <section class="mb-5">
        <div class="container">
            <div class="row">
                <div class="col-md-6  wow bounceInRight" data-wow-duration='2s'>
                    <!--img about-->
                    <img class="img-fluid" src="Assets/Image/headerImg.jpg">
                </div>
                <div class="col-md-6  wow bounceInLeft" data-wow-duration='2s'>
                       <!--about info -->
                        <div class="text__about">
                            <h2>ayyy</h2>
                            <p class="text__down">asdajdalsdaskds</p>
                            <button class="button-primary"> show it </button>
                        </div>
                </div>
            </div>
        </div>
    </section>

<!-- outptu-->


    <section>
        <div class="container">
            <div class="row">
                <div class="col-md-6 wow bounceInRight" data-wow-duration='2s'>
                    <!--img about-->
                    <img class="img-fluid" src="Assets/Image/headerImg.jpg">
                </div>
                <div class="col-md-6  wow bounceInLeft" data-wow-duration='2s'>
                       <!--about info -->
                        <div class="text__about">
                            <h2>ayyy</h2>
                            <p class="text__down">asdajdalsdaskds</p>
                            <button class="button-primary"> show it </button>
                        </div>
                </div>
            </div>
        </div>
    </section>


<!--pagination-->




    <section class="pagination">
        <div class="container">
            <nav aria-label="Page navigation example">
              <ul class="pagination">
                <li class="page-item">
                  <a class="page-link" href="#" aria-label="Previous">
                    <span aria-hidden="true">&laquo;</span>
                  </a>
                </li>
                <li class="page-item"><a class="page-link" href="#">1</a></li>
                <li class="page-item"><a class="page-link" href="#">2</a></li>
                <li class="page-item"><a class="page-link" href="#">3</a></li>
                <li class="page-item">
                  <a class="page-link" href="#" aria-label="Next">
                    <span aria-hidden="true">&raquo;</span>
                  </a>
                </li>
              </ul>
            </nav>
        </div>
    </section>
    
<!--footer -->
    <footer>
        COPY RIGHT 
    </footer>
    
<!--script content -->
    <script src="Assets/JS/jquery-3.4.1.min.js"></script>
    <script src="Assets/JS/popper.js"></script>
    <script src="Assets/JS/bootstrap.min.js"></script>
    <script src="Assets/JS/wow.min.js"></script>              
    <script type="text/javascript" src="./Assets/JS/index.js"></script>
</body>

</html>