<?php 

$heading_div="trolllllll";

function make_headingdiv($type_of_header,$result_of_sql_qurry) {

 		


 		
	if ($result_of_sql_qurry->num_rows>0) {
				$count=0;
				$count2=0;
			//effects viww page

			if($type_of_header=="Vpage"){
					while($row = $result_of_sql_qurry->fetch_assoc() and $count==0) {
					    $header=$row["header"];
					    $boady=$row["boady"];
					    $type=$row["type"];
					    $linked=$row["linked"];
					    $upvote=$row["upvote"];
					    $downvote=$row["downvote"];
					    $tital=$row["tital"];
					    $views=$row["views"];
					    $views_this_mouth=$row["views_this_mouth"];
					    $buypage=$row["buypage"];
					    $poster=$row["user"];
					    $sorce_H=["sorce"];
					    $diplayed_page="fild_id";
					    $count+=1;			    
				}


				$page_viewed=$diplayed_page;
				$name=$poster;
				//body handing to be immented
				$boady=$boady."</br> </br> </br> </br> </br> </br> </br> </br> </br> </br> </br>";

				// content handing to be implemented
				$content="
				<img style=\"float: right; padding: 0px 3px 0px 0px;\"src=\"".$linked."\"  
				alt=\"Girl in a jackets \" width=\"401\" height=\"200\">
				\ ";

				$content="<img src=\"".$linked."\" class=\"img-fluid \">";
				


			}



			if($type_of_header=="Bpage"){
				
					while($row = $result_of_sql_qurry->fetch_assoc() and $count==0) {

					$board=$row["board"];
					$photo1=$row["photo1"];
					$disc=$row["disc"];
					$rules=$row["rules"];
					$owner=$row["owner"];

					}
					$name=$owner;


					$tital=$board;
					$header=$diplayed_page."

					<button onclick=\"myFunction()\">rules</button>
					<p id=\"b_rules\"></p>
					<script>
					function myFunction() {
					  document.getElementById(\"b_rules\").innerHTML = \"".$rules."\";
					}
					</script>

					";
					//body handing to be immented

					$boady=$disc."</br> </br> </br> </br> </br> </br> </br> </br> </br> </br> </br>";

					// content handing to be implemented
					$content="<img style=\"float: right; padding: 0px 3px 0px 0px;\"src=\"".$photo1."\"  
					alt=\"Girl in a jacketsssss \" width=\"400\" height=\"200\">
					\ ";
					$page_viewed=$board;


			}




			/*

			this bit

			*/



			/*
			$heading_div=$page_viewed."

		  		<div class=\"pic\"> </br>


			   </div> <div class=\"users\"> ".$name."</div>   <div class=\"tital\">".$header." 

				</div>
				</br>
				".$content.$boady;
			*/

				$heading_div="
				    <header>
				        <div class=\"container\">
				            <div class=\"row\">
				                <div class=\"col-md-6 order-2\">
				                    <div class=\"hero__text\">
				                        <!--text header-->
				                        <h1 class=\"wow bounce\" data-wow-duration='2s'>".$name."</br>".$header."</h1>
				                        <p class=\" wow bounce\" data-wow-duration='3s'>".$boady."</p>
				                    </div>
				                </div> 
				                <div class=\"col-md-6 order-1\">
				                    <!--img-header-->
				                    ".$content."

				                </div>
				            </div> 
				        </div>
				    </header> ";




	}


return array($heading_div,$page_viewed);


}






?>