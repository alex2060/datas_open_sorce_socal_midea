
<?php

$post_page_css="

body {
	  background-image: url('https://wallpapercave.com/wp/8Ktr9Qn.jpg');
	}


	.phote{
width: 830px;
border: 5px solid gray;
background-image: url('https://metal.graphics/files/matte/matte-black-background.jpg');
color: rgb(255,255,255);


}

.header{
	width: 820px;

	font-size: 20px;
	color: rgb(255,255,255);
	border: 5px solid gray;
}

.header__1{	
	width: 820px;
	font-size: 30px;
	color: rgb(255,255,255);
	border: 5px solid gray;
}


.textbox{
	width: 800px;
	font-size: 20px;
	color: rgb(255,255,255);
	border: 5px solid gray;
	padding: 10px;
}

.nextthing{
	width: 820px;

	font-size: 20px;
	color: rgb(255,255,255);
	border: 5px solid gray;
}

.body_top{
	width: 820px;
font-size: 30px;
	font-size: 10px;
	color: rgb(255,255,255);
	border: 5px solid gray;
}


.viewimg{
	text-align:right;


}


.tital{
font-size: 30px;
}


.users{
font-size: 15px;
}


.upvote{

	font-size: 15px
}
.pic{
	float: right;

}

.postHead{

	font-size: 25px;
}


.buttonkk { 
height: 20px; 
width: 20px; 



} 

.comnet_header{
	font-size: 35px;
	border: 5px solid gray;
	width: 571px;

	text-overflow: ellipsis;
}

.body_header{
	font-size: 20px;
	border: 5px solid gray;
	width: 571px;

}

.textbody{
	float: left;
	width: auto;

}


.user_header{
	font-size: 15px;

}

";


?>