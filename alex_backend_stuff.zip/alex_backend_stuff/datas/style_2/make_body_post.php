
<?php



function make_body($type_of_header,$result) {
$array = array();

	if ($result->num_rows>0) {
		while($row = $result->fetch_assoc()) {
				$C_tital=$row["tital"];
				$C_user=$row["flags"];

				$C_header=$row["disc"];

				$button="<button class= \"buttonkk\" onclick=\"window.location.href= 'viewpage.php?pageid=".$row["fild_id"]." '; \"> </button>";

				$content="<img   src=\"imgs/".$row["fild_id"]."\" alt=\"fail\" style=\"width:205px;height:205px;\" width=\"205\" height=\"205\"> ";

				if ($type_of_header=="board_seach") {
						
					$C_user="<button class= \"buttonkk\" onclick=\"window.location.href= 'somewhere.php' \"'> ".$row["owner"]."</button>";
					$C_tital=$row["board"];	
					$C_header=$row["disc"];
					$button="<button class= \"button-primary\" onclick=\"window.location.href= '/bord.php?board=".$row["board"]." '; \"> </button>";
					$content="<img class=\"img-fluid\" src=\"".$row["photo1"]."\">";
				}


				if ($type_of_header=="post_id") {
						$C_user ="<button class= \"buttonkk\" onclick=\"window.location.href= 'somewhere.php' \"'> ".$row["user"]."</button>";
						$C_tital=$row["tital"];
						$content="<img class=\"img-fluid\" src=\"imgs/".$row["fild_id"]."\">";
						$C_header=$row["header"];
						$button="<button class= \"button-primary\" onclick=\"window.location.href= 
						'v2.php?pageid=".$row["fild_id"]." '; \"> </button>";
				}




$outputdiv=
	"<section>
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-md-6  wow bounceInLeft\" data-wow-duration='2s'>
                    <!--img about-->
                    ".$content."


                </div>
                <div class=\"col-md-6 wow bounceInRight\" data-wow-duration='2s'>
                       <!--about info -->
                        <div class=\"text__about\">
                            <h2>Another journey chamber way</h2>
                            <p class=\"text__down\">".$C_tital.
                            "</br>".$C_user.
                            "</br>".$C_header.
                            "</br>".$button."
                        </div>
                </div>
            </div>
        </div>
    </section>";


			array_push($array, $outputdiv);

		}


	}
$array[0]=$array[0]."";

return $array;




	}













?>
