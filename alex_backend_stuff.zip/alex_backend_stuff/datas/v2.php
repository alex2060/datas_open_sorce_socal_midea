<?php

session_start();
$uname=$_SESSION['uname'];

if ($uname=="") {
  $uname="nobody";
}
include("config.php");


//UPDATE video_table SET viewed_count=viewed_count+1 WHERE SELECT * FROM video_table WHERE DATE='today'

/*  
    CREATE TABLE `treelose_data`.`post` (   ,
    `fild_id` VARCHAR(64) NOT NULL          , 
    `user` TEXT NOT NULL                    , 
    `views` INT NOT NULL                    , 
    `views_this_mouth` INT NOT NULL         , 
    `tital` TEXT NOT NULL                   , 
    `type` TEXT NOT NULL                    ,
    `header` TEXT NOT NULL                  , 
    `boady` TEXT NOT NULL                   , 
    `linked` TEXT NOT NULL                  , 
    `sorce` TEXT NOT NULL                   , 
    `upvote` INT NOT NULL                   , 
    `downvote` INT NOT NULL                 , 
    `buypage` BOOLEAN not Null              , 
    `price` FLOAT not Null                  , 
    `git_data` Text not Null                , 
    `eamil_data` Text not NUll              ,
    `created` TIMESTAMP NOT NULL            ,  
    PRIMARY KEY (fild_id) ) ENGINE = MyISAM ;
*/

$pageid=$_GET["pageid"];
$uname_S=$_GET["uname"];
$header_S=$_GET["header"];
$seach_item=$_GET["seach_item"];
$type=$_GET["type"];
$combo_type=$_GET["combo_type"];

if($pageid==""){
$pageid="%%";
}


if($pageid=="all"){
$pageid="%%";
}


//output as $content for heaing of webpage  -- 
$sql ="SELECT * FROM `post_2` WHERE `fild_id` LIKE '".$pageid."' LIMIT 1;";
$result = $conn->query($sql);
$heading_div="nodiv";
$input_type="Vpage";
include "style_2/heading_div_ab.php";

$heading_obj=make_headingdiv("Vpage",$result);
$heading_div=$heading_obj[0];
/*
    $sql_view="UPDATE video_table SET views=views+10 WHERE `fild_id` Like ".$heading_obj[1]."' ;";
    $result = $conn->query($sql_view);
    $sql_view_M="UPDATE video_table SET views_this_mouth=views_this_mouth+10 WHERE `fild_id` Like ".$heading_obj[1]."' ;";
    $result = $conn->query($sql_view_M);
*/

include("seach.php");
$sql2= get_seach_sql_with_3_flags(
        "",
        $pageid,
        "",
        $combo_type,
        $uname_S,"user",
        $seach_item,"boady",
        $header_S,"header",
        $items_return,
        6,
        0,
        ""
);
include "style_2/make_body_post.php";
$result = $conn->query($sql2);
$outputdiv=make_body("post_id",$result);


?>




<!DOCTYPE html>
<html lang="">
<head>
	<meta charset="utf-8">
	<title>Example Title</title>
	<meta name="author" content="Your Name">
	<meta name="description" content="Example description">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--Links-->
    <link rel="stylesheet" href="Assets/Style/bootstrap.min.css"/>
    <link rel="stylesheet" href="Assets/Style/index.css"/>
    <link rel="stylesheet" href="Assets/Style/all.min.css"/>
	<link rel="icon" type="image/x-icon" href="Assets/Image/logo2.png"/>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="Assets/Style/animate.css">

</head>

<body>  
<!--header-->
<?php echo $heading_div; ?>





   <!--form -->
    <section class="form__section">
        <div class="container">
            <form class="d-flex justify-content-between flex-column  flex-wrap align-item-center form__enquery">
                <!--title --> 
                <h2 class="name">make post </h2>
                <!--input container --> 
                <div class="d-flex justify-content-order align-item-start form__name">
                        <input type="text" class="firstname"  placeholder="user search ">
                        <input class="lastname" type="text" placeholder="header ">
                </div>
                <!--input container -->
                <div class="d-flex justify-content-order align-item-start form__name">
                        <input class="company" type="text"  placeholder="boady_seach">
                        <input class="company" type="text"  placeholder="seach_item">
                </div>
                <!--input email  -->
                <input class="email" type="seach_page"  placeholder="seach_page">
                <!--option -->
                <div class="options mb-4 d-flex align-item-start">
                    <select id="cars " class="mr-3">
                      <option value="volvo">or exclusion</option>
                      <option value="saab">and exclusion</option>
                      <option value="opel">or inclusion </option>
                      <option value="audi">and inclusion</option>
                    </select>
                    <select id="cars">
                      <option value="volvo">time </option>
                      <option value="saab">top</option>
                      <option value="opel">hot</option>
                    </select>
                </div>
                <div class="d-flex justify-content-between flex-wrap" >
                    <!--button  -->
                    <button class="button-primary">search form  </button>
                </div>
            </form>
        </div>
    </section>
<!--section about one -->


            <?php 
                $i = 0;
                while ($i < count($outputdiv) )
                {
                    echo $outputdiv[$i] ."<br />";
                    $i++;
                }
            ?>


    
<!--footer -->
    <footer>
        COPY RIGHT 
    </footer>
    
<!--script content -->
    <script src="Assets/JS/jquery-3.4.1.min.js"></script>
    <script src="Assets/JS/popper.js"></script>
    <script src="Assets/JS/bootstrap.min.js"></script>
    <script src="Assets/JS/wow.min.js"></script>              
    <script type="text/javascript" src="./Assets/JS/index.js"></script>
</body>

</html>