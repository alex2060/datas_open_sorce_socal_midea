<?php 
session_start();

include("config.php");

$output="";
$uname=$_GET["uname"];
$password2=$_GET["password"];
$sql1 = "SELECT * FROM user_T_2 WHERE user LIKE '".$uname."' and pass LIKE '".$password2."';";

$result = $conn->query($sql1);

if ($uname!="") {

	if($result->num_rows==1){
		$_SESSION['uname']=$uname;
		header("Location: http://alexhaussmann.com/adhaussmann/datas/viewpage.php");
		$output="loged in as ".$uname." " ;
	}

	else{
		$output="not loged in";
	}
	# code...
}

$uname=$_SESSION['uname'];
if ($uname=="") {
  $uname="nobody";
}


/*
if ($result->num_rows!=0){
	$_SESSION['uname']
	$output="loged in as".$uname."here";
}

$output="wrong user name of password ";



/*
CREATE TABLE `treelose_data`.`__users` (
 `user` VARCHAR(100) NOT NULL , 
 `payment` TEXT NOT NULL , 
 `created` TIMESTAMP NOT NULL , 
 `email` TEXT NOT NULL , 
 `phone number` INT NOT NULL , 
 `paymentkey` TEXT NOT NULL , 
 `pass` TEXT NOT NULL, 
 PRIMARY KEY (user) ) ENGINE = MyISAM
*/



?>

<html>
  <head>
    <style>
      <?php
        include "style/seach_page_style.php";
        echo $post_page_css;
      ?>
    </style>
  </head>
  
  <body>

  <div class = "phote">

    <div class = "header">
      <h2>sighn up</h2>
              <?php 
                    include "style/heading_nav.php";
                    echo $header_nav_for_sight;
              ?>
      <div class = "body_top">
      expalination
      </div>

  		<form action="log_in.php">
  		  <label for="login">uname</label><br>
  		  <input type="uname" id="uname" name="uname" value=""><br>
  		  <label for="login">password</label><br>
  		  <input type="password" id="password" name="password" value=""><br>
  		  <input type="submit" value="Submit">
  		</form> 
		 <button type="button"  
		 onclick="window.location.href='http://alexhaussmann.com/adhaussmann/datas/sighnup.php';">sighnup</button> 
      <?php 
        include "log_in_its_done.php";
        echo $output_login;
      ?>  
    </div>
  </div>


  </body>
</html>











