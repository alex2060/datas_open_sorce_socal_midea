<?
$output_login="";
if ($uname=="nobody") {

	$output_login="
<div class=\"textbox\">

	your loged in as ".$uname." 
 <button type=\"button\"  
onclick=\"window.location.href='http://alexhaussmann.com/adhaussmann/datas/log_in.php';\"

 >log in as not nobody</button> 

	"."
</div>
	";
}
else{
$output_login="<div class=\"textbox\">

	your loged in as ".$uname." 
</div>
	";
}





?>	