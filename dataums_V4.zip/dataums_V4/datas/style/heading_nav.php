 <?php $header_nav_for_sight="<button type=\"button\"  
onclick=\"window.location.href='https://www.w3docs.com';\"

 >upload</button> 

 <button type=\"button\"  
onclick=\"window.location.href='http://alexhaussmann.com/adhaussmann/datas/post_page_F.php';\"

 >make post</button> 



 <button type=\"button\"  
onclick=\"window.location.href='http://alexhaussmann.com/adhaussmann/datas/bord_search.php';\"

 >seach board</button> 


 <button type=\"button\"  
onclick=\"window.location.href='http://alexhaussmann.com/adhaussmann/datas/viewpage.php';\"

 >seach posts</button> 



 <button type=\"button\"  
onclick=\"window.location.href='http://alexhaussmann.com/adhaussmann/datas/post_bord.php';\"

 >make bord</button> 
</div>"

?>