
<?php



function make_body($type_of_header,$result) {
$array = array();

	if ($result->num_rows>0) {
		while($row = $result->fetch_assoc()) {
				$C_tital=$row["tital"];
				$C_user=$row["flags"];

				$C_header=$row["disc"];

				$button="<button class= \"buttonkk\" onclick=\"window.location.href= 'viewpage.php?pageid=".$row["fild_id"]." '; \"> </button>";

				$content="<img   src=\"imgs/".$row["fild_id"]."\" alt=\"fail\" style=\"width:205px;height:205px;\" width=\"205\" height=\"205\"> ";

				if ($type_of_header=="board_seach") {
					$C_tital=$row["board"];		
					$C_user=$row["owner"];
					$C_header=$row["disc"];
					$button="<button class= \"buttonkk\" onclick=\"window.location.href= '/bord.php?board=".$row["board"]." '; \"> </button>";
					$content="<img   src=\"".$row["photo1"]."\" alt=\" fail\"  style=\"width:205px;height:205px;\" width=\"205\" height=\"205\"> ";

				}


				if ($type_of_header=="post_id") {
						$C_user ="<button class= \"buttonkk\" onclick=\"window.location.href= 'somewhere.php' \"'> ".$row["user"]."</button>";
						$C_tital=$row["tital"];
						$content="<img   src=\"imgs/".$row["fild_id"]."\" alt=\"fail \"  style=\"width:205px;height:205px;\" width=\"205\" height=\"205\"> ";
						$C_header=$row["header"];
						$button="<button class= \"buttonkk\" onclick=\"window.location.href= 
						'viewpage.php?pageid=".$row["fild_id"]." '; \"> </button>";
				}


				$outputdiv= "

				<div class=\"textbox\">
					<div class = \"textbody\">
						<div class =\"comnet_header\">
						".$C_tital."
						</br>
							<div class =\"user_header\">
								".$C_user."
							</div>
						</div>
						<div class =\"body_header\">
						  ".$C_header."
						  </br>
						</br>
					</br>
					</br>
					</br>
					".$button."
						</div>


					</div>
					
					<div class=\"viewimg\" >
				

					".$content."
				</div>

				</div>";


			array_push($array, $outputdiv);

		}


	}
$array[0]=$array[0]."";

return $array;




	}













?>
