<?php

session_start();
$uname=$_SESSION['uname'];

if ($uname=="") {
  $uname="nobody";
}
include("config.php");


//UPDATE video_table SET viewed_count=viewed_count+1 WHERE SELECT * FROM video_table WHERE DATE='today'

/*	
	CREATE TABLE `treelose_data`.`post` (   ,
	`fild_id` VARCHAR(64) NOT NULL 			, 
	`user` TEXT NOT NULL 					, 
	`views` INT NOT NULL 					, 
	`views_this_mouth` INT NOT NULL 		, 
	`tital` TEXT NOT NULL 					, 
	`type` TEXT NOT NULL  					,
	`header` TEXT NOT NULL    				, 
	`boady` TEXT NOT NULL     				, 
	`linked` TEXT NOT NULL    				, 
	`sorce` TEXT NOT NULL     				, 
	`upvote` INT NOT NULL     				, 
	`downvote` INT NOT NULL   				, 
	`buypage` BOOLEAN not Null  			, 
	`price` FLOAT not Null 					, 
	`git_data` Text not Null 				, 
	`eamil_data` Text not NUll 				,
	`created` TIMESTAMP NOT NULL 			,  
	PRIMARY KEY (fild_id) ) ENGINE = MyISAM ;
*/

$pageid=$_GET["pageid"];
$uname_S=$_GET["uname"];
$header_S=$_GET["header"];
$seach_item=$_GET["seach_item"];
$type=$_GET["type"];
$combo_type=$_GET["combo_type"];

if($pageid==""){
$pageid="%%";
}


if($pageid=="all"){
$pageid="%%";
}


//output as $content for heaing of webpage  -- 
$sql ="SELECT * FROM `post` WHERE `fild_id` LIKE '".$pageid."' LIMIT 1;";
$result = $conn->query($sql);
$heading_div="nodiv";
$input_type="Vpage";
include "style/heading_div_ab.php";
//heading div output div
$heading_obj=make_headingdiv("Vpage",$result);
$heading_div=$heading_obj[0];
/*
	$sql_view="UPDATE video_table SET views=views+10 WHERE `fild_id` Like ".$heading_obj[1]."' ;";
	$result = $conn->query($sql_view);
	$sql_view_M="UPDATE video_table SET views_this_mouth=views_this_mouth+10 WHERE `fild_id` Like ".$heading_obj[1]."' ;";
	$result = $conn->query($sql_view_M);
*/

include("seach.php");
$sql2= get_seach_sql_with_3_flags(
		"",
		$pageid,
		"",
		$combo_type,
		$uname_S,"user",
		$seach_item,"boady",
		$header_S,"header",
		$items_return,
		6,
		0,
		""
);
include "style/make_body_post.php";
$result = $conn->query($sql2);
$outputdiv=make_body("post_id",$result);


?>


<!DOCTYPE html>
<html>
<head>
<style>

	<?php
		include "style/seach_page_style.php";
		echo $post_page_css;
	?>

</style>
</head>
<body>

<div class = "phote">

	<div class = "header">
		<?php echo $heading_div;?>
		<?php 
			include "style/heading_nav.php"; 
			echo $header_nav_for_sight; 
		?>
		<div class = "body_top">

			<form>
				<label for="fname">user_seach</label>
				<input type="text" id="user_seach" name="user_seach">
				<label for="lname">header</label>
				<input type="text" id="header" name="header">
				<label for="lname">boady_seach</label>
				<input type="text" id="boady_seach" name="boady_seach">
				<label for="lname">seach_item</label>
				<input type="text" id="seach_item" name="seach_item">

				<label for="lname">seach_page</label>
				<input type="text" id="pageid" name="pageid" value=<?php echo "\"".$pageid."\""?>>
			   

				<select name="combo_type" id="type">

					  <option value="or_e">or exclusive</option>

					  <option value="and_e">and exclusive</option>

					  <option value="or_i">or inclusive</option>

					  <option value="and_i">and inclusive</option>

				</select>


				<select name="order_type" id="type">

				  <option value="time">time</option>

				  <option value="top">top</option>

				  <option value="hot">hot</option>
			  
				</select>


				<input type="submit" value="search form">
			</form> 



		</div>
			<?php 
				$i = 0;
		        while ($i < count($outputdiv) )
		        {
		            echo $outputdiv[$i] ."<br />";
		            $i++;
		        }
		    ?>
		<div class="nextthing">

				<button type="button" 
					onclick="window.location.href='something.php';">
					next</button>
				<button type="button"  
					onclick="window.location.href='something.php';">
					previose</button>
					upvote downvote
				<button type="button" 
					onclick=<?php echo "\"window.location.href='post_page_F.php?sorce=".$pageid."';\"";?> >
					post reply</button> 

				<button type="button" 
					onclick= <?php echo "\"window.location.href='post_to_bord.php?post_id=".$pageid."';\"";?> >
					post to bord</button> 

			    </br>

		</div>

		

		<?php 

	        include "style/log_in_its_done.php";
	        echo $output_login;

	    ?>  
    	</div>
	</div>


</div>


</body>
</html>
























