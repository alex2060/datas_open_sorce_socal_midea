<?php
$sitename="alex";
$addminpass="passaddmin";
?>