<?php


session_start();
include("web_name.php");
if( $_SESSION['logedin']==""){
    header("Location: log_in.php?");
}

$uname=$_SESSION['uname'];
if ($uname=="") {
  $uname="nobody";
}
include("config.php");



$tital=$_POST["tital"];

$header=$_POST["header"];
$boady=$_POST["boady"];
$link=$_POST["link"];

$comtype=$_POST["dropdown"];
$linkdisc=$_POST["linkdisc"];


$sorce=$_POST["sorce"];


$buy=$_POST["buy"];
$price=$_POST["price"];
$git_data=$_POST["git_data"];
$eamil_data=$_POST["eamil_data"];
$type=$_POST["type"];
$bord_I=$_POST["bord"];

$herewego="nothing";

$random_id=$uname1.time();

$buysend="0";
$price_send="5.00";

$output=$tital." heres ".$comtype;



//fild_id
  //user
  //views views_this_mouth
  //tital
  //type
  //header
  //boady
  //linked
  //sorce
//upvote downvote buypage price git_data eamil_data



$sql="";

$herewego="notgood";


$herewego="inlink";
if(isset($_FILES['image'])){
    $herewego="infile";
    $errors= array();
    $file_name = $_FILES['image']['name'];
    $file_size = $_FILES['image']['size'];
    $file_tmp = $_FILES['image']['tmp_name'];
    $file_type = $_FILES['image']['type'];
    $file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));

    $extensions= array("jpeg","jpg","png","gif","mp4");    
    if(in_array($file_ext,$extensions)=== false){
       $errors[]="extension not allowed, please choose a JPEG or PNG file.";
    }
    if($file_size > 2097152) {
       $errors[]='File size must be excately 2 MB';
    }

    if(empty($errors)==true) {
     $output="".$uname.time()."_2";
     move_uploaded_file($file_tmp,"".$random_id);
     $fileMoved = rename($random_id, "imgs/".$random_id ) ;
     $link="imgs/".$random_id;
     $herewego="ture";
    }else{
     print_r($errors);
    }
}





if ($comtype=="Yes") {

  $output="ture";
  $seachid=$boady;
  $websight= $header;


  $ch1 = curl_init();
  curl_setopt($ch1, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch1, CURLOPT_URL,    str_replace(' ', '', $websight."?type=post_B&postID=".$seachid)   );
  $boady       =  curl_exec($ch1);
  curl_close($ch1);



  $ch2 = curl_init();
  curl_setopt($ch2, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch2, CURLOPT_URL,    str_replace(' ', '', $websight."?type=post_2&postID=".$seachid)   );
  $git_data    =  curl_exec($c2);
  curl_close($ch2);



  $ch3 = curl_init();
  curl_setopt($ch3, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch3, CURLOPT_URL,    str_replace(' ', '', $websight."?type=post_H&postID=".$seachid)   );
  $header    =  curl_exec($ch3);
  curl_close($ch3);



  $ch4 = curl_init();
  curl_setopt($ch4, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch4, CURLOPT_URL,  str_replace(' ', '', $websight."?type=post_T&postID=".$seachid)   );
  $tital    =  curl_exec($ch4);
  curl_close($ch4);


  $ch5 = curl_init();
  curl_setopt($ch5, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch5, CURLOPT_URL,  str_replace(' ', '', $websight."?type=post_L&postID=".$seachid)   );
  $link    =  curl_exec($ch5);
  curl_close($ch5);



  $output=$output."?".$boady."?".$git_data."?".$header."?".$tital."      ".$websight."?type=post_T&postID=.  ".$seachid.$link ;


}





$here="1";
if ($tital!=""){


  $here="done";
  $sql="INSERT INTO `post_".$sitename."` (`fild_id`, `user`, `views`, `views_this_mouth`, `tital`, `type`, `header`, `boady`, `linked`, `sorce`, `upvote`, `downvote`, `buypage`, `price`, `git_data`, `eamil_data`,`created`) VALUES 


   ('".$random_id."', 
   '".$uname."',
   '0', '0', 
   '".$tital."', 
   '".$type."', 
   '".$header."', 
   '".$boady."', 
   '".$link."', 
   '".$sorce."', 
   '0', '0', ' ".$buy."', 
   '".$price."', 
   '".$git_data."', 
   '".$eamil_data."'
   ,CURRENT_TIMESTAMP); ";
  
  $result = $conn->query($sql);

  header("Location: V5.php?pageid=".$random_id."");
}


/*
  CREATE TABLE `treelose_data`.post` (
  `fild_id` VARCHAR(64) NOT NULL , 
  `user` TEXT NOT NULL , 
  `views` INT NOT NULL , 
  `views_this_mouth` INT NOT NULL , 
  `tital` TEXT NOT NULL , 
  'type' TEXT NOT NULL,
  `header` TEXT NOT NULL , 
  `boady` TEXT NOT NULL , 
  `linked` TEXT NOT NULL , 
  `sorce` TEXT NOT NULL , 
  `upvote` INT NOT NULL , 
  `downvote` INT NOT NULL, 
  `buypage` BOOLEAN not Null, 
  `price` FLOAT not Null, 
  `git_data` Text not Null, 
  `eamil_data` Text not NUll,
  PRIMARY KEY (fild_id) ) ENGINE = MyISAM
*/
//$result = $conn->query($sql);





//INSERT INTO `treelose_data` (`user`, `postid`, `board`, `ban_type`) VALUES ('thiz_user', '12911', 'bord1', 'type1');






?>




<!DOCTYPE html>
<html>
<head>
  <title>first_page</title>

<style>

.boady{

  width: 12vw;
  height: 6vw;
  font-size: 5vw;

}

.parent{

    display: flex;
    flex-direction:column;

}


.child1{

    color: blue;
    text-decoration-color: 
    flex: 1;
    margin: 4vw;
    padding: 5vw;
     border: 5px solid black;

}


.button{
  min-width:12vw;
  height: 5vw;
  font-size: 4vw;
}


.button2{
  min-width:15vw;
  height: 5vw;
  font-size: 3vw;
}
</style>

<body style="background-color: #24222a;">
  <div class="parent" style="background-color: #24222a;">

    <div class="child child1" style="background-color: #000000; color: #ffffffff; font-size:6vw; flex: 1; display: flex;">
    <form action = "" method = "POST" enctype = "multipart/form-data">
            <label for="login">Title</label><br>
            <input type="tital" id="tital" name="tital" class="button" value=""><br>
            <label for="login">Header/webpage</label><br>
            <input type="header" id="header" name="header" class="button" value=""><br>
            <label for="login">Bodys/ID</label><br>
            <input type="boady" id="boady" name="boady" class="button" value=""><br>
            <label for="login">Source</label><br>
            <input type="linked" id="sorce" name="sorce" class="button" value=<?php echo "\"".$_GET["pageid"]."\""; ?> > <br>
            Link
            <input type="checkbox"  style="height: 5vw; min-width:5vw;" name="dropdown" value="Yes" /><br>
            <input type = "file" name = "image" class="button" />
            </br>
            <input type="submit" class="button2" value="Enter">
            </select>
    </form>


  </div>
</div>
<?php echo $output;   ?>
    
</body>
</html>

