<?php

session_start();
$uname=$_SESSION['uname'];


if( $_SESSION['logedin']==""){
    header("Location: log_in.php?");
}
if ($uname=="") {
  $uname="nobody";
}
include("config.php");
include("web_name.php");



$pageid=$_GET["pageid"];
$seach_item=$_GET["user_seach"];
$type=$_GET["type"];
$combo_type="or_i";
$page_number=$_GET["page_number"] ;
if ($page_number<0) {
    $page_number=0;
}
if ($page_number=="") {
    $page_number=0;
}

$prev_page=$page_number-1;
if ($page_number<0) {
    $page_number=0;
}
$next_page=$next_number+1;
if($pageid==""){
$pageid="%%";
}
if($pageid=="all"){
$pageid="%%";
}
if ($seach_item!="%%") {
    $seach_item="%".$seach_item."%";
}



$page_numberbot=6*$page_number;
$page_numbertop=6*$page_number+6;




if ("%%"==$seach_item) {
    $sql ="SELECT * FROM `post_".$sitename."` WHERE `fild_id` LIKE '".$pageid."' ORDER BY `created`  DESC LIMIT 1;";

}
else{

    $sql="
    SELECT * FROM `post_".$sitename."` WHERE `sorce` 
    LIKE '".$pageid."' 
    AND ( 
    `user` LIKE '".$seach_item."' or 
    `boady` LIKE '".$seach_item."' or 
    `header` LIKE '".$seach_item."' ) ORDER BY `created`  DESC  
     LIMIT 1;";

}

$page_numberbot=$page_numberbot+1;
$page_numbertop=$page_numbertop+1;


$result = $conn->query($sql);
$heading_div="nodiv";
$input_type="Vpage";

if ($result->num_rows>0) {
    $count=0;
    while($row = $result->fetch_assoc() and $count==0) {
            $header=$row["header"];
            $boady=$row["boady"];
            $type=$row["type"];
            $linked=$row["linked"];
            $downvote=$row["downvote"];
            $tital=$row["tital"];
            $views=$row["views"];
            $views_this_mouth=$row["views_this_mouth"];
            $buypage=$row["buypage"];
            $poster=$row["user"];
            $sorce_H=$row["sorce"];
            $diplayed_page=$row["fild_id"];
            $count+=1;           
        }


        $heading="

        <div class=\"child child1\" style=\"background-color: #000000; color: #ffffffff; font-size:4vw; flex: 1; display: flex;\">
            <div style=\"font-size:6vw; padding: 15px;\" >".$poster."</div>
            ".$tital."<br>".$header."
        </div>
        ";

        $body="      
        <div class=\"child child1\" style=\"background-color: #000000; color: #ffffffff; font-size:2vw; flex: 1; display: flex;\">".
//

        $boady."
        </div>

        ";




        $endimg="
        <div class=\"child child2\" style=\"\">
             <img src=\"".$linked."\" class =\"img\" alt=\"HTML5 Icon\" >
        </div>";
        $sorce_HH=$sorce_H;
        if ($sorce_H=="%%") {
            $sorce_H="the main page";
        }

        $heading_div=


        "

    <div class=\"spacer\"  style=\"background-color: #000020; color: #ffffffff; font-size:4vw; flex: 1; display: flex; top:30px; padding-top: 5vw;\">

    page sorce is ".$sorce_H."
    
    </div>
    <div class=\"spacer\"  style=\"background-color: #000021; color: #ffffffff; font-size:4vw; flex: 1; display: flex; top:30px; padding-top: 1vw;\">

    page id is ".$pageid."
    
    </div>

    <div class=\"child child1\" style=\"background-color: #000000; color: #ffffffff; font-size:4vw; flex: 1; display: flex; top:30px; padding-top: 1vw;flex-direction:column; \">

        <div style=\" background-color: #000016; font-size:6vw; padding:30px; padding-top: 1vw; top:30px;\" >".$poster."</div>
            
            <div style=\"background-color: #000020; font-size:5vw; padding:30px; padding-top: 4vw;\" >".$tital."</div> ".$header."
        </div>

        <div class=\"child child1\" style=\"background-color: #000000; color: #ffffffff; font-size:5vw; flex: 1; display: flex;\">
        ".$boady."</div>

    <img src=\"".$linked."\" class =\"img\" alt=\"\" >


    <div class=\"spacer\" style=\"font-size:4vw; color: #ffffffff; \">
            <button class = 
            \"button\" 
            onclick=\"window.location.href='V5.php?pageid=".$diplayed_page." ';\">
            go2page
            </button>
            <button class = 
            \"button\" 
            onclick=\"window.location.href='V5.php?pageid=".$sorce_HH." ';\">
            sorce
            </button>
            <button class = 
            \"button\" 
            onclick=\"window.location.href='post_page2.php?pageid=".$diplayed_page." ';\">
            reply
            </button><br>
            ".$diplayed_page."
    </div>


    <div class=\"spacer\"  >


    </div>

    ";




}






$result = $conn->query($sql_view);
$result = $conn->query($sql_view_M);




$page_numberbot=6*$page_number;
$page_numbertop=6*$page_number+6;





$sql2="
    SELECT * FROM `post_".$sitename."` WHERE `sorce` 
    LIKE '".$pageid."' 
    AND ( 
    `user` LIKE '".$seach_item."' or 
    `boady` LIKE '".$seach_item."' or 
    `header` LIKE '".$seach_item."' ) ORDER BY `created`  DESC  
LIMIT ".$page_numberbot." ,".$page_numbertop.";";



$array = array();

$result = $conn->query($sql2);



if ($result->num_rows>0) {

    while($row = $result->fetch_assoc()) {


    $C_user =$row["user"];
    $C_tital=$row["tital"];
    $content="<img class=\"img-fluid\" src=\"imgs/".$row["fild_id"]."\">";
    $C_header=$row["header"];

    $button="<button style=\"float: right;\" onclick=
    \"window.location.href= 'V3.php?pageid=".$row["fild_id"]." ' ;\"  >go to page</button>";
    $content="<img src=\"".$row["linked"]."\" style=\"width: 180px; height:110px; \">";




    $outputdivs=
        "
        <img src=\"".$row["linked"]."\" class =\"img\" alt=\"\" >

        <div class=\"child child1\" style=\"background-color: #000000; color: #ffffffff; font-size:4vw; flex: 1; display: flex;flex-direction:column;   \">
            
            <div style=\"font-size:5vw; padding: 15px; background-color: #000030;\" > 
            ".$row["user"]."            


        </div>".$row["tital"]."<br>".$row["header"].
            "<br><div>

        </div>
        </div>

        <div class=\"spacer\" style=\"font-size:4vw; color: #ffffffff; \">
                <button class = 
                    \"button\" 
                    onclick=\"window.location.href='V5.php?pageid=".$row["fild_id"]." ';\">
                    go2page
                </button>
                <button class = 
                    \"button\" 
                    onclick=\"window.location.href=' V5.php?pageid=".$row["sorce"]." ';\">
                    sorce
                </button>
                <button class = 
                    \"button\" 
                    onclick=\"window.location.href='post_page2.php?pageid=".$row["fild_id"]." ';\">
                    reply
                </button><br>
                ".$row["fild_id"]."
        </div>

        <div class=\"spacer\">


        </div>
        ";
        if ($diplayed_page==$row["fild_id"]){

            $outputdivs="";
        }



    


    array_push($array, $outputdivs);
    }
    

}
$outputdiv=$array;








?>



<html>
<head>
    <style type="text/css">
        


body{
    margin: 0;
    padding: 0
}

.househead{


}


.parent{
    border: 1px solid black ;
    display: flex;
    flex-direction:column;
}

.child{
    height: 50px;
    padding: 10px
}

.child1{


    color: blue;
    text-decoration-color: 
    
    flex: 1;

padding: 5vw;
     border: 5px solid black ;
}
.child2{
    flex-direction: row;
    display: flex;
     background-color: lightblue;
    flex: 1;
   margin: 10vw;
padding: 5vw;
     border: 5px solid black ;
}



.child3{
    flex-direction: row;
    display: flex;
     background-color: lightblue;
    flex: 1;
   margin: 5vw;
padding: 5vw;
     border: 5px solid black ;
}

.img {
    max-width: 100%;
    height: auto;
    width: auto; /* ie8 */
}
.srpite{
height: 50px;
width: 50px;
}




.serachbox
{
min-width:12vw;
height: 6vw;
font-size: 5vw;
}


.serachbox2
{
min-width:12vw;
height: 6vw;
font-size: 5vw;
}


.button
{
max-width:20vw;
height: 5vw;
font-size: 3vw;
}


.heading
{
max-width:10vw;
height: 10vw;
font-size: 3vw;
}



.spacer{

min-width:12vw;
min-height:7vw;

background-color: #24222a;


}

    </style>
    </head>
    
    <body>

    

    <div class="parent">
    

    <div style="background-color: #99ccff; color: #000000; font-size: 3vw; display: flex;     margin: 0; 
      margin-top: 0px;
  position: fixed;
  width:100%;
     ">

            <img src="imgs/1.png" class = "heading"  alt="alex">

            <form action="" >
                <label for="fname">Search</label>
                <input class= "serachbox" type="text" id="fname" name="user_seach" id="user_seach">           
                <input class = "button" type="submit" value="Submit"  >
            </form>
                    </div>

<div class="spacer">
</div>
        <?php echo $heading_div;?>














            <?php 
                $i = 0;
                while ($i < count($outputdiv) )
                {
                    echo $outputdiv[$i];
                    $i++;
                }
            ?>







    <div class="child child1" style="background-color: #000000; display: flex; justify-content: Space-between; color: #ffffffff; font-size: 10vw; flex: 1;">


            <button class = 
                "button" 
                onclick=<?php echo "\"window.location.href='V5.php?pageid=".$pageid."&user_seach=".$seach_item."&page_number=".($page_number-1)."';\" ";?>>
                prev
            </button>


            <button class = 
                "button" 
                onclick=<?php echo "\"window.location.href='V5.php?pageid=".$pageid."&user_seach=".$seach_item."&page_number=".($page_number+1)."';\" ";?>>
                next
            </button>





    </div>


<div class="spacer">

</div>



    <div class="spacer" style="color: #ffffffff; font-size: 10vw; flex: 1;" >

    </div>
    
    <div class="child child1" style="background-color: #000000; display: flex; justify-content: Space-between; color: #ffffffff; font-size: 10vw; flex: 1;">

            <form action="" >
                <label for="fname">Search page</label>
                <input class= "serachbox" type="text" id="fname" name="pageid" id="pageid" value=<?php echo "\"".$pageid."\""; ?> > 
                 <label for="fname">Search term</label>
                <input class= "serachbox" type="text" id="fname" name="user_seach" id="user_seach">           
                <input class = "button" type="submit" value="Submit"  >
            </form>
    </div>

<div class="spacer" style="color: #ffffffff; font-size: 6vw; flex: 1;" >

<?php echo "logedin as ".$uname;?>
</br>


            <button class = 
                "button" 


                onclick=

                <?php 
                echo " \"window.location.href='post_page2.php?pageid=".$pageid."' \""?> >
                reply to page

            </button>
 
         <div style="color: #ffffffff; font-size: 3vw; flex: 1;">
        http://alexhaussmann.com/adhaussmann/alex/final/datumes.php
        </div>

        <button class = 
                "button" 


                onclick=

                <?php 
                echo " \"window.location.href='admin_page.html' \" "?> >
                adminpage

        </button>

    <div class="spacer" style="color: #ffffffff; font-size: 10vw; flex: 1;" >

    </div>

</div>


    </div>


    </div>




    </div>
        
        

        
    </body>




    
    
</html>