<?php

session_start();
$uname=$_SESSION['uname'];


if( $_SESSION['logedin']==""){
    header("Location: log_in.php?");
}
if ($uname=="") {
  $uname="nobody";
}
include("config.php");
include("web_name.php");
/*	
	CREATE TABLE `treelose_data`.`post` (   ,
	`fild_id` VARCHAR(64) NOT NULL 			, 
	`user` TEXT NOT NULL 					, 
	`views` INT NOT NULL 					, 
	`views_this_mouth` INT NOT NULL 		, 
	`tital` TEXT NOT NULL 					, 
	`type` TEXT NOT NULL  					,
	`header` TEXT NOT NULL    				, 
	`boady` TEXT NOT NULL     				, 
	`linked` TEXT NOT NULL    				, 
	`sorce` TEXT NOT NULL     				, 
	`upvote` INT NOT NULL     				, 
	`downvote` INT NOT NULL   				, 
	`buypage` BOOLEAN not Null  			, 
	`price` FLOAT not Null 					, 
	`git_data` Text not Null 				, 
	`eamil_data` Text not NUll 				,
	`created` TIMESTAMP NOT NULL 			,  
	PRIMARY KEY (fild_id) ) ENGINE = MyISAM ;
*/
$pageid=$_GET["pageid"];
$seach_item=$_GET["user_seach"];
$type=$_GET["type"];
$combo_type="or_i";
$page_number=$_GET["page_number"] ;
if ($page_number<0) {
	$page_number=0;
}
if ($page_number=="") {
	$page_number=0;
}

$prev_page=$page_number-1;
if ($page_number<0) {
	$page_number=0;
}
$next_page=$next_number+1;
if($pageid==""){
$pageid="%%";
}
if($pageid=="all"){
$pageid="%%";
}
$seach_item="%".$seach_item."%";
$sql ="SELECT * FROM `post_".$sitename."` WHERE `fild_id` LIKE '".$pageid."' LIMIT 1;";

$hersit=$sql."inhere" ;
$result = $conn->query($sql);
$heading_div="nodiv";
$input_type="Vpage";




if ($result->num_rows>0) {
	$count=0;
	while($row = $result->fetch_assoc() and $count==0) {
					    $header=$row["header"];
					    $boady=$row["boady"];
					    $type=$row["type"];
					    $linked=$row["linked"];
					    $downvote=$row["downvote"];
					    $tital=$row["tital"];
					    $views=$row["views"];
					    $views_this_mouth=$row["views_this_mouth"];
					    $buypage=$row["buypage"];
					    $poster=$row["user"];
					    $sorce_H=$row["sorce"];
					    $diplayed_page="fild_id";
					    $count+=1;			    
					}


		$heading="


        <div class=\"child child1\" style=\"background-color: #000000; color: #ffffffff; font-size:4vw; flex: 1; display: flex;\">
            <div style=\"font-size:6vw; padding: 15px;\" >".$poster."</div>
            ".$header."

        </div>

		";

        $body="      <div class=
        \"child child1\" style=\"background-color: #000000; color: #ffffffff; font-size:2vw; flex: 1; display: flex;\">".


        $boady."

        <button class = \"button\" onclick= \" window.location.href='V3.php?pageid=".$sorce_H."'; \"  >

        back
        </button>
        </div>

        ";




        $endimg="
        <div class=\"child child2\" style=\"background: url(imgs/1.png)\">

             <img src=\"".$linked."\" class =\"img\" alt=\"HTML5 Icon\" >


        </div>";

        $heading_div=$heading.$body.$endimg;




}






$result = $conn->query($sql_view);
$result = $conn->query($sql_view_M);

$page_numberbot=6*$page_number;
$page_numbertop=6*$page_number+6;


$sql2="
SELECT * FROM `post_".$sitename."` WHERE `sorce` 
LIKE '".$pageid."' 
AND ( 
`user` LIKE '".$seach_item."' or 
`boady` LIKE '".$seach_item."' or 
`header` LIKE '".$seach_item."' ) ORDER BY `created`  DESC  

LIMIT ".$page_numberbot." ,".$page_numbertop.";";



$array = array();

$result = $conn->query($sql2);

if ($result->num_rows>0) {

	while($row = $result->fetch_assoc()) {


	$C_user =$row["user"];
	$C_tital=$row["tital"];
	$content="<img class=\"img-fluid\" src=\"imgs/".$row["fild_id"]."\">";
	$C_header=$row["header"];

	$button="<button style=\"float: right;\" onclick=
	\"window.location.href= 'V3.php?pageid=".$row["fild_id"]." ' ;\"  >go to page</button>";
	$content="<img src=\"".$row["linked"]."\" style=\"width: 180px; height:110px; \">";


	$outputdivs=
		"
	
        <div class=\"child child1\" style=\"background-color: #000000; color: #ffffffff; font-size:2vw; flex: 1; display: flex;\">
            
            <div style=\"font-size:6vw; padding: 15px;\" > 
            ".$C_user."</div>"
            .
            $C_header
            ."
            <button class = \"button\" onclick=\"window.location.href='V3.php?pageid=".$row["fild_id"]."';\">
        post page
        </button>
        \
        </div>

        <div class=\"child child2\" style=\"background: url(imgs/1.png)\">

             <img src=\"imgs/".$row["fild_id"]."\" class =\"img\" alt=\"HTML5 Icon\" >


        </div>


	 ";


	array_push($array, $outputdivs);
	}
	

}



$outputdiv=$array;





function giff() {
  return "

<div class=\"child child3\" style=\"background: url(imgs/2.png); display: flex; justify-content: Space-between;\">




<img src=\"gifs/".rand(1,25).".gif\" alt=\"HTML5 Icon\" style=\"width:20vw;height:20vw;\">

<img src=\"gifs/".rand(1,25).".gif\" alt=\"HTML5 Icon\" style=\"width:20vw;height:20vw;\">

<img src=\"gifs/".rand(1,25).".gif\" alt=\"HTML5 Icon\" style=\"width:20vw;height:20vw;\">



        </div>


  ";
} 


?>



<html>
<head>
    <style type="text/css">
        


body{
    margin: 0;
    padding: 0
}

.househead{


}


.parent{
    border: 1px solid black ;
    display: flex;
    flex-direction:column;
}

.child{
    height: 50px;
    margin: 10;
    padding: 10px
}

.child1{


    color: blue;
    text-decoration-color: 
    
    flex: 1;

    margin: 4vw;
padding: 5vw;
     border: 5px solid black ;
}
.child2{
    flex-direction: row;
    display: flex;
     background-color: lightblue;
    flex: 1;
   margin: 10vw;
padding: 5vw;
     border: 5px solid black ;
}



.child3{
    flex-direction: row;
    display: flex;
     background-color: lightblue;
    flex: 1;
   margin: 5vw;
padding: 5vw;
     border: 5px solid black ;
}

.img {
    max-width: 100%;
    height: auto;
    width: auto; /* ie8 */
}
.srpite{
height: 50px;
width: 50px;
}




.serachbox
{
min-width:12vw;
height: 6vw;
font-size: 5vw;
}


.button
{
min-width:12vw;
height: 5vw;
font-size: 4vw;
}



    </style>
    </head>
    
    <body>


    <div class="parent" style="background: url(imgs/1.png)">
	


    	<?php echo $heading_div;?>

    	<?php echo giff();?>


            <div style="background-color: #000000; color: #ffffffff; font-size: 10vw; flex: 1; display: flex;     margin: 5vw; padding: 5vw; ">
        
        <button class = "button" onclick=<?php echo "window.location.href='post_page2.php?pageid=".$pageid."';" ?>   >
        post page
        </button></br>
        <form action="" >
        	<br>


    		<br>

            <label for="fname">Search</label><br>
            <input class= "serachbox" type="text" id="fname" name="user_seach" id="user_seach"         >
            
            </br>
            
            <label for="lname">Search Page</label>
            <br>
            <input class= "serachbox" type="text" id="lname" name="pageid"  id="pageid"   value=""     >

          <br>
            <input class = "button" type="submit" value="Submit"  >


        </form>

             </div>










			<?php 
				$i = 0;
		        while ($i < count($outputdiv) )
		        {
		            echo $outputdiv[$i]."<br>".giff();
		            $i++;
		        }
		    ?>







    <div class="child child3" style="background-color: #000000; display: flex; justify-content: Space-between; color: #ffffffff; font-size: 10vw; flex: 1;">

          <a <?php echo "href=\"V3.php?pageid=".$pageid."&page_number=".($page_number-1)."\" ";?> >PREV</a>
          <a <?php echo "href=\"V3.php?pageid=".$pageid."&page_number=".($page_number+1)."\" ";?> >NEXT</a>

          <a href="#">&raquo;</a>


    </div>



    <div class="child child3" style=" background-color: #000000; display: flex; justify-content: Space-between; color: #ffffffff; font-size: 10vw; flex: 1;">

        logedin as <?php echo $uname; ?>
        <br>

        <button class = "button" onclick="window.location.href='post_page2.php';">
            logout
        </button></br>




    </div>


    </div>




    </div>
        
        
        

        
    </body>




    
    
</html>