<?

session_start();


include("config.php");
include("web_name.php");

$uname=$_POST["uname"];
$password=$_POST["password"];

$sql = "SELECT * FROM user".$sitename." WHERE user LIKE '".$uname."' ;";

$result = $conn->query($sql1);
if($uname!=""){

  $result = $conn->query($sql1);


  if($result->num_rows==0){


      $go="true";

      $_SESSION['uname']=$uname;

      $sql="INSERT INTO `users_".$sitename."` (`user`, `payment`, `created`, `email`, `phone number`, `paymentkey`, `pass`, `views`, `view_M`) VALUES 
      ('".$uname."', '".$payment."', CURRENT_TIMESTAMP, '".$email."', '".$phone."', '".$paymentkey."', '".$password."', '0', '0');";
      $result = $conn->query($sql);

      $_SESSION['uname']=$uname;
      $_SESSION['logedin']="True";

      header("Location: V3.php");



  }
  else{
      $output="uname in use";
  }

}


$uname=$_SESSION['uname'];
if ($uname=="") {
  $uname="nobody";
}


/*
CREATE TABLE `treelose_data`.`user_T` (
 `user` VARCHAR(100) NOT NULL , 
 `payment` TEXT NOT NULL , 
 `created` TIMESTAMP NOT NULL , 
 `email` TEXT NOT NULL , 
 `phone number` TEXT NOT NULL , 
 `paymentkey` TEXT NOT NULL , 
 `pass` TEXT NOT NULL, 
 `views` int NOT NULL,
 `view_M` int not NULL,
 PRIMARY KEY (user) ) ENGINE = MyISAM
*/



?>






<!DOCTYPE html>
<html>
<head>
  <title>first_page</title>

<style>





.parent{
    border: 1px solid black ;
    display: flex;
    flex-direction:column;
}


.child1{


    color: blue;
    text-decoration-color: 
    
    flex: 1;

    margin: 4vw;
padding: 5vw;
     border: 5px solid black ;
}


</style>

<body style="background: url(imgs/1.png)">
  <div class="parent" style="background: url(1.png)">



    <div class="child child1" style="background-color: #000000; color: #ffffffff; font-size:5vw; flex: 1; display: flex;">
      
    <form action = "" method = "POST" enctype = "multipart/form-data">

    <form action = "" method = "POST" enctype = "multipart/form-data">

            <label for="login">username</label><br>
            <input type="tital" id="uname" name="uname" class="button" value=""><br>

            <label for="login">password</label><br>
            <input type="header" id="password" name="password" class="button" value=""><br>


            <label for="login">website password</label><br>
            <input type="header" id="password" name="sight" class="button" value=""><br>

            </br>
            <input type="submit" class="button" value="Enter">
            </select>
    </form>
    </form>


  </div>
</div>
    
</body>
</html>


